%% Initialize Project variables

%   Copyright 2021-2022 The MathWorks, Inc.
evalin('base', 'InitSimulinkPlantVars;');
evalin('base', 'InitPX4ControllerVars;');
evalin('base', 'InitOnboardAlgorithmVars;');
evalin('base', 'Init3DVisualizationVars;');

