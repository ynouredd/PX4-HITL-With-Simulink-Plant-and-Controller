%

%   Copyright 2021-2023 The MathWorks, Inc.

% Onboard algorithm frequency (10 Hz)
OnboardSampleTime = 0.1;

% MAVLink data source
% UDP - 0
% Serial - 1
onboardMAVLinkSource = 0;


