%

%   Copyright 2022 The MathWorks, Inc.

% UDP Receive data rate
SampleTime_UDPReceive = 0.01;

% Unreal Engine Sample Time
SampleTime_UnrealConfig = 0.1;

% Don't stream data to Onboard Computer
enableOnboardStreaming = 0;
