//
// File: Quadcopter_ControllerWithNavigation1_data.cpp
//
// Code generated for Simulink model 'Quadcopter_ControllerWithNavigation1'.
//
// Model version                  : 4.12
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Wed Apr  3 23:18:28 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "Quadcopter_ControllerWithNavigation1.h"

// Block parameters (default storage)
P_Quadcopter_ControllerWithNavigation1_T Quadcopter_ControllerWithNavigation1_P =
{
  // Variable: pitchP
  //  Referenced by: '<S254>/Proportional Gain'

  15.0,

  // Variable: pitchRateD
  //  Referenced by: '<S145>/Derivative Gain'

  0.01,

  // Variable: pitchRateI
  //  Referenced by: '<S148>/Integral Gain'

  0.05824,

  // Variable: pitchRateP
  //  Referenced by: '<S156>/Proportional Gain'

  0.0724,

  // Variable: rollP
  //  Referenced by: '<S302>/Proportional Gain'

  15.0,

  // Variable: rollRateD
  //  Referenced by: '<S195>/Derivative Gain'

  0.01,

  // Variable: rollRateI
  //  Referenced by: '<S198>/Integral Gain'

  0.0335,

  // Variable: rollRateP
  //  Referenced by: '<S206>/Proportional Gain'

  0.2,

  // Variable: yawRateD
  //  Referenced by: '<S95>/Derivative Gain'

  0.0,

  // Variable: yawRateI
  //  Referenced by: '<S98>/Integral Gain'

  0.1,

  // Variable: yawRateP
  //  Referenced by: '<S106>/Proportional Gain'

  0.2,

  // Mask Parameter: PID_Altitude_D
  //  Referenced by: '<S500>/Derivative Gain'

  0.01,

  // Mask Parameter: PID_vz_D
  //  Referenced by: '<S550>/Derivative Gain'

  0.05,

  // Mask Parameter: PIDController_D
  //  Referenced by: '<S628>/Derivative Gain'

  0.0,

  // Mask Parameter: PIDController1_D
  //  Referenced by: '<S678>/Derivative Gain'

  0.0025,

  // Mask Parameter: PIDController2_D
  //  Referenced by: '<S728>/Derivative Gain'

  0.0025,

  // Mask Parameter: PID_Altitude_I
  //  Referenced by: '<S503>/Integral Gain'

  0.01,

  // Mask Parameter: PID_vz_I
  //  Referenced by: '<S553>/Integral Gain'

  0.1,

  // Mask Parameter: PIDController_I
  //  Referenced by: '<S631>/Integral Gain'

  0.0,

  // Mask Parameter: PIDController1_I
  //  Referenced by: '<S681>/Integral Gain'

  0.0,

  // Mask Parameter: PIDController2_I
  //  Referenced by: '<S731>/Integral Gain'

  0.0,

  // Mask Parameter: PIDController_InitialConditionForFilter
  //  Referenced by: '<S96>/Filter'

  0.0,

  // Mask Parameter: PIDController1_InitialConditionForFilter
  //  Referenced by: '<S146>/Filter'

  0.0,

  // Mask Parameter: PIDController2_InitialConditionForFilter
  //  Referenced by: '<S196>/Filter'

  0.0,

  // Mask Parameter: PID_Altitude_InitialConditionForFilter
  //  Referenced by: '<S501>/Filter'

  0.0,

  // Mask Parameter: PID_vz_InitialConditionForFilter
  //  Referenced by: '<S551>/Filter'

  0.0,

  // Mask Parameter: PIDController_InitialConditionForFilter_o
  //  Referenced by: '<S629>/Filter'

  0.0,

  // Mask Parameter: PIDController1_InitialConditionForFilter_k
  //  Referenced by: '<S679>/Filter'

  0.0,

  // Mask Parameter: PIDController2_InitialConditionForFilter_m
  //  Referenced by: '<S729>/Filter'

  0.0,

  // Mask Parameter: PIDController_InitialConditionForIntegrator
  //  Referenced by: '<S101>/Integrator'

  0.0,

  // Mask Parameter: PIDController1_InitialConditionForIntegrator
  //  Referenced by: '<S151>/Integrator'

  0.0,

  // Mask Parameter: PIDController2_InitialConditionForIntegrator
  //  Referenced by: '<S201>/Integrator'

  0.0,

  // Mask Parameter: PID_Altitude_InitialConditionForIntegrator
  //  Referenced by: '<S506>/Integrator'

  0.0,

  // Mask Parameter: PID_vz_InitialConditionForIntegrator
  //  Referenced by: '<S556>/Integrator'

  0.0,

  // Mask Parameter: PIDController_InitialConditionForIntegrator_g
  //  Referenced by: '<S634>/Integrator'

  0.0,

  // Mask Parameter: PIDController1_InitialConditionForIntegrator_i
  //  Referenced by: '<S684>/Integrator'

  0.0,

  // Mask Parameter: PIDController2_InitialConditionForIntegrator_e
  //  Referenced by: '<S734>/Integrator'

  0.0,

  // Mask Parameter: PIDController5_LowerSaturationLimit
  //  Referenced by: '<S352>/Saturation'

  -0.87266462599716477,

  // Mask Parameter: PIDController_LowerSaturationLimit
  //  Referenced by:
  //    '<S108>/Saturation'
  //    '<S94>/DeadZone'

  -0.1,

  // Mask Parameter: PIDController1_LowerSaturationLimit
  //  Referenced by:
  //    '<S158>/Saturation'
  //    '<S144>/DeadZone'

  -0.2,

  // Mask Parameter: PIDController2_LowerSaturationLimit
  //  Referenced by:
  //    '<S208>/Saturation'
  //    '<S194>/DeadZone'

  -0.2,

  // Mask Parameter: PID_Altitude_LowerSaturationLimit
  //  Referenced by:
  //    '<S513>/Saturation'
  //    '<S499>/DeadZone'

  -2.0,

  // Mask Parameter: PID_vz_LowerSaturationLimit
  //  Referenced by:
  //    '<S563>/Saturation'
  //    '<S549>/DeadZone'

  0.0,

  // Mask Parameter: PIDController1_LowerSaturationLimit_j
  //  Referenced by: '<S463>/Saturation'

  -4.0,

  // Mask Parameter: PIDController_LowerSaturationLimit_f
  //  Referenced by: '<S415>/Saturation'

  -0.3490658503988659,

  // Mask Parameter: PIDController5_LowerSaturationLimit_g
  //  Referenced by: '<S885>/Saturation'

  -0.87266462599716477,

  // Mask Parameter: PIDController_LowerSaturationLimit_f4
  //  Referenced by:
  //    '<S641>/Saturation'
  //    '<S627>/DeadZone'

  -0.1,

  // Mask Parameter: PIDController1_LowerSaturationLimit_p
  //  Referenced by:
  //    '<S691>/Saturation'
  //    '<S677>/DeadZone'

  -0.2,

  // Mask Parameter: PIDController2_LowerSaturationLimit_f
  //  Referenced by:
  //    '<S741>/Saturation'
  //    '<S727>/DeadZone'

  -0.2,

  // Mask Parameter: PIDController_N
  //  Referenced by: '<S104>/Filter Coefficient'

  100.0,

  // Mask Parameter: PIDController1_N
  //  Referenced by: '<S154>/Filter Coefficient'

  50.0,

  // Mask Parameter: PIDController2_N
  //  Referenced by: '<S204>/Filter Coefficient'

  50.0,

  // Mask Parameter: PID_Altitude_N
  //  Referenced by: '<S509>/Filter Coefficient'

  10.0,

  // Mask Parameter: PID_vz_N
  //  Referenced by: '<S559>/Filter Coefficient'

  10.0,

  // Mask Parameter: PIDController_N_h
  //  Referenced by: '<S637>/Filter Coefficient'

  100.0,

  // Mask Parameter: PIDController1_N_e
  //  Referenced by: '<S687>/Filter Coefficient'

  50.0,

  // Mask Parameter: PIDController2_N_p
  //  Referenced by: '<S737>/Filter Coefficient'

  50.0,

  // Mask Parameter: PIDController5_P
  //  Referenced by: '<S350>/Proportional Gain'

  2.8,

  // Mask Parameter: PID_Altitude_P
  //  Referenced by: '<S511>/Proportional Gain'

  1.5,

  // Mask Parameter: PID_vz_P
  //  Referenced by: '<S561>/Proportional Gain'

  0.5,

  // Mask Parameter: PIDController1_P
  //  Referenced by: '<S461>/Proportional Gain'

  0.6,

  // Mask Parameter: PIDController_P
  //  Referenced by: '<S413>/Proportional Gain'

  0.3,

  // Mask Parameter: PIDController5_P_d
  //  Referenced by: '<S883>/Proportional Gain'

  2.0,

  // Mask Parameter: PIDController_P_j
  //  Referenced by: '<S639>/Proportional Gain'

  0.4,

  // Mask Parameter: PIDController3_P
  //  Referenced by: '<S787>/Proportional Gain'

  4.0,

  // Mask Parameter: PIDController1_P_e
  //  Referenced by: '<S689>/Proportional Gain'

  0.035,

  // Mask Parameter: PIDController4_P
  //  Referenced by: '<S835>/Proportional Gain'

  4.0,

  // Mask Parameter: PIDController2_P
  //  Referenced by: '<S739>/Proportional Gain'

  0.035,

  // Mask Parameter: PIDController5_UpperSaturationLimit
  //  Referenced by: '<S352>/Saturation'

  0.87266462599716477,

  // Mask Parameter: PIDController_UpperSaturationLimit
  //  Referenced by:
  //    '<S108>/Saturation'
  //    '<S94>/DeadZone'

  0.1,

  // Mask Parameter: PIDController1_UpperSaturationLimit
  //  Referenced by:
  //    '<S158>/Saturation'
  //    '<S144>/DeadZone'

  0.2,

  // Mask Parameter: PIDController2_UpperSaturationLimit
  //  Referenced by:
  //    '<S208>/Saturation'
  //    '<S194>/DeadZone'

  0.2,

  // Mask Parameter: PID_Altitude_UpperSaturationLimit
  //  Referenced by:
  //    '<S513>/Saturation'
  //    '<S499>/DeadZone'

  2.0,

  // Mask Parameter: PID_vz_UpperSaturationLimit
  //  Referenced by:
  //    '<S563>/Saturation'
  //    '<S549>/DeadZone'

  1.0,

  // Mask Parameter: PIDController1_UpperSaturationLimit_h
  //  Referenced by: '<S463>/Saturation'

  4.0,

  // Mask Parameter: PIDController_UpperSaturationLimit_i
  //  Referenced by: '<S415>/Saturation'

  0.3490658503988659,

  // Mask Parameter: PIDController5_UpperSaturationLimit_g
  //  Referenced by: '<S885>/Saturation'

  0.87266462599716477,

  // Mask Parameter: PIDController_UpperSaturationLimit_c
  //  Referenced by:
  //    '<S641>/Saturation'
  //    '<S627>/DeadZone'

  0.1,

  // Mask Parameter: PIDController1_UpperSaturationLimit_f
  //  Referenced by:
  //    '<S691>/Saturation'
  //    '<S677>/DeadZone'

  0.2,

  // Mask Parameter: PIDController2_UpperSaturationLimit_k
  //  Referenced by:
  //    '<S741>/Saturation'
  //    '<S727>/DeadZone'

  0.2,

  // Mask Parameter: CompareToConstant_const
  //  Referenced by: '<S30>/Constant'

  5U,

  // Computed Parameter: Out1_Y0
  //  Referenced by: '<S37>/Out1'

  {
    (0ULL),                            // timestamp
    0U,                                // type

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    ,                                  // _padding0

    {
      {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      } }
    // waypoints
  },

  // Computed Parameter: Constant_Value
  //  Referenced by: '<S42>/Constant'

  {
    (0ULL),                            // timestamp
    0U,                                // type

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    ,                                  // _padding0

    {
      {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      } }
    // waypoints
  },

  // Computed Parameter: Constant_Value_i
  //  Referenced by: '<S36>/Constant'

  {
    (0ULL),                            // timestamp
    0U,                                // type

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    ,                                  // _padding0

    {
      {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      }, {
        (0ULL),                        // timestamp

        {
          0.0F, 0.0F, 0.0F }
        ,                              // position

        {
          0.0F, 0.0F, 0.0F }
        ,                              // velocity

        {
          0.0F, 0.0F, 0.0F }
        ,                              // acceleration
        0.0F,                          // yaw
        0.0F,                          // yaw_speed
        false,                         // point_valid
        0U,                            // type

        {
          0U, 0U }
        // _padding0
      } }
    // waypoints
  },

  // Computed Parameter: Out1_Y0_e
  //  Referenced by: '<S10>/Out1'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q_offset

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // pose_covariance
    0.0F,                              // vx
    0.0F,                              // vy
    0.0F,                              // vz
    0.0F,                              // rollspeed
    0.0F,                              // pitchspeed
    0.0F,                              // yawspeed

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // velocity_covariance
    0U,                                // local_frame
    0U,                                // velocity_frame

    {
      0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_n
  //  Referenced by: '<S6>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q_offset

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // pose_covariance
    0.0F,                              // vx
    0.0F,                              // vy
    0.0F,                              // vz
    0.0F,                              // rollspeed
    0.0F,                              // pitchspeed
    0.0F,                              // yawspeed

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // velocity_covariance
    0U,                                // local_frame
    0U,                                // velocity_frame

    {
      0U, 0U }
    // _padding0
  },

  // Computed Parameter: Out1_Y0_o
  //  Referenced by: '<S49>/Out1'

  {
    (0ULL),                            // timestamp

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    },                                 // previous

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    },                                 // current

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    }                                  // next
  },

  // Computed Parameter: Constant_Value_l
  //  Referenced by: '<S34>/Constant'

  {
    (0ULL),                            // timestamp

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    },                                 // previous

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    },                                 // current

    {
      (0ULL),                          // timestamp
      0.0,                             // lat
      0.0,                             // lon
      0.0F,                            // vx
      0.0F,                            // vy
      0.0F,                            // vz
      0.0F,                            // alt
      0.0F,                            // yaw
      0.0F,                            // yawspeed
      0.0F,                            // loiter_radius
      0.0F,                            // acceptance_radius
      0.0F,                            // cruising_speed
      0.0F,                            // cruising_throttle
      false,                           // valid
      0U,                              // type
      false,                           // velocity_valid
      0U,                              // velocity_frame
      false,                           // alt_valid
      false,                           // yaw_valid
      false,                           // yawspeed_valid
      0,                               // landing_gear
      0,                               // loiter_direction
      false,                           // disable_weather_vane

      {
        0U, 0U, 0U, 0U, 0U, 0U }
      // _padding0
    }                                  // next
  },

  // Computed Parameter: Out1_Y0_p
  //  Referenced by: '<S13>/Out1'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample
    (0ULL),                            // ref_timestamp
    0.0,                               // ref_lat
    0.0,                               // ref_lon
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z

    {
      0.0F, 0.0F }
    ,                                  // delta_xy
    0.0F,                              // delta_z
    0.0F,                              // vx
    0.0F,                              // vy
    0.0F,                              // vz
    0.0F,                              // z_deriv

    {
      0.0F, 0.0F }
    ,                                  // delta_vxy
    0.0F,                              // delta_vz
    0.0F,                              // ax
    0.0F,                              // ay
    0.0F,                              // az
    0.0F,                              // heading
    0.0F,                              // delta_heading
    0.0F,                              // ref_alt
    0.0F,                              // dist_bottom
    0.0F,                              // eph
    0.0F,                              // epv
    0.0F,                              // evh
    0.0F,                              // evv
    0.0F,                              // vxy_max
    0.0F,                              // vz_max
    0.0F,                              // hagl_min
    0.0F,                              // hagl_max
    false,                             // xy_valid
    false,                             // z_valid
    false,                             // v_xy_valid
    false,                             // v_z_valid
    0U,                                // xy_reset_counter
    0U,                                // z_reset_counter
    0U,                                // vxy_reset_counter
    0U,                                // vz_reset_counter
    0U,                                // heading_reset_counter
    false,                             // xy_global
    false,                             // z_global
    false,                             // dist_bottom_valid
    0U,                                // dist_bottom_sensor_bitfield

    {
      0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_e
  //  Referenced by: '<S9>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample
    (0ULL),                            // ref_timestamp
    0.0,                               // ref_lat
    0.0,                               // ref_lon
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z

    {
      0.0F, 0.0F }
    ,                                  // delta_xy
    0.0F,                              // delta_z
    0.0F,                              // vx
    0.0F,                              // vy
    0.0F,                              // vz
    0.0F,                              // z_deriv

    {
      0.0F, 0.0F }
    ,                                  // delta_vxy
    0.0F,                              // delta_vz
    0.0F,                              // ax
    0.0F,                              // ay
    0.0F,                              // az
    0.0F,                              // heading
    0.0F,                              // delta_heading
    0.0F,                              // ref_alt
    0.0F,                              // dist_bottom
    0.0F,                              // eph
    0.0F,                              // epv
    0.0F,                              // evh
    0.0F,                              // evv
    0.0F,                              // vxy_max
    0.0F,                              // vz_max
    0.0F,                              // hagl_min
    0.0F,                              // hagl_max
    false,                             // xy_valid
    false,                             // z_valid
    false,                             // v_xy_valid
    false,                             // v_z_valid
    0U,                                // xy_reset_counter
    0U,                                // z_reset_counter
    0U,                                // vxy_reset_counter
    0U,                                // vz_reset_counter
    0U,                                // heading_reset_counter
    false,                             // xy_global
    false,                             // z_global
    false,                             // dist_bottom_valid
    0U,                                // dist_bottom_sensor_bitfield

    {
      0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Out1_Y0_i
  //  Referenced by: '<S583>/Out1'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_last_signal
    0,                                 // rssi
    0U,                                // rc_lost_frame_count
    0U,                                // rc_total_frame_count
    0U,                                // rc_ppm_frame_length

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
    ,                                  // values
    0U,                                // channel_count
    false,                             // rc_failsafe
    false,                             // rc_lost
    0U,                                // input_source

    {
      0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_f
  //  Referenced by: '<S582>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_last_signal
    0,                                 // rssi
    0U,                                // rc_lost_frame_count
    0U,                                // rc_total_frame_count
    0U,                                // rc_ppm_frame_length

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
    ,                                  // values
    0U,                                // channel_count
    false,                             // rc_failsafe
    false,                             // rc_lost
    0U,                                // input_source

    {
      0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_g
  //  Referenced by: '<S368>/Constant'

  {
    (0ULL),                            // timestamp
    0.0F,                              // roll_body
    0.0F,                              // pitch_body
    0.0F,                              // yaw_body
    0.0F,                              // yaw_sp_move_rate

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q_d

    {
      0.0F, 0.0F, 0.0F }
    ,                                  // thrust_body
    false,                             // roll_reset_integral
    false,                             // pitch_reset_integral
    false,                             // yaw_reset_integral
    false,                             // fw_control_yaw
    0U,                                // apply_flaps

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_il
  //  Referenced by: '<S895>/Constant'

  {
    (0ULL),                            // timestamp
    0.0F,                              // roll_body
    0.0F,                              // pitch_body
    0.0F,                              // yaw_body
    0.0F,                              // yaw_sp_move_rate

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q_d

    {
      0.0F, 0.0F, 0.0F }
    ,                                  // thrust_body
    false,                             // roll_reset_integral
    false,                             // pitch_reset_integral
    false,                             // yaw_reset_integral
    false,                             // fw_control_yaw
    0U,                                // apply_flaps

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_d
  //  Referenced by: '<S366>/Constant'

  {
    (0ULL),                            // timestamp
    0.0F,                              // roll_body
    0.0F,                              // pitch_body
    0.0F,                              // yaw_body
    0.0F,                              // yaw_sp_move_rate

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q_d

    {
      0.0F, 0.0F, 0.0F }
    ,                                  // thrust_body

    {
      0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Out1_Y0_k
  //  Referenced by: '<S12>/Out1'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // delta_q_reset
    0U,                                // quat_reset_counter

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_lh
  //  Referenced by: '<S8>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // q

    {
      0.0F, 0.0F, 0.0F, 0.0F }
    ,                                  // delta_q_reset
    0U,                                // quat_reset_counter

    {
      0U, 0U, 0U, 0U, 0U, 0U, 0U }
    // _padding0
  },

  // Computed Parameter: Constant_Value_h
  //  Referenced by: '<S51>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    // control
  },

  // Computed Parameter: Constant_Value_j
  //  Referenced by: '<S586>/Constant'

  {
    (0ULL),                            // timestamp
    (0ULL),                            // timestamp_sample

    {
      0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F }
    // control
  },

  // Computed Parameter: Out1_Y0_ke
  //  Referenced by: '<S48>/Out1'

  {
    (0ULL),                            // timestamp
    0.0,                               // lat
    0.0,                               // lon
    0.0F,                              // alt
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z
    0.0F,                              // yaw
    false,                             // valid_alt
    false,                             // valid_hpos
    false,                             // valid_lpos
    false                              // manual_home
  },

  // Computed Parameter: Constant_Value_nt
  //  Referenced by: '<S33>/Constant'

  {
    (0ULL),                            // timestamp
    0.0,                               // lat
    0.0,                               // lon
    0.0F,                              // alt
    0.0F,                              // x
    0.0F,                              // y
    0.0F,                              // z
    0.0F,                              // yaw
    false,                             // valid_alt
    false,                             // valid_hpos
    false,                             // valid_lpos
    false                              // manual_home
  },

  // Computed Parameter: Constant_Value_k
  //  Referenced by: '<S362>/Constant'

  {
    (0ULL),                            // timestamp
    0.0F,                              // roll
    0.0F,                              // pitch
    0.0F,                              // yaw

    {
      0.0F, 0.0F, 0.0F }
    // thrust_body
  },

  // Computed Parameter: Constant_Value_c
  //  Referenced by: '<S364>/Constant'

  {
    (0ULL),                            // timestamp
    0.0F,                              // rollspeed_integ
    0.0F,                              // pitchspeed_integ
    0.0F,                              // yawspeed_integ
    0.0F                               // additional_integ1
  },

  // Computed Parameter: Out1_Y0_d
  //  Referenced by: '<S11>/Out1'

  {
    (0ULL),                            // timestamp
    false,                             // armed
    false,                             // prearmed
    false,                             // ready_to_arm
    false,                             // lockdown
    false,                             // manual_lockdown
    false,                             // force_failsafe
    false,                             // in_esc_calibration_mode
    false                              // soft_stop
  },

  // Computed Parameter: Constant_Value_jl
  //  Referenced by: '<S7>/Constant'

  {
    (0ULL),                            // timestamp
    false,                             // armed
    false,                             // prearmed
    false,                             // ready_to_arm
    false,                             // lockdown
    false,                             // manual_lockdown
    false,                             // force_failsafe
    false,                             // in_esc_calibration_mode
    false                              // soft_stop
  },

  // Expression: 0
  //  Referenced by: '<S57>/Switch1'

  0.0,

  // Computed Parameter: tau_Yaw_Y0
  //  Referenced by: '<S53>/tau_Yaw'

  0.0,

  // Computed Parameter: tau_Pitch_Y0
  //  Referenced by: '<S53>/tau_Pitch'

  0.0,

  // Computed Parameter: tau_Roll_Y0
  //  Referenced by: '<S53>/tau_Roll'

  0.0,

  // Expression: 0
  //  Referenced by: '<S92>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S142>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S192>/Constant1'

  0.0,

  // Expression: 60*pi/180
  //  Referenced by: '<S53>/Rate Limiter1'

  1.0471975511965976,

  // Expression: -60*pi/180
  //  Referenced by: '<S53>/Rate Limiter1'

  -1.0471975511965976,

  // Expression: 0
  //  Referenced by: '<S53>/Rate Limiter1'

  0.0,

  // Expression: 60*pi/180
  //  Referenced by: '<S53>/Saturation'

  1.0471975511965976,

  // Expression: -50*pi/180
  //  Referenced by: '<S53>/Saturation'

  -0.87266462599716477,

  // Expression: 60*pi/180
  //  Referenced by: '<S53>/Rate Limiter2'

  1.0471975511965976,

  // Expression: -60*pi/180
  //  Referenced by: '<S53>/Rate Limiter2'

  -1.0471975511965976,

  // Expression: 0
  //  Referenced by: '<S53>/Rate Limiter2'

  0.0,

  // Expression: 60*pi/180
  //  Referenced by: '<S53>/Saturation1'

  1.0471975511965976,

  // Expression: -60*pi/180
  //  Referenced by: '<S53>/Saturation1'

  -1.0471975511965976,

  // Expression: 2*pi
  //  Referenced by: '<S57>/Constant'

  6.2831853071795862,

  // Expression: pi
  //  Referenced by: '<S57>/Switch'

  3.1415926535897931,

  // Computed Parameter: Integrator_gainval
  //  Referenced by: '<S101>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval
  //  Referenced by: '<S96>/Filter'

  0.01,

  // Expression: 0
  //  Referenced by: '<S92>/Clamping_zero'

  0.0,

  // Computed Parameter: Integrator_gainval_k
  //  Referenced by: '<S151>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval_p
  //  Referenced by: '<S146>/Filter'

  0.01,

  // Expression: 0
  //  Referenced by: '<S142>/Clamping_zero'

  0.0,

  // Computed Parameter: Integrator_gainval_i
  //  Referenced by: '<S201>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval_h
  //  Referenced by: '<S196>/Filter'

  0.01,

  // Expression: 0
  //  Referenced by: '<S192>/Clamping_zero'

  0.0,

  // Computed Parameter: DiscreteTimeIntegrator2_gainval
  //  Referenced by: '<S53>/Discrete-Time Integrator2'

  0.000335,

  // Expression: 0
  //  Referenced by: '<S53>/Discrete-Time Integrator2'

  0.0,

  // Computed Parameter: DiscreteTimeIntegrator1_gainval
  //  Referenced by: '<S53>/Discrete-Time Integrator1'

  0.00058240000000000006,

  // Expression: 0
  //  Referenced by: '<S53>/Discrete-Time Integrator1'

  0.0,

  // Computed Parameter: DiscreteTimeIntegrator_gainval
  //  Referenced by: '<S53>/Discrete-Time Integrator'

  0.001,

  // Expression: 0
  //  Referenced by: '<S53>/Discrete-Time Integrator'

  0.0,

  // Expression: 0
  //  Referenced by: '<S370>/Constant'

  0.0,

  // Computed Parameter: tau_Thrust_Y0
  //  Referenced by: '<S54>/tau_Thrust'

  0.0,

  // Computed Parameter: des_pitch_Y0
  //  Referenced by: '<S54>/des_pitch'

  0.0,

  // Computed Parameter: des_roll_Y0
  //  Referenced by: '<S54>/des_roll'

  0.0,

  // Expression: 0
  //  Referenced by: '<S497>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S547>/Constant1'

  0.0,

  // Expression: -1
  //  Referenced by: '<S370>/Gain1'

  -1.0,

  // Expression: 0
  //  Referenced by: '<S497>/Clamping_zero'

  0.0,

  // Computed Parameter: Filter_gainval_g
  //  Referenced by: '<S501>/Filter'

  0.01,

  // Computed Parameter: Integrator_gainval_a
  //  Referenced by: '<S506>/Integrator'

  0.01,

  // Expression: 0
  //  Referenced by: '<S547>/Clamping_zero'

  0.0,

  // Computed Parameter: Filter_gainval_k
  //  Referenced by: '<S551>/Filter'

  0.01,

  // Computed Parameter: Integrator_gainval_g
  //  Referenced by: '<S556>/Integrator'

  0.01,

  // Expression: -1
  //  Referenced by: '<S371>/Gain'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S54>/Gain1'

  -1.0,

  // Expression: [1 0 0 0]
  //  Referenced by: '<S55>/Constant'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S577>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S578>/Constant'

  1.0,

  // Expression: 0
  //  Referenced by: '<S55>/Switch'

  0.0,

  // Expression: -1
  //  Referenced by: '<S50>/Gain'

  -1.0,

  // Expression: zeros(4,1)
  //  Referenced by: '<S3>/Constant'

  { 0.0, 0.0, 0.0, 0.0 },

  // Computed Parameter: tau_Yaw_Y0_g
  //  Referenced by: '<S584>/tau_Yaw'

  0.0,

  // Computed Parameter: tau_Pitch_Y0_j
  //  Referenced by: '<S584>/tau_Pitch'

  0.0,

  // Computed Parameter: tau_Roll_Y0_j
  //  Referenced by: '<S584>/tau_Roll'

  0.0,

  // Expression: 0
  //  Referenced by: '<S625>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S675>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S725>/Constant1'

  0.0,

  // Expression: 0
  //  Referenced by: '<S625>/Clamping_zero'

  0.0,

  // Computed Parameter: Integrator_gainval_c
  //  Referenced by: '<S634>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval_c
  //  Referenced by: '<S629>/Filter'

  0.01,

  // Expression: 40*pi/180
  //  Referenced by: '<S584>/Rate Limiter2'

  0.69813170079773179,

  // Expression: -40*pi/180
  //  Referenced by: '<S584>/Rate Limiter2'

  -0.69813170079773179,

  // Expression: 0
  //  Referenced by: '<S584>/Rate Limiter2'

  0.0,

  // Expression: 20*pi/180
  //  Referenced by: '<S584>/Saturation1'

  0.3490658503988659,

  // Expression: -20*pi/180
  //  Referenced by: '<S584>/Saturation1'

  -0.3490658503988659,

  // Expression: 0
  //  Referenced by: '<S675>/Clamping_zero'

  0.0,

  // Computed Parameter: Integrator_gainval_iw
  //  Referenced by: '<S684>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval_pb
  //  Referenced by: '<S679>/Filter'

  0.01,

  // Expression: 40*pi/180
  //  Referenced by: '<S584>/Rate Limiter1'

  0.69813170079773179,

  // Expression: -40*pi/180
  //  Referenced by: '<S584>/Rate Limiter1'

  -0.69813170079773179,

  // Expression: 0
  //  Referenced by: '<S584>/Rate Limiter1'

  0.0,

  // Expression: 20*pi/180
  //  Referenced by: '<S584>/Saturation'

  0.3490658503988659,

  // Expression: -20*pi/180
  //  Referenced by: '<S584>/Saturation'

  -0.3490658503988659,

  // Expression: 0
  //  Referenced by: '<S725>/Clamping_zero'

  0.0,

  // Computed Parameter: Integrator_gainval_f
  //  Referenced by: '<S734>/Integrator'

  0.01,

  // Computed Parameter: Filter_gainval_ga
  //  Referenced by: '<S729>/Filter'

  0.01,

  // Expression: [1 0 0 0]
  //  Referenced by: '<S589>/Constant'

  { 1.0, 0.0, 0.0, 0.0 },

  // Expression: 1
  //  Referenced by: '<S901>/Constant'

  1.0,

  // Expression: 1
  //  Referenced by: '<S902>/Constant'

  1.0,

  // Expression: 0
  //  Referenced by: '<S589>/Switch'

  0.0,

  // Expression: 0.3
  //  Referenced by: '<S5>/Gain3'

  0.3,

  // Expression: zeros(4,1)
  //  Referenced by: '<S5>/Constant'

  { 0.0, 0.0, 0.0, 0.0 },

  // Computed Parameter: yaw_Out_Y0
  //  Referenced by: '<S28>/yaw_Out'

  0.0,

  // Expression: 0.0
  //  Referenced by: '<S26>/Delay'

  0.0,

  // Expression: 0.01
  //  Referenced by: '<S26>/Rate'

  0.01,

  // Expression: -1
  //  Referenced by: '<S26>/Gain1'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S26>/Gain'

  -1.0,

  // Expression: 1
  //  Referenced by: '<S27>/Delay'

  1.0,

  // Expression: 0
  //  Referenced by: '<S27>/Constant'

  0.0,

  // Computed Parameter: Out_Y0
  //  Referenced by: '<S24>/Out'

  0.0,

  // Expression: -1
  //  Referenced by: '<S22>/Gain'

  -1.0,

  // Computed Parameter: yaw_Out_Y0_k
  //  Referenced by: '<S25>/yaw_Out'

  0.0,

  // Expression: 0.0
  //  Referenced by: '<S17>/Delay'

  0.0,

  // Expression: 0.0
  //  Referenced by: '<S22>/Delay'

  0.0,

  // Expression: 0
  //  Referenced by: '<S22>/Switch'

  0.0,

  // Expression: 0.02
  //  Referenced by: '<S22>/Rate of descent'

  0.02,

  // Expression: -1
  //  Referenced by: '<S22>/Gain2'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S22>/Gain1'

  -1.0,

  // Expression: 1
  //  Referenced by: '<S23>/Delay'

  1.0,

  // Expression: 0
  //  Referenced by: '<S23>/Constant'

  0.0,

  // Expression: 0
  //  Referenced by: '<S29>/Constant'

  0.0,

  // Expression: 6
  //  Referenced by: '<S19>/Constant'

  6.0,

  // Computed Parameter: yaw_Out_Y0_g
  //  Referenced by: '<S21>/yaw_Out'

  0.0,

  // Expression: 1
  //  Referenced by: '<S20>/Delay'

  1.0,

  // Expression: 0
  //  Referenced by: '<S20>/Constant'

  0.0,

  // Expression: -1
  //  Referenced by: '<S15>/Read Parameter'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S47>/Read Parameter'

  -1.0,

  // Expression: -1
  //  Referenced by: '<S46>/Read Parameter'

  -1.0,

  // Computed Parameter: Constant7_Value
  //  Referenced by: '<S40>/Constant7'

  (0ULL),

  // Computed Parameter: Constant2_Value
  //  Referenced by: '<S53>/Constant2'

  { 0.0F, 0.0F, 0.0F, 0.0F },

  // Computed Parameter: Constant1_Value_i
  //  Referenced by: '<S53>/Constant1'

  { 0.0F, 0.0F, 0.0F },

  // Computed Parameter: Constant4_Value
  //  Referenced by: '<S53>/Constant4'

  0.0F,

  // Computed Parameter: Constant_Value_c0
  //  Referenced by: '<S53>/Constant'

  0.0F,

  // Computed Parameter: Bias_Bias
  //  Referenced by: '<S588>/Bias'

  -1500.0F,

  // Computed Parameter: Gain_Gain_b
  //  Referenced by: '<S588>/Gain'

  0.002F,

  // Computed Parameter: Gain1_Gain_j
  //  Referenced by: '<S5>/Gain1'

  0.4F,

  // Computed Parameter: Bias_Bias_o
  //  Referenced by: '<S591>/Bias'

  -1500.0F,

  // Computed Parameter: Gain_Gain_o
  //  Referenced by: '<S591>/Gain'

  0.002F,

  // Computed Parameter: Gain_Gain_d
  //  Referenced by: '<S5>/Gain'

  1.0F,

  // Computed Parameter: Bias_Bias_e
  //  Referenced by: '<S593>/Bias'

  -1498.0F,

  // Computed Parameter: Gain_Gain_m
  //  Referenced by: '<S593>/Gain'

  0.002F,

  // Computed Parameter: Bias_Bias_m
  //  Referenced by: '<S592>/Bias'

  -1000.0F,

  // Computed Parameter: Gain_Gain_k
  //  Referenced by: '<S592>/Gain'

  0.001F,

  // Computed Parameter: Gain2_Gain_k
  //  Referenced by: '<S5>/Gain2'

  1.0F,

  // Computed Parameter: Constant1_Value_e3
  //  Referenced by: '<S47>/Constant1'

  { 0.0F, 0.0F },

  // Computed Parameter: Constant_Value_kl
  //  Referenced by: '<S47>/Constant'

  0.0F,

  // Computed Parameter: Gain_Gain_g
  //  Referenced by: '<S46>/Gain'

  -1.0F,

  // Computed Parameter: Constant1_Value_k
  //  Referenced by: '<S46>/Constant1'

  { 0.0F, 0.0F },

  // Computed Parameter: Constant_Value_co
  //  Referenced by: '<S46>/Constant'

  0.0F,

  // Computed Parameter: Constant_Value_ps
  //  Referenced by: '<S40>/Constant'

  { 0.0F, 0.0F, 0.0F },

  // Computed Parameter: Constant1_Value_d
  //  Referenced by: '<S40>/Constant1'

  { 0.0F, 0.0F, 0.0F },

  // Computed Parameter: Constant2_Value_b
  //  Referenced by: '<S40>/Constant2'

  { 0.0F, 0.0F, 0.0F },

  // Computed Parameter: Constant3_Value
  //  Referenced by: '<S40>/Constant3'

  0.0F,

  // Computed Parameter: Constant4_Value_p
  //  Referenced by: '<S40>/Constant4'

  0.0F,

  // Computed Parameter: Constant5_Value
  //  Referenced by: '<S38>/Constant5'

  true,

  // Computed Parameter: Constant5_Value_m
  //  Referenced by: '<S39>/Constant5'

  true,

  // Computed Parameter: Constant1_Value_a2
  //  Referenced by: '<S41>/Constant1'

  true,

  // Computed Parameter: Constant5_Value_k
  //  Referenced by: '<S41>/Constant5'

  true,

  // Computed Parameter: Constant5_Value_e
  //  Referenced by: '<S40>/Constant5'

  false,

  // Computed Parameter: Constant_Value_kt
  //  Referenced by: '<S92>/Constant'

  1,

  // Computed Parameter: Constant2_Value_e
  //  Referenced by: '<S92>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_g
  //  Referenced by: '<S92>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_j
  //  Referenced by: '<S92>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_hp
  //  Referenced by: '<S142>/Constant'

  1,

  // Computed Parameter: Constant2_Value_f
  //  Referenced by: '<S142>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_c
  //  Referenced by: '<S142>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_e
  //  Referenced by: '<S142>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_is
  //  Referenced by: '<S192>/Constant'

  1,

  // Computed Parameter: Constant2_Value_a
  //  Referenced by: '<S192>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_b
  //  Referenced by: '<S192>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_k
  //  Referenced by: '<S192>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_hk
  //  Referenced by: '<S497>/Constant'

  1,

  // Computed Parameter: Constant2_Value_l
  //  Referenced by: '<S497>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_gn
  //  Referenced by: '<S497>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_g
  //  Referenced by: '<S497>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_mp
  //  Referenced by: '<S547>/Constant'

  1,

  // Computed Parameter: Constant2_Value_k
  //  Referenced by: '<S547>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_i
  //  Referenced by: '<S547>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_ja
  //  Referenced by: '<S547>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_dj
  //  Referenced by: '<S625>/Constant'

  1,

  // Computed Parameter: Constant2_Value_bl
  //  Referenced by: '<S625>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_k
  //  Referenced by: '<S625>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_l
  //  Referenced by: '<S625>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_p5
  //  Referenced by: '<S675>/Constant'

  1,

  // Computed Parameter: Constant2_Value_n
  //  Referenced by: '<S675>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_o
  //  Referenced by: '<S675>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_ly
  //  Referenced by: '<S675>/Constant4'

  -1,

  // Computed Parameter: Constant_Value_c4
  //  Referenced by: '<S725>/Constant'

  1,

  // Computed Parameter: Constant2_Value_nn
  //  Referenced by: '<S725>/Constant2'

  -1,

  // Computed Parameter: Constant3_Value_ie
  //  Referenced by: '<S725>/Constant3'

  1,

  // Computed Parameter: Constant4_Value_d
  //  Referenced by: '<S725>/Constant4'

  -1,

  // Computed Parameter: Constant3_Value_m
  //  Referenced by: '<S53>/Constant3'

  { 0U, 0U, 0U, 0U },

  // Computed Parameter: Constant_Value_cc
  //  Referenced by: '<S32>/Constant'

  0U,

  // Computed Parameter: Constant6_Value
  //  Referenced by: '<S40>/Constant6'

  255U
};

//
// File trailer for generated code.
//
// [EOF]
//
