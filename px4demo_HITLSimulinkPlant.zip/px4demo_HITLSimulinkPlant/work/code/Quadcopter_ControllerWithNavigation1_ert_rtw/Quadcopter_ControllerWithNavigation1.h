//
// File: Quadcopter_ControllerWithNavigation1.h
//
// Code generated for Simulink model 'Quadcopter_ControllerWithNavigation1'.
//
// Model version                  : 4.12
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Wed Apr  3 23:18:28 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_Quadcopter_ControllerWithNavigation1_h_
#define RTW_HEADER_Quadcopter_ControllerWithNavigation1_h_
#include <poll.h>
#include <uORB/uORB.h>
#include <drivers/drv_hrt.h>
#include "rtwtypes.h"
#include "MW_uORB_Read.h"
#include "MW_uORB_Write.h"
#include "MW_Parameter.h"
#include "MW_ParameterRead.h"
#include "Quadcopter_ControllerWithNavigation1_types.h"
#include <uORB/topics/vehicle_trajectory_waypoint.h>
#include <uORB/topics/vehicle_odometry.h>
#include <uORB/topics/position_setpoint_triplet.h>
#include <uORB/topics/vehicle_local_position.h>
#include <uORB/topics/input_rc.h>
#include <uORB/topics/vehicle_attitude_setpoint.h>
#include <uORB/topics/vehicle_attitude.h>
#include <uORB/topics/trajectory_waypoint.h>
#include <uORB/topics/vehAttSet.h>
#include <uORB/topics/home_position.h>
#include <uORB/topics/actuator_controls.h>
#include <uORB/topics/vehicle_rates_setpoint.h>
#include <uORB/topics/rate_ctrl_status.h>
#include <uORB/topics/actuator_armed.h>

extern "C"
{

#include "rt_nonfinite.h"

}

extern "C"
{

#include "rtGetNaN.h"

}

#include <stddef.h>

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

// Block signals for system '<S64>/PX4 Timestamp'
struct B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T {
  uint64_T PX4Timestamp;               // '<S64>/PX4 Timestamp'
};

// Block states (default storage) for system '<S64>/PX4 Timestamp'
struct DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T {
  px4_internal_block_getPX4AbsoluteTime_Quadcopter_ControllerWi_T obj;// '<S64>/PX4 Timestamp' 
  boolean_T objisempty;                // '<S64>/PX4 Timestamp'
};

// Block states (default storage) for system '<S369>/SinkBlock'
struct DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T {
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj;// '<S369>/SinkBlock' 
  boolean_T objisempty;                // '<S369>/SinkBlock'
};

// Block states (default storage) for system '<S52>/SinkBlock'
struct DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T {
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj;// '<S52>/SinkBlock' 
  boolean_T objisempty;                // '<S52>/SinkBlock'
};

// Block signals for system '<S38>/MATLAB System'
struct B_MATLABSystem_Quadcopter_ControllerWithNavigation1_T {
  real32_T MATLABSystem[3];            // '<S38>/MATLAB System'
  real_T dLat;
};

// Block states (default storage) for system '<S38>/MATLAB System'
struct DW_MATLABSystem_Quadcopter_ControllerWithNavigation1_T {
  px4_internal_block_LLA2LocalCoordinatesNED_Quadcopter_Control_T obj;// '<S38>/MATLAB System' 
  boolean_T objisempty;                // '<S38>/MATLAB System'
};

// Block signals (default storage)
struct B_Quadcopter_ControllerWithNavigation1_T {
  px4_Bus_vehicle_trajectory_waypoint In1;// '<S37>/In1'
  px4_Bus_vehicle_trajectory_waypoint b_varargout_2;
  px4_Bus_vehicle_trajectory_waypoint BusAssignment1;// '<S32>/Bus Assignment1'
  px4_Bus_vehicle_trajectory_waypoint BusAssignment1_m;// '<S32>/Bus Assignment1' 
  px4_Bus_vehicle_odometry In1_l;      // '<S10>/In1'
  px4_Bus_vehicle_odometry b_varargout_2_c;
  px4_Bus_position_setpoint_triplet In1_g;// '<S49>/In1'
  px4_Bus_position_setpoint_triplet b_varargout_2_k;
  px4_Bus_vehicle_local_position In1_c;// '<S13>/In1'
  px4_Bus_vehicle_local_position b_varargout_2_cx;
  px4_Bus_input_rc In1_d;              // '<S583>/In1'
  px4_Bus_input_rc b_varargout_2_b;
  real_T b_waypointsIn_data[9];
  real_T MatrixConcatenate_a[9];       // '<S19>/Matrix Concatenate'
  px4_Bus_vehicle_attitude_setpoint BusAssignment_p;// '<S67>/Bus Assignment'
  px4_Bus_vehicle_attitude_setpoint BusAssignment_b;// '<S585>/Bus Assignment'
  px4_Bus_vehicle_attitude In1_m;      // '<S12>/In1'
  px4_Bus_vehicle_attitude b_varargout_2_p;
  px4_Bus_trajectory_waypoint BusAssignment1_d;// '<S40>/Bus Assignment1'
  px4_Bus_vehAttSet BusAssignment_bp;  // '<S66>/Bus Assignment'
  px4_Bus_vehAttSet BusAssignment_bp_c;// '<S66>/Bus Assignment'
  px4_Bus_home_position In1_o;         // '<S48>/In1'
  px4_Bus_home_position b_varargout_2_f;
  px4_Bus_actuator_controls BusAssignment_e;// '<S5>/Bus Assignment'
  px4_Bus_actuator_controls BusAssignment_g;// '<S3>/Bus Assignment'
  px4_Bus_vehicle_rates_setpoint BusAssignment_c;// '<S64>/Bus Assignment'
  px4_Bus_rate_ctrl_status BusAssignment_n;// '<S65>/Bus Assignment'
  real_T b_varargout_3[3];
  real_T lla0[3];
  real_T DataTypeConversion2[3];       // '<S1>/Data Type Conversion2'
  real_T VectorConcatenate_p[3];       // '<S574>/Vector Concatenate'
  real_T rtb_DataTypeConversion_g[3];
  px4_Bus_actuator_armed In1_b;        // '<S11>/In1'
  px4_Bus_actuator_armed b_varargout_2_g;
  real_T yaw_In;                       // '<S21>/yaw_In'
  real_T yaw_In_i;                     // '<S25>/yaw_In'
  real_T In;                           // '<S24>/In'
  real_T yaw_In_ik;                    // '<S28>/yaw_In'
  real_T Saturation;                   // '<S641>/Saturation'
  real_T Saturation_i;                 // '<S691>/Saturation'
  real_T Saturation_g;                 // '<S741>/Saturation'
  real_T Saturation_d;                 // '<S563>/Saturation'
  real_T Saturation_h;                 // '<S108>/Saturation'
  real_T Saturation_c;                 // '<S158>/Saturation'
  real_T Saturation_d2;                // '<S208>/Saturation'
  real_T dist;
  real_T Subtract;                     // '<S22>/Subtract'
  real_T Product2;                     // '<S899>/Product2'
  real_T Gain1;                        // '<S370>/Gain1'
  real_T Filter_l;                     // '<S551>/Filter'
  real_T SinCos_o2;                    // '<S371>/SinCos'
  real_T Integrator_a;                 // '<S734>/Integrator'
  real_T SinCos_o1;                    // '<S371>/SinCos'
  real_T rtb_Merge_idx_3;
  real_T rtb_Merge_idx_2;
  real_T rtb_DataTypeConversion_idx_3;
  real_T rtb_DataTypeConversion_idx_1;
  real_T rtb_DataTypeConversion_idx_2;
  real_T rtb_Merge_idx_0;
  real_T rtb_Merge_idx_1;
  real_T rtb_VectorConcatenate_p_tmp;
  real_T rtb_VectorConcatenate_p_tmp_m;
  real_T dLat;
  real_T dLon;
  real_T Rn;
  real_T flat;
  real_T b_x;
  real_T absx;
  real_T absx_n;
  real_T q;
  real_T scale;
  real_T absxk;
  real_T t;
  boolean_T x[6];
  real32_T ParamStep;
  int32_T ParamStep_p;
  int32_T i2;
  int32_T i1;
  int32_T j;
  int32_T ix;
  int32_T b_exponent;
  int32_T b_exponent_l;
  int32_T waypoints_size_idx_0;
  int32_T b_k;
  int32_T i;
  int32_T i1_j;
  int8_T tmp_data[3];
  boolean_T distinctWptsIdx[3];
  boolean_T b[3];
  boolean_T IsNaN_b[2];                // '<S17>/IsNaN'
  int8_T rtPrevAction;
  int8_T i2_d;
  int8_T i3;
  int8_T i4;
  boolean_T RelationalOperator_h;      // '<S625>/Relational Operator'
  boolean_T RelationalOperator_b;      // '<S675>/Relational Operator'
  boolean_T RelationalOperator_c;      // '<S142>/Relational Operator'
  boolean_T fixforDTpropagationissue_ne;// '<S142>/fix for DT propagation issue' 
  boolean_T RelationalOperator_a;      // '<S192>/Relational Operator'
  boolean_T fixforDTpropagationissue_bu;// '<S192>/fix for DT propagation issue' 
  boolean_T latp2;
  B_MATLABSystem_Quadcopter_ControllerWithNavigation1_T MATLABSystem_p;// '<S38>/MATLAB System' 
  B_MATLABSystem_Quadcopter_ControllerWithNavigation1_T MATLABSystem;// '<S38>/MATLAB System' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp;// '<S64>/PX4 Timestamp' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_c;// '<S64>/PX4 Timestamp' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_d;// '<S64>/PX4 Timestamp' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_k;// '<S64>/PX4 Timestamp' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_h;// '<S64>/PX4 Timestamp' 
  B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_b;// '<S64>/PX4 Timestamp' 
};

// Block states (default storage) for system '<Root>'
struct DW_Quadcopter_ControllerWithNavigation1_T {
  uav_sluav_internal_system_WaypointFollower_Quadcopter_Control_T obj;// '<S19>/UAV Waypoint Follower' 
  px4_internal_block_ParameterUpdate_Quadcopter_ControllerWithN_T obj_d;// '<S46>/Read Parameter' 
  px4_internal_block_ParameterUpdate_Quadcopter_ControllerWithN_T obj_j;// '<S47>/Read Parameter' 
  px4_internal_block_ParameterUpdate_Quadcopter_ControllerWithN_T obj_p;// '<S15>/Read Parameter' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_n;// '<S582>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_b;// '<S34>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_h;// '<S33>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_l;// '<S36>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_m;// '<S9>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_g;// '<S8>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_d0;// '<S7>/SourceBlock' 
  px4_internal_block_Subscriber_Quadcopter_ControllerWithNaviga_T obj_po;// '<S6>/SourceBlock' 
  px4_internal_block_LLA2LocalCoordinates_Quadcopter_Controller_T obj_i;// '<S15>/LLA2LocalCoordinates' 
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj_gj;// '<S43>/SinkBlock' 
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj_a;// '<S367>/SinkBlock' 
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj_gk;// '<S365>/SinkBlock' 
  px4_internal_block_Publisher_Quadcopter_ControllerWithNavigat_T obj_jr;// '<S363>/SinkBlock' 
  real_T Delay_DSTATE;                 // '<S20>/Delay'
  real_T Delay_DSTATE_o[2];            // '<S17>/Delay'
  real_T Delay_DSTATE_g;               // '<S22>/Delay'
  real_T Delay_DSTATE_e;               // '<S23>/Delay'
  real_T Delay_DSTATE_i;               // '<S26>/Delay'
  real_T Delay_DSTATE_n;               // '<S27>/Delay'
  real_T Integrator_DSTATE;            // '<S634>/Integrator'
  real_T Filter_DSTATE;                // '<S629>/Filter'
  real_T Integrator_DSTATE_p;          // '<S684>/Integrator'
  real_T Filter_DSTATE_i;              // '<S679>/Filter'
  real_T Integrator_DSTATE_b;          // '<S734>/Integrator'
  real_T Filter_DSTATE_h;              // '<S729>/Filter'
  real_T Filter_DSTATE_ij;             // '<S501>/Filter'
  real_T Integrator_DSTATE_a;          // '<S506>/Integrator'
  real_T Filter_DSTATE_m;              // '<S551>/Filter'
  real_T Integrator_DSTATE_c;          // '<S556>/Integrator'
  real_T Integrator_DSTATE_h;          // '<S101>/Integrator'
  real_T Filter_DSTATE_f;              // '<S96>/Filter'
  real_T Integrator_DSTATE_o;          // '<S151>/Integrator'
  real_T Filter_DSTATE_n;              // '<S146>/Filter'
  real_T Integrator_DSTATE_i;          // '<S201>/Integrator'
  real_T Filter_DSTATE_k;              // '<S196>/Filter'
  real_T DiscreteTimeIntegrator2_DSTATE;// '<S53>/Discrete-Time Integrator2'
  real_T DiscreteTimeIntegrator1_DSTATE;// '<S53>/Discrete-Time Integrator1'
  real_T DiscreteTimeIntegrator_DSTATE;// '<S53>/Discrete-Time Integrator'
  real_T PrevY;                        // '<S584>/Rate Limiter2'
  real_T PrevY_m;                      // '<S584>/Rate Limiter1'
  real_T PrevY_b;                      // '<S53>/Rate Limiter1'
  real_T PrevY_g;                      // '<S53>/Rate Limiter2'
  px4_internal_block_LLA2LocalCoordinatesNED_Quadcopter_Control_T obj_ls;// '<S41>/MATLAB System' 
  int8_T If_ActiveSubsystem;           // '<S14>/If'
  DW_MATLABSystem_Quadcopter_ControllerWithNavigation1_T MATLABSystem_p;// '<S38>/MATLAB System' 
  DW_MATLABSystem_Quadcopter_ControllerWithNavigation1_T MATLABSystem;// '<S38>/MATLAB System' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp;// '<S64>/PX4 Timestamp' 
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T SinkBlock_k;// '<S52>/SinkBlock' 
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T SinkBlock_g;// '<S369>/SinkBlock' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_c;// '<S64>/PX4 Timestamp' 
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T SinkBlock;// '<S52>/SinkBlock' 
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T SinkBlock_c;// '<S369>/SinkBlock' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_d;// '<S64>/PX4 Timestamp' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_k;// '<S64>/PX4 Timestamp' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_h;// '<S64>/PX4 Timestamp' 
  DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T PX4Timestamp_b;// '<S64>/PX4 Timestamp' 
};

// Parameters (default storage)
struct P_Quadcopter_ControllerWithNavigation1_T_ {
  real_T pitchP;                       // Variable: pitchP
                                          //  Referenced by: '<S254>/Proportional Gain'

  real_T pitchRateD;                   // Variable: pitchRateD
                                          //  Referenced by: '<S145>/Derivative Gain'

  real_T pitchRateI;                   // Variable: pitchRateI
                                          //  Referenced by: '<S148>/Integral Gain'

  real_T pitchRateP;                   // Variable: pitchRateP
                                          //  Referenced by: '<S156>/Proportional Gain'

  real_T rollP;                        // Variable: rollP
                                          //  Referenced by: '<S302>/Proportional Gain'

  real_T rollRateD;                    // Variable: rollRateD
                                          //  Referenced by: '<S195>/Derivative Gain'

  real_T rollRateI;                    // Variable: rollRateI
                                          //  Referenced by: '<S198>/Integral Gain'

  real_T rollRateP;                    // Variable: rollRateP
                                          //  Referenced by: '<S206>/Proportional Gain'

  real_T yawRateD;                     // Variable: yawRateD
                                          //  Referenced by: '<S95>/Derivative Gain'

  real_T yawRateI;                     // Variable: yawRateI
                                          //  Referenced by: '<S98>/Integral Gain'

  real_T yawRateP;                     // Variable: yawRateP
                                          //  Referenced by: '<S106>/Proportional Gain'

  real_T PID_Altitude_D;               // Mask Parameter: PID_Altitude_D
                                          //  Referenced by: '<S500>/Derivative Gain'

  real_T PID_vz_D;                     // Mask Parameter: PID_vz_D
                                          //  Referenced by: '<S550>/Derivative Gain'

  real_T PIDController_D;              // Mask Parameter: PIDController_D
                                          //  Referenced by: '<S628>/Derivative Gain'

  real_T PIDController1_D;             // Mask Parameter: PIDController1_D
                                          //  Referenced by: '<S678>/Derivative Gain'

  real_T PIDController2_D;             // Mask Parameter: PIDController2_D
                                          //  Referenced by: '<S728>/Derivative Gain'

  real_T PID_Altitude_I;               // Mask Parameter: PID_Altitude_I
                                          //  Referenced by: '<S503>/Integral Gain'

  real_T PID_vz_I;                     // Mask Parameter: PID_vz_I
                                          //  Referenced by: '<S553>/Integral Gain'

  real_T PIDController_I;              // Mask Parameter: PIDController_I
                                          //  Referenced by: '<S631>/Integral Gain'

  real_T PIDController1_I;             // Mask Parameter: PIDController1_I
                                          //  Referenced by: '<S681>/Integral Gain'

  real_T PIDController2_I;             // Mask Parameter: PIDController2_I
                                          //  Referenced by: '<S731>/Integral Gain'

  real_T PIDController_InitialConditionForFilter;
                      // Mask Parameter: PIDController_InitialConditionForFilter
                         //  Referenced by: '<S96>/Filter'

  real_T PIDController1_InitialConditionForFilter;
                     // Mask Parameter: PIDController1_InitialConditionForFilter
                        //  Referenced by: '<S146>/Filter'

  real_T PIDController2_InitialConditionForFilter;
                     // Mask Parameter: PIDController2_InitialConditionForFilter
                        //  Referenced by: '<S196>/Filter'

  real_T PID_Altitude_InitialConditionForFilter;
                       // Mask Parameter: PID_Altitude_InitialConditionForFilter
                          //  Referenced by: '<S501>/Filter'

  real_T PID_vz_InitialConditionForFilter;
                             // Mask Parameter: PID_vz_InitialConditionForFilter
                                //  Referenced by: '<S551>/Filter'

  real_T PIDController_InitialConditionForFilter_o;
                    // Mask Parameter: PIDController_InitialConditionForFilter_o
                       //  Referenced by: '<S629>/Filter'

  real_T PIDController1_InitialConditionForFilter_k;
                   // Mask Parameter: PIDController1_InitialConditionForFilter_k
                      //  Referenced by: '<S679>/Filter'

  real_T PIDController2_InitialConditionForFilter_m;
                   // Mask Parameter: PIDController2_InitialConditionForFilter_m
                      //  Referenced by: '<S729>/Filter'

  real_T PIDController_InitialConditionForIntegrator;
                  // Mask Parameter: PIDController_InitialConditionForIntegrator
                     //  Referenced by: '<S101>/Integrator'

  real_T PIDController1_InitialConditionForIntegrator;
                 // Mask Parameter: PIDController1_InitialConditionForIntegrator
                    //  Referenced by: '<S151>/Integrator'

  real_T PIDController2_InitialConditionForIntegrator;
                 // Mask Parameter: PIDController2_InitialConditionForIntegrator
                    //  Referenced by: '<S201>/Integrator'

  real_T PID_Altitude_InitialConditionForIntegrator;
                   // Mask Parameter: PID_Altitude_InitialConditionForIntegrator
                      //  Referenced by: '<S506>/Integrator'

  real_T PID_vz_InitialConditionForIntegrator;
                         // Mask Parameter: PID_vz_InitialConditionForIntegrator
                            //  Referenced by: '<S556>/Integrator'

  real_T PIDController_InitialConditionForIntegrator_g;
                // Mask Parameter: PIDController_InitialConditionForIntegrator_g
                   //  Referenced by: '<S634>/Integrator'

  real_T PIDController1_InitialConditionForIntegrator_i;
               // Mask Parameter: PIDController1_InitialConditionForIntegrator_i
                  //  Referenced by: '<S684>/Integrator'

  real_T PIDController2_InitialConditionForIntegrator_e;
               // Mask Parameter: PIDController2_InitialConditionForIntegrator_e
                  //  Referenced by: '<S734>/Integrator'

  real_T PIDController5_LowerSaturationLimit;
                          // Mask Parameter: PIDController5_LowerSaturationLimit
                             //  Referenced by: '<S352>/Saturation'

  real_T PIDController_LowerSaturationLimit;
                           // Mask Parameter: PIDController_LowerSaturationLimit
                              //  Referenced by:
                              //    '<S108>/Saturation'
                              //    '<S94>/DeadZone'

  real_T PIDController1_LowerSaturationLimit;
                          // Mask Parameter: PIDController1_LowerSaturationLimit
                             //  Referenced by:
                             //    '<S158>/Saturation'
                             //    '<S144>/DeadZone'

  real_T PIDController2_LowerSaturationLimit;
                          // Mask Parameter: PIDController2_LowerSaturationLimit
                             //  Referenced by:
                             //    '<S208>/Saturation'
                             //    '<S194>/DeadZone'

  real_T PID_Altitude_LowerSaturationLimit;
                            // Mask Parameter: PID_Altitude_LowerSaturationLimit
                               //  Referenced by:
                               //    '<S513>/Saturation'
                               //    '<S499>/DeadZone'

  real_T PID_vz_LowerSaturationLimit;
                                  // Mask Parameter: PID_vz_LowerSaturationLimit
                                     //  Referenced by:
                                     //    '<S563>/Saturation'
                                     //    '<S549>/DeadZone'

  real_T PIDController1_LowerSaturationLimit_j;
                        // Mask Parameter: PIDController1_LowerSaturationLimit_j
                           //  Referenced by: '<S463>/Saturation'

  real_T PIDController_LowerSaturationLimit_f;
                         // Mask Parameter: PIDController_LowerSaturationLimit_f
                            //  Referenced by: '<S415>/Saturation'

  real_T PIDController5_LowerSaturationLimit_g;
                        // Mask Parameter: PIDController5_LowerSaturationLimit_g
                           //  Referenced by: '<S885>/Saturation'

  real_T PIDController_LowerSaturationLimit_f4;
                        // Mask Parameter: PIDController_LowerSaturationLimit_f4
                           //  Referenced by:
                           //    '<S641>/Saturation'
                           //    '<S627>/DeadZone'

  real_T PIDController1_LowerSaturationLimit_p;
                        // Mask Parameter: PIDController1_LowerSaturationLimit_p
                           //  Referenced by:
                           //    '<S691>/Saturation'
                           //    '<S677>/DeadZone'

  real_T PIDController2_LowerSaturationLimit_f;
                        // Mask Parameter: PIDController2_LowerSaturationLimit_f
                           //  Referenced by:
                           //    '<S741>/Saturation'
                           //    '<S727>/DeadZone'

  real_T PIDController_N;              // Mask Parameter: PIDController_N
                                          //  Referenced by: '<S104>/Filter Coefficient'

  real_T PIDController1_N;             // Mask Parameter: PIDController1_N
                                          //  Referenced by: '<S154>/Filter Coefficient'

  real_T PIDController2_N;             // Mask Parameter: PIDController2_N
                                          //  Referenced by: '<S204>/Filter Coefficient'

  real_T PID_Altitude_N;               // Mask Parameter: PID_Altitude_N
                                          //  Referenced by: '<S509>/Filter Coefficient'

  real_T PID_vz_N;                     // Mask Parameter: PID_vz_N
                                          //  Referenced by: '<S559>/Filter Coefficient'

  real_T PIDController_N_h;            // Mask Parameter: PIDController_N_h
                                          //  Referenced by: '<S637>/Filter Coefficient'

  real_T PIDController1_N_e;           // Mask Parameter: PIDController1_N_e
                                          //  Referenced by: '<S687>/Filter Coefficient'

  real_T PIDController2_N_p;           // Mask Parameter: PIDController2_N_p
                                          //  Referenced by: '<S737>/Filter Coefficient'

  real_T PIDController5_P;             // Mask Parameter: PIDController5_P
                                          //  Referenced by: '<S350>/Proportional Gain'

  real_T PID_Altitude_P;               // Mask Parameter: PID_Altitude_P
                                          //  Referenced by: '<S511>/Proportional Gain'

  real_T PID_vz_P;                     // Mask Parameter: PID_vz_P
                                          //  Referenced by: '<S561>/Proportional Gain'

  real_T PIDController1_P;             // Mask Parameter: PIDController1_P
                                          //  Referenced by: '<S461>/Proportional Gain'

  real_T PIDController_P;              // Mask Parameter: PIDController_P
                                          //  Referenced by: '<S413>/Proportional Gain'

  real_T PIDController5_P_d;           // Mask Parameter: PIDController5_P_d
                                          //  Referenced by: '<S883>/Proportional Gain'

  real_T PIDController_P_j;            // Mask Parameter: PIDController_P_j
                                          //  Referenced by: '<S639>/Proportional Gain'

  real_T PIDController3_P;             // Mask Parameter: PIDController3_P
                                          //  Referenced by: '<S787>/Proportional Gain'

  real_T PIDController1_P_e;           // Mask Parameter: PIDController1_P_e
                                          //  Referenced by: '<S689>/Proportional Gain'

  real_T PIDController4_P;             // Mask Parameter: PIDController4_P
                                          //  Referenced by: '<S835>/Proportional Gain'

  real_T PIDController2_P;             // Mask Parameter: PIDController2_P
                                          //  Referenced by: '<S739>/Proportional Gain'

  real_T PIDController5_UpperSaturationLimit;
                          // Mask Parameter: PIDController5_UpperSaturationLimit
                             //  Referenced by: '<S352>/Saturation'

  real_T PIDController_UpperSaturationLimit;
                           // Mask Parameter: PIDController_UpperSaturationLimit
                              //  Referenced by:
                              //    '<S108>/Saturation'
                              //    '<S94>/DeadZone'

  real_T PIDController1_UpperSaturationLimit;
                          // Mask Parameter: PIDController1_UpperSaturationLimit
                             //  Referenced by:
                             //    '<S158>/Saturation'
                             //    '<S144>/DeadZone'

  real_T PIDController2_UpperSaturationLimit;
                          // Mask Parameter: PIDController2_UpperSaturationLimit
                             //  Referenced by:
                             //    '<S208>/Saturation'
                             //    '<S194>/DeadZone'

  real_T PID_Altitude_UpperSaturationLimit;
                            // Mask Parameter: PID_Altitude_UpperSaturationLimit
                               //  Referenced by:
                               //    '<S513>/Saturation'
                               //    '<S499>/DeadZone'

  real_T PID_vz_UpperSaturationLimit;
                                  // Mask Parameter: PID_vz_UpperSaturationLimit
                                     //  Referenced by:
                                     //    '<S563>/Saturation'
                                     //    '<S549>/DeadZone'

  real_T PIDController1_UpperSaturationLimit_h;
                        // Mask Parameter: PIDController1_UpperSaturationLimit_h
                           //  Referenced by: '<S463>/Saturation'

  real_T PIDController_UpperSaturationLimit_i;
                         // Mask Parameter: PIDController_UpperSaturationLimit_i
                            //  Referenced by: '<S415>/Saturation'

  real_T PIDController5_UpperSaturationLimit_g;
                        // Mask Parameter: PIDController5_UpperSaturationLimit_g
                           //  Referenced by: '<S885>/Saturation'

  real_T PIDController_UpperSaturationLimit_c;
                         // Mask Parameter: PIDController_UpperSaturationLimit_c
                            //  Referenced by:
                            //    '<S641>/Saturation'
                            //    '<S627>/DeadZone'

  real_T PIDController1_UpperSaturationLimit_f;
                        // Mask Parameter: PIDController1_UpperSaturationLimit_f
                           //  Referenced by:
                           //    '<S691>/Saturation'
                           //    '<S677>/DeadZone'

  real_T PIDController2_UpperSaturationLimit_k;
                        // Mask Parameter: PIDController2_UpperSaturationLimit_k
                           //  Referenced by:
                           //    '<S741>/Saturation'
                           //    '<S727>/DeadZone'

  uint8_T CompareToConstant_const;    // Mask Parameter: CompareToConstant_const
                                         //  Referenced by: '<S30>/Constant'

  px4_Bus_vehicle_trajectory_waypoint Out1_Y0;// Computed Parameter: Out1_Y0
                                                 //  Referenced by: '<S37>/Out1'

  px4_Bus_vehicle_trajectory_waypoint Constant_Value;// Computed Parameter: Constant_Value
                                                        //  Referenced by: '<S42>/Constant'

  px4_Bus_vehicle_trajectory_waypoint Constant_Value_i;// Computed Parameter: Constant_Value_i
                                                          //  Referenced by: '<S36>/Constant'

  px4_Bus_vehicle_odometry Out1_Y0_e;  // Computed Parameter: Out1_Y0_e
                                          //  Referenced by: '<S10>/Out1'

  px4_Bus_vehicle_odometry Constant_Value_n;// Computed Parameter: Constant_Value_n
                                               //  Referenced by: '<S6>/Constant'

  px4_Bus_position_setpoint_triplet Out1_Y0_o;// Computed Parameter: Out1_Y0_o
                                                 //  Referenced by: '<S49>/Out1'

  px4_Bus_position_setpoint_triplet Constant_Value_l;// Computed Parameter: Constant_Value_l
                                                        //  Referenced by: '<S34>/Constant'

  px4_Bus_vehicle_local_position Out1_Y0_p;// Computed Parameter: Out1_Y0_p
                                              //  Referenced by: '<S13>/Out1'

  px4_Bus_vehicle_local_position Constant_Value_e;// Computed Parameter: Constant_Value_e
                                                     //  Referenced by: '<S9>/Constant'

  px4_Bus_input_rc Out1_Y0_i;          // Computed Parameter: Out1_Y0_i
                                          //  Referenced by: '<S583>/Out1'

  px4_Bus_input_rc Constant_Value_f;   // Computed Parameter: Constant_Value_f
                                          //  Referenced by: '<S582>/Constant'

  px4_Bus_vehicle_attitude_setpoint Constant_Value_g;// Computed Parameter: Constant_Value_g
                                                        //  Referenced by: '<S368>/Constant'

  px4_Bus_vehicle_attitude_setpoint Constant_Value_il;// Computed Parameter: Constant_Value_il
                                                         //  Referenced by: '<S895>/Constant'

  px4_Bus_vehAttSet Constant_Value_d;  // Computed Parameter: Constant_Value_d
                                          //  Referenced by: '<S366>/Constant'

  px4_Bus_vehicle_attitude Out1_Y0_k;  // Computed Parameter: Out1_Y0_k
                                          //  Referenced by: '<S12>/Out1'

  px4_Bus_vehicle_attitude Constant_Value_lh;// Computed Parameter: Constant_Value_lh
                                                //  Referenced by: '<S8>/Constant'

  px4_Bus_actuator_controls Constant_Value_h;// Computed Parameter: Constant_Value_h
                                                //  Referenced by: '<S51>/Constant'

  px4_Bus_actuator_controls Constant_Value_j;// Computed Parameter: Constant_Value_j
                                                //  Referenced by: '<S586>/Constant'

  px4_Bus_home_position Out1_Y0_ke;    // Computed Parameter: Out1_Y0_ke
                                          //  Referenced by: '<S48>/Out1'

  px4_Bus_home_position Constant_Value_nt;// Computed Parameter: Constant_Value_nt
                                             //  Referenced by: '<S33>/Constant'

  px4_Bus_vehicle_rates_setpoint Constant_Value_k;// Computed Parameter: Constant_Value_k
                                                     //  Referenced by: '<S362>/Constant'

  px4_Bus_rate_ctrl_status Constant_Value_c;// Computed Parameter: Constant_Value_c
                                               //  Referenced by: '<S364>/Constant'

  px4_Bus_actuator_armed Out1_Y0_d;    // Computed Parameter: Out1_Y0_d
                                          //  Referenced by: '<S11>/Out1'

  px4_Bus_actuator_armed Constant_Value_jl;// Computed Parameter: Constant_Value_jl
                                              //  Referenced by: '<S7>/Constant'

  real_T Switch1_Threshold;            // Expression: 0
                                          //  Referenced by: '<S57>/Switch1'

  real_T tau_Yaw_Y0;                   // Computed Parameter: tau_Yaw_Y0
                                          //  Referenced by: '<S53>/tau_Yaw'

  real_T tau_Pitch_Y0;                 // Computed Parameter: tau_Pitch_Y0
                                          //  Referenced by: '<S53>/tau_Pitch'

  real_T tau_Roll_Y0;                  // Computed Parameter: tau_Roll_Y0
                                          //  Referenced by: '<S53>/tau_Roll'

  real_T Constant1_Value;              // Expression: 0
                                          //  Referenced by: '<S92>/Constant1'

  real_T Constant1_Value_e;            // Expression: 0
                                          //  Referenced by: '<S142>/Constant1'

  real_T Constant1_Value_a;            // Expression: 0
                                          //  Referenced by: '<S192>/Constant1'

  real_T RateLimiter1_RisingLim;       // Expression: 60*pi/180
                                          //  Referenced by: '<S53>/Rate Limiter1'

  real_T RateLimiter1_FallingLim;      // Expression: -60*pi/180
                                          //  Referenced by: '<S53>/Rate Limiter1'

  real_T RateLimiter1_IC;              // Expression: 0
                                          //  Referenced by: '<S53>/Rate Limiter1'

  real_T Saturation_UpperSat;          // Expression: 60*pi/180
                                          //  Referenced by: '<S53>/Saturation'

  real_T Saturation_LowerSat;          // Expression: -50*pi/180
                                          //  Referenced by: '<S53>/Saturation'

  real_T RateLimiter2_RisingLim;       // Expression: 60*pi/180
                                          //  Referenced by: '<S53>/Rate Limiter2'

  real_T RateLimiter2_FallingLim;      // Expression: -60*pi/180
                                          //  Referenced by: '<S53>/Rate Limiter2'

  real_T RateLimiter2_IC;              // Expression: 0
                                          //  Referenced by: '<S53>/Rate Limiter2'

  real_T Saturation1_UpperSat;         // Expression: 60*pi/180
                                          //  Referenced by: '<S53>/Saturation1'

  real_T Saturation1_LowerSat;         // Expression: -60*pi/180
                                          //  Referenced by: '<S53>/Saturation1'

  real_T Constant_Value_p;             // Expression: 2*pi
                                          //  Referenced by: '<S57>/Constant'

  real_T Switch_Threshold;             // Expression: pi
                                          //  Referenced by: '<S57>/Switch'

  real_T Integrator_gainval;           // Computed Parameter: Integrator_gainval
                                          //  Referenced by: '<S101>/Integrator'

  real_T Filter_gainval;               // Computed Parameter: Filter_gainval
                                          //  Referenced by: '<S96>/Filter'

  real_T Clamping_zero_Value;          // Expression: 0
                                          //  Referenced by: '<S92>/Clamping_zero'

  real_T Integrator_gainval_k;       // Computed Parameter: Integrator_gainval_k
                                        //  Referenced by: '<S151>/Integrator'

  real_T Filter_gainval_p;             // Computed Parameter: Filter_gainval_p
                                          //  Referenced by: '<S146>/Filter'

  real_T Clamping_zero_Value_e;        // Expression: 0
                                          //  Referenced by: '<S142>/Clamping_zero'

  real_T Integrator_gainval_i;       // Computed Parameter: Integrator_gainval_i
                                        //  Referenced by: '<S201>/Integrator'

  real_T Filter_gainval_h;             // Computed Parameter: Filter_gainval_h
                                          //  Referenced by: '<S196>/Filter'

  real_T Clamping_zero_Value_p;        // Expression: 0
                                          //  Referenced by: '<S192>/Clamping_zero'

  real_T DiscreteTimeIntegrator2_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator2_gainval
                             //  Referenced by: '<S53>/Discrete-Time Integrator2'

  real_T DiscreteTimeIntegrator2_IC;   // Expression: 0
                                          //  Referenced by: '<S53>/Discrete-Time Integrator2'

  real_T DiscreteTimeIntegrator1_gainval;
                          // Computed Parameter: DiscreteTimeIntegrator1_gainval
                             //  Referenced by: '<S53>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator1_IC;   // Expression: 0
                                          //  Referenced by: '<S53>/Discrete-Time Integrator1'

  real_T DiscreteTimeIntegrator_gainval;
                           // Computed Parameter: DiscreteTimeIntegrator_gainval
                              //  Referenced by: '<S53>/Discrete-Time Integrator'

  real_T DiscreteTimeIntegrator_IC;    // Expression: 0
                                          //  Referenced by: '<S53>/Discrete-Time Integrator'

  real_T Constant_Value_j4;            // Expression: 0
                                          //  Referenced by: '<S370>/Constant'

  real_T tau_Thrust_Y0;                // Computed Parameter: tau_Thrust_Y0
                                          //  Referenced by: '<S54>/tau_Thrust'

  real_T des_pitch_Y0;                 // Computed Parameter: des_pitch_Y0
                                          //  Referenced by: '<S54>/des_pitch'

  real_T des_roll_Y0;                  // Computed Parameter: des_roll_Y0
                                          //  Referenced by: '<S54>/des_roll'

  real_T Constant1_Value_f;            // Expression: 0
                                          //  Referenced by: '<S497>/Constant1'

  real_T Constant1_Value_o;            // Expression: 0
                                          //  Referenced by: '<S547>/Constant1'

  real_T Gain1_Gain;                   // Expression: -1
                                          //  Referenced by: '<S370>/Gain1'

  real_T Clamping_zero_Value_m;        // Expression: 0
                                          //  Referenced by: '<S497>/Clamping_zero'

  real_T Filter_gainval_g;             // Computed Parameter: Filter_gainval_g
                                          //  Referenced by: '<S501>/Filter'

  real_T Integrator_gainval_a;       // Computed Parameter: Integrator_gainval_a
                                        //  Referenced by: '<S506>/Integrator'

  real_T Clamping_zero_Value_et;       // Expression: 0
                                          //  Referenced by: '<S547>/Clamping_zero'

  real_T Filter_gainval_k;             // Computed Parameter: Filter_gainval_k
                                          //  Referenced by: '<S551>/Filter'

  real_T Integrator_gainval_g;       // Computed Parameter: Integrator_gainval_g
                                        //  Referenced by: '<S556>/Integrator'

  real_T Gain_Gain;                    // Expression: -1
                                          //  Referenced by: '<S371>/Gain'

  real_T Gain1_Gain_f;                 // Expression: -1
                                          //  Referenced by: '<S54>/Gain1'

  real_T Constant_Value_im[4];         // Expression: [1 0 0 0]
                                          //  Referenced by: '<S55>/Constant'

  real_T Constant_Value_b;             // Expression: 1
                                          //  Referenced by: '<S577>/Constant'

  real_T Constant_Value_m;             // Expression: 1
                                          //  Referenced by: '<S578>/Constant'

  real_T Switch_Threshold_l;           // Expression: 0
                                          //  Referenced by: '<S55>/Switch'

  real_T Gain_Gain_c;                  // Expression: -1
                                          //  Referenced by: '<S50>/Gain'

  real_T Constant_Value_mw[4];         // Expression: zeros(4,1)
                                          //  Referenced by: '<S3>/Constant'

  real_T tau_Yaw_Y0_g;                 // Computed Parameter: tau_Yaw_Y0_g
                                          //  Referenced by: '<S584>/tau_Yaw'

  real_T tau_Pitch_Y0_j;               // Computed Parameter: tau_Pitch_Y0_j
                                          //  Referenced by: '<S584>/tau_Pitch'

  real_T tau_Roll_Y0_j;                // Computed Parameter: tau_Roll_Y0_j
                                          //  Referenced by: '<S584>/tau_Roll'

  real_T Constant1_Value_j;            // Expression: 0
                                          //  Referenced by: '<S625>/Constant1'

  real_T Constant1_Value_h;            // Expression: 0
                                          //  Referenced by: '<S675>/Constant1'

  real_T Constant1_Value_m;            // Expression: 0
                                          //  Referenced by: '<S725>/Constant1'

  real_T Clamping_zero_Value_mk;       // Expression: 0
                                          //  Referenced by: '<S625>/Clamping_zero'

  real_T Integrator_gainval_c;       // Computed Parameter: Integrator_gainval_c
                                        //  Referenced by: '<S634>/Integrator'

  real_T Filter_gainval_c;             // Computed Parameter: Filter_gainval_c
                                          //  Referenced by: '<S629>/Filter'

  real_T RateLimiter2_RisingLim_g;     // Expression: 40*pi/180
                                          //  Referenced by: '<S584>/Rate Limiter2'

  real_T RateLimiter2_FallingLim_k;    // Expression: -40*pi/180
                                          //  Referenced by: '<S584>/Rate Limiter2'

  real_T RateLimiter2_IC_b;            // Expression: 0
                                          //  Referenced by: '<S584>/Rate Limiter2'

  real_T Saturation1_UpperSat_g;       // Expression: 20*pi/180
                                          //  Referenced by: '<S584>/Saturation1'

  real_T Saturation1_LowerSat_j;       // Expression: -20*pi/180
                                          //  Referenced by: '<S584>/Saturation1'

  real_T Clamping_zero_Value_o;        // Expression: 0
                                          //  Referenced by: '<S675>/Clamping_zero'

  real_T Integrator_gainval_iw;     // Computed Parameter: Integrator_gainval_iw
                                       //  Referenced by: '<S684>/Integrator'

  real_T Filter_gainval_pb;            // Computed Parameter: Filter_gainval_pb
                                          //  Referenced by: '<S679>/Filter'

  real_T RateLimiter1_RisingLim_e;     // Expression: 40*pi/180
                                          //  Referenced by: '<S584>/Rate Limiter1'

  real_T RateLimiter1_FallingLim_d;    // Expression: -40*pi/180
                                          //  Referenced by: '<S584>/Rate Limiter1'

  real_T RateLimiter1_IC_n;            // Expression: 0
                                          //  Referenced by: '<S584>/Rate Limiter1'

  real_T Saturation_UpperSat_f;        // Expression: 20*pi/180
                                          //  Referenced by: '<S584>/Saturation'

  real_T Saturation_LowerSat_n;        // Expression: -20*pi/180
                                          //  Referenced by: '<S584>/Saturation'

  real_T Clamping_zero_Value_j;        // Expression: 0
                                          //  Referenced by: '<S725>/Clamping_zero'

  real_T Integrator_gainval_f;       // Computed Parameter: Integrator_gainval_f
                                        //  Referenced by: '<S734>/Integrator'

  real_T Filter_gainval_ga;            // Computed Parameter: Filter_gainval_ga
                                          //  Referenced by: '<S729>/Filter'

  real_T Constant_Value_kv[4];         // Expression: [1 0 0 0]
                                          //  Referenced by: '<S589>/Constant'

  real_T Constant_Value_mw1;           // Expression: 1
                                          //  Referenced by: '<S901>/Constant'

  real_T Constant_Value_bd;            // Expression: 1
                                          //  Referenced by: '<S902>/Constant'

  real_T Switch_Threshold_j;           // Expression: 0
                                          //  Referenced by: '<S589>/Switch'

  real_T Gain3_Gain;                   // Expression: 0.3
                                          //  Referenced by: '<S5>/Gain3'

  real_T Constant_Value_f5[4];         // Expression: zeros(4,1)
                                          //  Referenced by: '<S5>/Constant'

  real_T yaw_Out_Y0;                   // Computed Parameter: yaw_Out_Y0
                                          //  Referenced by: '<S28>/yaw_Out'

  real_T Delay_InitialCondition;       // Expression: 0.0
                                          //  Referenced by: '<S26>/Delay'

  real_T Rate_Value;                   // Expression: 0.01
                                          //  Referenced by: '<S26>/Rate'

  real_T Gain1_Gain_i;                 // Expression: -1
                                          //  Referenced by: '<S26>/Gain1'

  real_T Gain_Gain_l;                  // Expression: -1
                                          //  Referenced by: '<S26>/Gain'

  real_T Delay_InitialCondition_c;     // Expression: 1
                                          //  Referenced by: '<S27>/Delay'

  real_T Constant_Value_ki;            // Expression: 0
                                          //  Referenced by: '<S27>/Constant'

  real_T Out_Y0;                       // Computed Parameter: Out_Y0
                                          //  Referenced by: '<S24>/Out'

  real_T Gain_Gain_lz;                 // Expression: -1
                                          //  Referenced by: '<S22>/Gain'

  real_T yaw_Out_Y0_k;                 // Computed Parameter: yaw_Out_Y0_k
                                          //  Referenced by: '<S25>/yaw_Out'

  real_T Delay_InitialCondition_h;     // Expression: 0.0
                                          //  Referenced by: '<S17>/Delay'

  real_T Delay_InitialCondition_l;     // Expression: 0.0
                                          //  Referenced by: '<S22>/Delay'

  real_T Switch_Threshold_h;           // Expression: 0
                                          //  Referenced by: '<S22>/Switch'

  real_T Rateofdescent_Value;          // Expression: 0.02
                                          //  Referenced by: '<S22>/Rate of descent'

  real_T Gain2_Gain;                   // Expression: -1
                                          //  Referenced by: '<S22>/Gain2'

  real_T Gain1_Gain_m;                 // Expression: -1
                                          //  Referenced by: '<S22>/Gain1'

  real_T Delay_InitialCondition_k;     // Expression: 1
                                          //  Referenced by: '<S23>/Delay'

  real_T Constant_Value_fn;            // Expression: 0
                                          //  Referenced by: '<S23>/Constant'

  real_T Constant_Value_dx;            // Expression: 0
                                          //  Referenced by: '<S29>/Constant'

  real_T Constant_Value_fa;            // Expression: 6
                                          //  Referenced by: '<S19>/Constant'

  real_T yaw_Out_Y0_g;                 // Computed Parameter: yaw_Out_Y0_g
                                          //  Referenced by: '<S21>/yaw_Out'

  real_T Delay_InitialCondition_n;     // Expression: 1
                                          //  Referenced by: '<S20>/Delay'

  real_T Constant_Value_gj;            // Expression: 0
                                          //  Referenced by: '<S20>/Constant'

  real_T ReadParameter_SampleTime;     // Expression: -1
                                          //  Referenced by: '<S15>/Read Parameter'

  real_T ReadParameter_SampleTime_i;   // Expression: -1
                                          //  Referenced by: '<S47>/Read Parameter'

  real_T ReadParameter_SampleTime_l;   // Expression: -1
                                          //  Referenced by: '<S46>/Read Parameter'

  uint64_T Constant7_Value;            // Computed Parameter: Constant7_Value
                                          //  Referenced by: '<S40>/Constant7'

  real32_T Constant2_Value[4];         // Computed Parameter: Constant2_Value
                                          //  Referenced by: '<S53>/Constant2'

  real32_T Constant1_Value_i[3];       // Computed Parameter: Constant1_Value_i
                                          //  Referenced by: '<S53>/Constant1'

  real32_T Constant4_Value;            // Computed Parameter: Constant4_Value
                                          //  Referenced by: '<S53>/Constant4'

  real32_T Constant_Value_c0;          // Computed Parameter: Constant_Value_c0
                                          //  Referenced by: '<S53>/Constant'

  real32_T Bias_Bias;                  // Computed Parameter: Bias_Bias
                                          //  Referenced by: '<S588>/Bias'

  real32_T Gain_Gain_b;                // Computed Parameter: Gain_Gain_b
                                          //  Referenced by: '<S588>/Gain'

  real32_T Gain1_Gain_j;               // Computed Parameter: Gain1_Gain_j
                                          //  Referenced by: '<S5>/Gain1'

  real32_T Bias_Bias_o;                // Computed Parameter: Bias_Bias_o
                                          //  Referenced by: '<S591>/Bias'

  real32_T Gain_Gain_o;                // Computed Parameter: Gain_Gain_o
                                          //  Referenced by: '<S591>/Gain'

  real32_T Gain_Gain_d;                // Computed Parameter: Gain_Gain_d
                                          //  Referenced by: '<S5>/Gain'

  real32_T Bias_Bias_e;                // Computed Parameter: Bias_Bias_e
                                          //  Referenced by: '<S593>/Bias'

  real32_T Gain_Gain_m;                // Computed Parameter: Gain_Gain_m
                                          //  Referenced by: '<S593>/Gain'

  real32_T Bias_Bias_m;                // Computed Parameter: Bias_Bias_m
                                          //  Referenced by: '<S592>/Bias'

  real32_T Gain_Gain_k;                // Computed Parameter: Gain_Gain_k
                                          //  Referenced by: '<S592>/Gain'

  real32_T Gain2_Gain_k;               // Computed Parameter: Gain2_Gain_k
                                          //  Referenced by: '<S5>/Gain2'

  real32_T Constant1_Value_e3[2];      // Computed Parameter: Constant1_Value_e3
                                          //  Referenced by: '<S47>/Constant1'

  real32_T Constant_Value_kl;          // Computed Parameter: Constant_Value_kl
                                          //  Referenced by: '<S47>/Constant'

  real32_T Gain_Gain_g;                // Computed Parameter: Gain_Gain_g
                                          //  Referenced by: '<S46>/Gain'

  real32_T Constant1_Value_k[2];       // Computed Parameter: Constant1_Value_k
                                          //  Referenced by: '<S46>/Constant1'

  real32_T Constant_Value_co;          // Computed Parameter: Constant_Value_co
                                          //  Referenced by: '<S46>/Constant'

  real32_T Constant_Value_ps[3];       // Computed Parameter: Constant_Value_ps
                                          //  Referenced by: '<S40>/Constant'

  real32_T Constant1_Value_d[3];       // Computed Parameter: Constant1_Value_d
                                          //  Referenced by: '<S40>/Constant1'

  real32_T Constant2_Value_b[3];       // Computed Parameter: Constant2_Value_b
                                          //  Referenced by: '<S40>/Constant2'

  real32_T Constant3_Value;            // Computed Parameter: Constant3_Value
                                          //  Referenced by: '<S40>/Constant3'

  real32_T Constant4_Value_p;          // Computed Parameter: Constant4_Value_p
                                          //  Referenced by: '<S40>/Constant4'

  boolean_T Constant5_Value;           // Computed Parameter: Constant5_Value
                                          //  Referenced by: '<S38>/Constant5'

  boolean_T Constant5_Value_m;         // Computed Parameter: Constant5_Value_m
                                          //  Referenced by: '<S39>/Constant5'

  boolean_T Constant1_Value_a2;        // Computed Parameter: Constant1_Value_a2
                                          //  Referenced by: '<S41>/Constant1'

  boolean_T Constant5_Value_k;         // Computed Parameter: Constant5_Value_k
                                          //  Referenced by: '<S41>/Constant5'

  boolean_T Constant5_Value_e;         // Computed Parameter: Constant5_Value_e
                                          //  Referenced by: '<S40>/Constant5'

  int8_T Constant_Value_kt;            // Computed Parameter: Constant_Value_kt
                                          //  Referenced by: '<S92>/Constant'

  int8_T Constant2_Value_e;            // Computed Parameter: Constant2_Value_e
                                          //  Referenced by: '<S92>/Constant2'

  int8_T Constant3_Value_g;            // Computed Parameter: Constant3_Value_g
                                          //  Referenced by: '<S92>/Constant3'

  int8_T Constant4_Value_j;            // Computed Parameter: Constant4_Value_j
                                          //  Referenced by: '<S92>/Constant4'

  int8_T Constant_Value_hp;            // Computed Parameter: Constant_Value_hp
                                          //  Referenced by: '<S142>/Constant'

  int8_T Constant2_Value_f;            // Computed Parameter: Constant2_Value_f
                                          //  Referenced by: '<S142>/Constant2'

  int8_T Constant3_Value_c;            // Computed Parameter: Constant3_Value_c
                                          //  Referenced by: '<S142>/Constant3'

  int8_T Constant4_Value_e;            // Computed Parameter: Constant4_Value_e
                                          //  Referenced by: '<S142>/Constant4'

  int8_T Constant_Value_is;            // Computed Parameter: Constant_Value_is
                                          //  Referenced by: '<S192>/Constant'

  int8_T Constant2_Value_a;            // Computed Parameter: Constant2_Value_a
                                          //  Referenced by: '<S192>/Constant2'

  int8_T Constant3_Value_b;            // Computed Parameter: Constant3_Value_b
                                          //  Referenced by: '<S192>/Constant3'

  int8_T Constant4_Value_k;            // Computed Parameter: Constant4_Value_k
                                          //  Referenced by: '<S192>/Constant4'

  int8_T Constant_Value_hk;            // Computed Parameter: Constant_Value_hk
                                          //  Referenced by: '<S497>/Constant'

  int8_T Constant2_Value_l;            // Computed Parameter: Constant2_Value_l
                                          //  Referenced by: '<S497>/Constant2'

  int8_T Constant3_Value_gn;           // Computed Parameter: Constant3_Value_gn
                                          //  Referenced by: '<S497>/Constant3'

  int8_T Constant4_Value_g;            // Computed Parameter: Constant4_Value_g
                                          //  Referenced by: '<S497>/Constant4'

  int8_T Constant_Value_mp;            // Computed Parameter: Constant_Value_mp
                                          //  Referenced by: '<S547>/Constant'

  int8_T Constant2_Value_k;            // Computed Parameter: Constant2_Value_k
                                          //  Referenced by: '<S547>/Constant2'

  int8_T Constant3_Value_i;            // Computed Parameter: Constant3_Value_i
                                          //  Referenced by: '<S547>/Constant3'

  int8_T Constant4_Value_ja;           // Computed Parameter: Constant4_Value_ja
                                          //  Referenced by: '<S547>/Constant4'

  int8_T Constant_Value_dj;            // Computed Parameter: Constant_Value_dj
                                          //  Referenced by: '<S625>/Constant'

  int8_T Constant2_Value_bl;           // Computed Parameter: Constant2_Value_bl
                                          //  Referenced by: '<S625>/Constant2'

  int8_T Constant3_Value_k;            // Computed Parameter: Constant3_Value_k
                                          //  Referenced by: '<S625>/Constant3'

  int8_T Constant4_Value_l;            // Computed Parameter: Constant4_Value_l
                                          //  Referenced by: '<S625>/Constant4'

  int8_T Constant_Value_p5;            // Computed Parameter: Constant_Value_p5
                                          //  Referenced by: '<S675>/Constant'

  int8_T Constant2_Value_n;            // Computed Parameter: Constant2_Value_n
                                          //  Referenced by: '<S675>/Constant2'

  int8_T Constant3_Value_o;            // Computed Parameter: Constant3_Value_o
                                          //  Referenced by: '<S675>/Constant3'

  int8_T Constant4_Value_ly;           // Computed Parameter: Constant4_Value_ly
                                          //  Referenced by: '<S675>/Constant4'

  int8_T Constant_Value_c4;            // Computed Parameter: Constant_Value_c4
                                          //  Referenced by: '<S725>/Constant'

  int8_T Constant2_Value_nn;           // Computed Parameter: Constant2_Value_nn
                                          //  Referenced by: '<S725>/Constant2'

  int8_T Constant3_Value_ie;           // Computed Parameter: Constant3_Value_ie
                                          //  Referenced by: '<S725>/Constant3'

  int8_T Constant4_Value_d;            // Computed Parameter: Constant4_Value_d
                                          //  Referenced by: '<S725>/Constant4'

  uint8_T Constant3_Value_m[4];        // Computed Parameter: Constant3_Value_m
                                          //  Referenced by: '<S53>/Constant3'

  uint8_T Constant_Value_cc;           // Computed Parameter: Constant_Value_cc
                                          //  Referenced by: '<S32>/Constant'

  uint8_T Constant6_Value;             // Computed Parameter: Constant6_Value
                                          //  Referenced by: '<S40>/Constant6'

};

// Real-time Model Data Structure
struct tag_RTM_Quadcopter_ControllerWithNavigation1_T {
  const char_T * volatile errorStatus;
};

// Block parameters (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern P_Quadcopter_ControllerWithNavigation1_T
    Quadcopter_ControllerWithNavigation1_P;

#ifdef __cplusplus

}

#endif

// Block signals (default storage)
#ifdef __cplusplus

extern "C"
{

#endif

  extern struct B_Quadcopter_ControllerWithNavigation1_T
    Quadcopter_ControllerWithNavigation1_B;

#ifdef __cplusplus

}

#endif

// Block states (default storage)
extern struct DW_Quadcopter_ControllerWithNavigation1_T
  Quadcopter_ControllerWithNavigation1_DW;

#ifdef __cplusplus

extern "C"
{

#endif

  // Model entry point functions
  extern void Quadcopter_ControllerWithNavigation1_initialize(void);
  extern void Quadcopter_ControllerWithNavigation1_step(void);
  extern void Quadcopter_ControllerWithNavigation1_terminate(void);

#ifdef __cplusplus

}

#endif

// Real-time Model object
#ifdef __cplusplus

extern "C"
{

#endif

  extern RT_MODEL_Quadcopter_ControllerWithNavigation1_T *const
    Quadcopter_ControllerWithNavigation1_M;

#ifdef __cplusplus

}

#endif

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<S6>/NOT' : Unused code path elimination
//  Block '<S7>/NOT' : Unused code path elimination
//  Block '<S8>/NOT' : Unused code path elimination
//  Block '<S9>/NOT' : Unused code path elimination
//  Block '<S35>/Compare' : Unused code path elimination
//  Block '<S35>/Constant' : Unused code path elimination
//  Block '<S36>/NOT' : Unused code path elimination
//  Block '<S31>/Subtract' : Unused code path elimination
//  Block '<S33>/NOT' : Unused code path elimination
//  Block '<S34>/NOT' : Unused code path elimination
//  Block '<S376>/Data Type Duplicate' : Unused code path elimination
//  Block '<S376>/Data Type Propagation' : Unused code path elimination
//  Block '<S4>/Bitwise Operator' : Unused code path elimination
//  Block '<S4>/Data Type Conversion' : Unused code path elimination
//  Block '<S4>/Data Type Conversion1' : Unused code path elimination
//  Block '<S4>/Data Type Conversion2' : Unused code path elimination
//  Block '<S4>/Gain' : Unused code path elimination
//  Block '<S4>/Gain1' : Unused code path elimination
//  Block '<S582>/NOT' : Unused code path elimination
//  Block '<S584>/Abs1' : Unused code path elimination
//  Block '<S584>/Abs2' : Unused code path elimination
//  Block '<S594>/Gain' : Unused code path elimination
//  Block '<S594>/Matrix Concatenate' : Unused code path elimination
//  Block '<S594>/Reshape' : Unused code path elimination
//  Block '<S594>/Reshape1' : Unused code path elimination
//  Block '<S594>/SinCos' : Unused code path elimination
//  Block '<S594>/Transpose' : Unused code path elimination
//  Block '<S584>/Gain' : Unused code path elimination
//  Block '<S584>/Gain1' : Unused code path elimination
//  Block '<S584>/Gain2' : Unused code path elimination
//  Block '<S584>/Gain3' : Unused code path elimination
//  Block '<S584>/Gain4' : Unused code path elimination
//  Block '<S584>/Matrix Multiply2' : Unused code path elimination
//  Block '<S584>/Switch' : Unused code path elimination
//  Block '<S584>/Switch1' : Unused code path elimination
//  Block '<S17>/Reshape1' : Reshape block reduction
//  Block '<S53>/Data Type Conversion7' : Eliminate redundant data type conversion
//  Block '<S50>/Data Type Conversion' : Eliminate redundant data type conversion
//  Block '<S5>/Data Type Conversion1' : Eliminate redundant data type conversion


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'Quadcopter_ControllerWithNavigation1'
//  '<S1>'   : 'Quadcopter_ControllerWithNavigation1/Estimator Output'
//  '<S2>'   : 'Quadcopter_ControllerWithNavigation1/Navigation'
//  '<S3>'   : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller'
//  '<S4>'   : 'Quadcopter_ControllerWithNavigation1/Radio Control Transmitter'
//  '<S5>'   : 'Quadcopter_ControllerWithNavigation1/controllerAttitude'
//  '<S6>'   : 'Quadcopter_ControllerWithNavigation1/Estimator Output/PX4 uORB Read1'
//  '<S7>'   : 'Quadcopter_ControllerWithNavigation1/Estimator Output/PX4 uORB Read2'
//  '<S8>'   : 'Quadcopter_ControllerWithNavigation1/Estimator Output/vehicle_attitude'
//  '<S9>'   : 'Quadcopter_ControllerWithNavigation1/Estimator Output/vehicle_local_pos'
//  '<S10>'  : 'Quadcopter_ControllerWithNavigation1/Estimator Output/PX4 uORB Read1/Enabled Subsystem'
//  '<S11>'  : 'Quadcopter_ControllerWithNavigation1/Estimator Output/PX4 uORB Read2/Enabled Subsystem'
//  '<S12>'  : 'Quadcopter_ControllerWithNavigation1/Estimator Output/vehicle_attitude/Enabled Subsystem'
//  '<S13>'  : 'Quadcopter_ControllerWithNavigation1/Estimator Output/vehicle_local_pos/Enabled Subsystem'
//  '<S14>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem'
//  '<S15>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC'
//  '<S16>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/IDLE'
//  '<S17>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Land'
//  '<S18>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Take-off'
//  '<S19>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Waypoint'
//  '<S20>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/IDLE/Maintain Current Yaw during IDLE'
//  '<S21>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/IDLE/Maintain Current Yaw during IDLE/Enabled Subsystem2'
//  '<S22>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Land/Ensure Smooth descend during Land'
//  '<S23>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Land/Maintain Current Yaw during Land'
//  '<S24>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Land/Ensure Smooth descend during Land/Enabled Subsystem'
//  '<S25>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Land/Maintain Current Yaw during Land/Enabled Subsystem2'
//  '<S26>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Take-off/Ensure smooth ascend during Takeoff'
//  '<S27>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Take-off/Maintain Current Yaw during TakeOff'
//  '<S28>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Take-off/Maintain Current Yaw during TakeOff/Enabled Subsystem2'
//  '<S29>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Waypoint/Output signal conditioning'
//  '<S30>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Guidance Subsystem/Waypoint/Output signal conditioning/Compare To Constant'
//  '<S31>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Read waypoints from OBC'
//  '<S32>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC'
//  '<S33>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/homePositionRead'
//  '<S34>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/positionSetpointRead'
//  '<S35>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Read waypoints from OBC/Compare To Constant'
//  '<S36>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Read waypoints from OBC/PX4 uORB Read'
//  '<S37>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Read waypoints from OBC/PX4 uORB Read/Enabled Subsystem'
//  '<S38>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_Type_Adapted_WayPoint'
//  '<S39>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_WayPoint'
//  '<S40>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Empty_WayPoint'
//  '<S41>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Next_WayPoint'
//  '<S42>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/PX4 uORB Message'
//  '<S43>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/PX4 uORB Write'
//  '<S44>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_Type_Adapted_WayPoint/Convert_to_type_adapted_WP'
//  '<S45>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_Type_Adapted_WayPoint/Convert_to_type_adapted_WP/If Action Subsystem'
//  '<S46>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_Type_Adapted_WayPoint/Convert_to_type_adapted_WP/If Action Subsystem1'
//  '<S47>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/Send waypoints to OBC/Current_Type_Adapted_WayPoint/Convert_to_type_adapted_WP/If Action Subsystem2'
//  '<S48>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/homePositionRead/Enabled Subsystem'
//  '<S49>'  : 'Quadcopter_ControllerWithNavigation1/Navigation/Read Position Setpoint from Mission set in QGC/positionSetpointRead/Enabled Subsystem'
//  '<S50>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller'
//  '<S51>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/PX4 uORB Message'
//  '<S52>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/PX4 uORB Write'
//  '<S53>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller'
//  '<S54>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller'
//  '<S55>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternion Validity Check'
//  '<S56>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles'
//  '<S57>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/Calculate minimum Turn'
//  '<S58>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller'
//  '<S59>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1'
//  '<S60>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2'
//  '<S61>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3'
//  '<S62>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4'
//  '<S63>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5'
//  '<S64>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog'
//  '<S65>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog1'
//  '<S66>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog2'
//  '<S67>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog3'
//  '<S68>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Anti-windup'
//  '<S69>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/D Gain'
//  '<S70>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Filter'
//  '<S71>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Filter ICs'
//  '<S72>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/I Gain'
//  '<S73>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Ideal P Gain'
//  '<S74>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Ideal P Gain Fdbk'
//  '<S75>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Integrator'
//  '<S76>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Integrator ICs'
//  '<S77>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/N Copy'
//  '<S78>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/N Gain'
//  '<S79>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/P Copy'
//  '<S80>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Parallel P Gain'
//  '<S81>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Reset Signal'
//  '<S82>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Saturation'
//  '<S83>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Saturation Fdbk'
//  '<S84>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Sum'
//  '<S85>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Sum Fdbk'
//  '<S86>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tracking Mode'
//  '<S87>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tracking Mode Sum'
//  '<S88>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tsamp - Integral'
//  '<S89>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tsamp - Ngain'
//  '<S90>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/postSat Signal'
//  '<S91>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/preSat Signal'
//  '<S92>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S93>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S94>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S95>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/D Gain/Internal Parameters'
//  '<S96>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Filter/Disc. Forward Euler Filter'
//  '<S97>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Filter ICs/Internal IC - Filter'
//  '<S98>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/I Gain/Internal Parameters'
//  '<S99>'  : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S100>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S101>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Integrator/Discrete'
//  '<S102>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Integrator ICs/Internal IC'
//  '<S103>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/N Copy/Disabled'
//  '<S104>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/N Gain/Internal Parameters'
//  '<S105>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/P Copy/Disabled'
//  '<S106>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Parallel P Gain/Internal Parameters'
//  '<S107>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Reset Signal/Disabled'
//  '<S108>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Saturation/Enabled'
//  '<S109>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S110>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Sum/Sum_PID'
//  '<S111>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Sum Fdbk/Disabled'
//  '<S112>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tracking Mode/Disabled'
//  '<S113>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S114>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tsamp - Integral/TsSignalSpecification'
//  '<S115>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S116>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/postSat Signal/Forward_Path'
//  '<S117>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller/preSat Signal/Forward_Path'
//  '<S118>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Anti-windup'
//  '<S119>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/D Gain'
//  '<S120>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Filter'
//  '<S121>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Filter ICs'
//  '<S122>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/I Gain'
//  '<S123>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Ideal P Gain'
//  '<S124>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Ideal P Gain Fdbk'
//  '<S125>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Integrator'
//  '<S126>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Integrator ICs'
//  '<S127>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/N Copy'
//  '<S128>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/N Gain'
//  '<S129>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/P Copy'
//  '<S130>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Parallel P Gain'
//  '<S131>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Reset Signal'
//  '<S132>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Saturation'
//  '<S133>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Saturation Fdbk'
//  '<S134>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Sum'
//  '<S135>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Sum Fdbk'
//  '<S136>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tracking Mode'
//  '<S137>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tracking Mode Sum'
//  '<S138>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tsamp - Integral'
//  '<S139>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tsamp - Ngain'
//  '<S140>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/postSat Signal'
//  '<S141>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/preSat Signal'
//  '<S142>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel'
//  '<S143>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S144>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S145>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/D Gain/Internal Parameters'
//  '<S146>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Filter/Disc. Forward Euler Filter'
//  '<S147>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Filter ICs/Internal IC - Filter'
//  '<S148>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/I Gain/Internal Parameters'
//  '<S149>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Ideal P Gain/Passthrough'
//  '<S150>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Ideal P Gain Fdbk/Disabled'
//  '<S151>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Integrator/Discrete'
//  '<S152>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Integrator ICs/Internal IC'
//  '<S153>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/N Copy/Disabled'
//  '<S154>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/N Gain/Internal Parameters'
//  '<S155>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/P Copy/Disabled'
//  '<S156>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Parallel P Gain/Internal Parameters'
//  '<S157>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Reset Signal/Disabled'
//  '<S158>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Saturation/Enabled'
//  '<S159>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Saturation Fdbk/Disabled'
//  '<S160>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Sum/Sum_PID'
//  '<S161>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Sum Fdbk/Disabled'
//  '<S162>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tracking Mode/Disabled'
//  '<S163>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tracking Mode Sum/Passthrough'
//  '<S164>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tsamp - Integral/TsSignalSpecification'
//  '<S165>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/Tsamp - Ngain/Passthrough'
//  '<S166>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/postSat Signal/Forward_Path'
//  '<S167>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller1/preSat Signal/Forward_Path'
//  '<S168>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Anti-windup'
//  '<S169>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/D Gain'
//  '<S170>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Filter'
//  '<S171>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Filter ICs'
//  '<S172>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/I Gain'
//  '<S173>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Ideal P Gain'
//  '<S174>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Ideal P Gain Fdbk'
//  '<S175>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Integrator'
//  '<S176>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Integrator ICs'
//  '<S177>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/N Copy'
//  '<S178>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/N Gain'
//  '<S179>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/P Copy'
//  '<S180>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Parallel P Gain'
//  '<S181>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Reset Signal'
//  '<S182>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Saturation'
//  '<S183>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Saturation Fdbk'
//  '<S184>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Sum'
//  '<S185>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Sum Fdbk'
//  '<S186>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tracking Mode'
//  '<S187>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tracking Mode Sum'
//  '<S188>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tsamp - Integral'
//  '<S189>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tsamp - Ngain'
//  '<S190>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/postSat Signal'
//  '<S191>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/preSat Signal'
//  '<S192>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel'
//  '<S193>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S194>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S195>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/D Gain/Internal Parameters'
//  '<S196>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Filter/Disc. Forward Euler Filter'
//  '<S197>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Filter ICs/Internal IC - Filter'
//  '<S198>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/I Gain/Internal Parameters'
//  '<S199>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Ideal P Gain/Passthrough'
//  '<S200>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Ideal P Gain Fdbk/Disabled'
//  '<S201>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Integrator/Discrete'
//  '<S202>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Integrator ICs/Internal IC'
//  '<S203>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/N Copy/Disabled'
//  '<S204>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/N Gain/Internal Parameters'
//  '<S205>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/P Copy/Disabled'
//  '<S206>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Parallel P Gain/Internal Parameters'
//  '<S207>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Reset Signal/Disabled'
//  '<S208>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Saturation/Enabled'
//  '<S209>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Saturation Fdbk/Disabled'
//  '<S210>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Sum/Sum_PID'
//  '<S211>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Sum Fdbk/Disabled'
//  '<S212>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tracking Mode/Disabled'
//  '<S213>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tracking Mode Sum/Passthrough'
//  '<S214>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tsamp - Integral/TsSignalSpecification'
//  '<S215>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/Tsamp - Ngain/Passthrough'
//  '<S216>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/postSat Signal/Forward_Path'
//  '<S217>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller2/preSat Signal/Forward_Path'
//  '<S218>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Anti-windup'
//  '<S219>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/D Gain'
//  '<S220>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Filter'
//  '<S221>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Filter ICs'
//  '<S222>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/I Gain'
//  '<S223>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Ideal P Gain'
//  '<S224>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Ideal P Gain Fdbk'
//  '<S225>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Integrator'
//  '<S226>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Integrator ICs'
//  '<S227>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/N Copy'
//  '<S228>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/N Gain'
//  '<S229>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/P Copy'
//  '<S230>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Parallel P Gain'
//  '<S231>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Reset Signal'
//  '<S232>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Saturation'
//  '<S233>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Saturation Fdbk'
//  '<S234>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Sum'
//  '<S235>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Sum Fdbk'
//  '<S236>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tracking Mode'
//  '<S237>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tracking Mode Sum'
//  '<S238>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tsamp - Integral'
//  '<S239>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tsamp - Ngain'
//  '<S240>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/postSat Signal'
//  '<S241>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/preSat Signal'
//  '<S242>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Anti-windup/Disabled'
//  '<S243>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/D Gain/Disabled'
//  '<S244>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Filter/Disabled'
//  '<S245>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Filter ICs/Disabled'
//  '<S246>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/I Gain/Disabled'
//  '<S247>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Ideal P Gain/Passthrough'
//  '<S248>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Ideal P Gain Fdbk/Disabled'
//  '<S249>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Integrator/Disabled'
//  '<S250>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Integrator ICs/Disabled'
//  '<S251>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/N Copy/Disabled wSignal Specification'
//  '<S252>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/N Gain/Disabled'
//  '<S253>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/P Copy/Disabled'
//  '<S254>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Parallel P Gain/Internal Parameters'
//  '<S255>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Reset Signal/Disabled'
//  '<S256>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Saturation/Passthrough'
//  '<S257>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Saturation Fdbk/Disabled'
//  '<S258>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Sum/Passthrough_P'
//  '<S259>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Sum Fdbk/Disabled'
//  '<S260>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tracking Mode/Disabled'
//  '<S261>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tracking Mode Sum/Passthrough'
//  '<S262>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tsamp - Integral/TsSignalSpecification'
//  '<S263>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/Tsamp - Ngain/Passthrough'
//  '<S264>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/postSat Signal/Forward_Path'
//  '<S265>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller3/preSat Signal/Forward_Path'
//  '<S266>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Anti-windup'
//  '<S267>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/D Gain'
//  '<S268>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Filter'
//  '<S269>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Filter ICs'
//  '<S270>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/I Gain'
//  '<S271>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Ideal P Gain'
//  '<S272>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Ideal P Gain Fdbk'
//  '<S273>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Integrator'
//  '<S274>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Integrator ICs'
//  '<S275>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/N Copy'
//  '<S276>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/N Gain'
//  '<S277>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/P Copy'
//  '<S278>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Parallel P Gain'
//  '<S279>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Reset Signal'
//  '<S280>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Saturation'
//  '<S281>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Saturation Fdbk'
//  '<S282>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Sum'
//  '<S283>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Sum Fdbk'
//  '<S284>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tracking Mode'
//  '<S285>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tracking Mode Sum'
//  '<S286>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tsamp - Integral'
//  '<S287>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tsamp - Ngain'
//  '<S288>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/postSat Signal'
//  '<S289>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/preSat Signal'
//  '<S290>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Anti-windup/Disabled'
//  '<S291>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/D Gain/Disabled'
//  '<S292>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Filter/Disabled'
//  '<S293>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Filter ICs/Disabled'
//  '<S294>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/I Gain/Disabled'
//  '<S295>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Ideal P Gain/Passthrough'
//  '<S296>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Ideal P Gain Fdbk/Disabled'
//  '<S297>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Integrator/Disabled'
//  '<S298>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Integrator ICs/Disabled'
//  '<S299>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/N Copy/Disabled wSignal Specification'
//  '<S300>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/N Gain/Disabled'
//  '<S301>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/P Copy/Disabled'
//  '<S302>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Parallel P Gain/Internal Parameters'
//  '<S303>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Reset Signal/Disabled'
//  '<S304>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Saturation/Passthrough'
//  '<S305>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Saturation Fdbk/Disabled'
//  '<S306>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Sum/Passthrough_P'
//  '<S307>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Sum Fdbk/Disabled'
//  '<S308>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tracking Mode/Disabled'
//  '<S309>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tracking Mode Sum/Passthrough'
//  '<S310>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tsamp - Integral/TsSignalSpecification'
//  '<S311>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/Tsamp - Ngain/Passthrough'
//  '<S312>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/postSat Signal/Forward_Path'
//  '<S313>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller4/preSat Signal/Forward_Path'
//  '<S314>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Anti-windup'
//  '<S315>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/D Gain'
//  '<S316>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Filter'
//  '<S317>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Filter ICs'
//  '<S318>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/I Gain'
//  '<S319>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Ideal P Gain'
//  '<S320>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Ideal P Gain Fdbk'
//  '<S321>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Integrator'
//  '<S322>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Integrator ICs'
//  '<S323>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/N Copy'
//  '<S324>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/N Gain'
//  '<S325>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/P Copy'
//  '<S326>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Parallel P Gain'
//  '<S327>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Reset Signal'
//  '<S328>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Saturation'
//  '<S329>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Saturation Fdbk'
//  '<S330>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Sum'
//  '<S331>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Sum Fdbk'
//  '<S332>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tracking Mode'
//  '<S333>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tracking Mode Sum'
//  '<S334>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tsamp - Integral'
//  '<S335>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tsamp - Ngain'
//  '<S336>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/postSat Signal'
//  '<S337>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/preSat Signal'
//  '<S338>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Anti-windup/Disabled'
//  '<S339>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/D Gain/Disabled'
//  '<S340>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Filter/Disabled'
//  '<S341>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Filter ICs/Disabled'
//  '<S342>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/I Gain/Disabled'
//  '<S343>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Ideal P Gain/Passthrough'
//  '<S344>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Ideal P Gain Fdbk/Disabled'
//  '<S345>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Integrator/Disabled'
//  '<S346>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Integrator ICs/Disabled'
//  '<S347>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/N Copy/Disabled wSignal Specification'
//  '<S348>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/N Gain/Disabled'
//  '<S349>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/P Copy/Disabled'
//  '<S350>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Parallel P Gain/Internal Parameters'
//  '<S351>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Reset Signal/Disabled'
//  '<S352>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Saturation/Enabled'
//  '<S353>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Saturation Fdbk/Disabled'
//  '<S354>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Sum/Passthrough_P'
//  '<S355>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Sum Fdbk/Disabled'
//  '<S356>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tracking Mode/Disabled'
//  '<S357>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tracking Mode Sum/Passthrough'
//  '<S358>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tsamp - Integral/TsSignalSpecification'
//  '<S359>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/Tsamp - Ngain/Passthrough'
//  '<S360>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/postSat Signal/Forward_Path'
//  '<S361>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PID Controller5/preSat Signal/Forward_Path'
//  '<S362>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog/PX4 uORB Message'
//  '<S363>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog/PX4_log_write'
//  '<S364>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog1/PX4 uORB Message'
//  '<S365>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog1/PX4_log_write'
//  '<S366>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog2/PX4 uORB Message'
//  '<S367>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog2/PX4_log_write'
//  '<S368>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog3/PX4 uORB Message'
//  '<S369>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Attitude controller/PX4 ULog3/PX4_log_write'
//  '<S370>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/Altitude Signal conditioning'
//  '<S371>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/Calculate Transformation Matrix'
//  '<S372>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller'
//  '<S373>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1'
//  '<S374>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude'
//  '<S375>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz'
//  '<S376>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/Altitude Signal conditioning/Saturation Dynamic'
//  '<S377>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Anti-windup'
//  '<S378>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/D Gain'
//  '<S379>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Filter'
//  '<S380>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Filter ICs'
//  '<S381>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/I Gain'
//  '<S382>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Ideal P Gain'
//  '<S383>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Ideal P Gain Fdbk'
//  '<S384>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Integrator'
//  '<S385>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Integrator ICs'
//  '<S386>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/N Copy'
//  '<S387>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/N Gain'
//  '<S388>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/P Copy'
//  '<S389>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Parallel P Gain'
//  '<S390>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Reset Signal'
//  '<S391>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Saturation'
//  '<S392>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Saturation Fdbk'
//  '<S393>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Sum'
//  '<S394>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Sum Fdbk'
//  '<S395>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tracking Mode'
//  '<S396>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tracking Mode Sum'
//  '<S397>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tsamp - Integral'
//  '<S398>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tsamp - Ngain'
//  '<S399>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/postSat Signal'
//  '<S400>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/preSat Signal'
//  '<S401>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Anti-windup/Disabled'
//  '<S402>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/D Gain/Disabled'
//  '<S403>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Filter/Disabled'
//  '<S404>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Filter ICs/Disabled'
//  '<S405>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/I Gain/Disabled'
//  '<S406>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S407>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S408>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Integrator/Disabled'
//  '<S409>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Integrator ICs/Disabled'
//  '<S410>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/N Copy/Disabled wSignal Specification'
//  '<S411>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/N Gain/Disabled'
//  '<S412>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/P Copy/Disabled'
//  '<S413>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Parallel P Gain/Internal Parameters'
//  '<S414>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Reset Signal/Disabled'
//  '<S415>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Saturation/Enabled'
//  '<S416>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S417>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Sum/Passthrough_P'
//  '<S418>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Sum Fdbk/Disabled'
//  '<S419>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tracking Mode/Disabled'
//  '<S420>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S421>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tsamp - Integral/TsSignalSpecification'
//  '<S422>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S423>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/postSat Signal/Forward_Path'
//  '<S424>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller/preSat Signal/Forward_Path'
//  '<S425>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Anti-windup'
//  '<S426>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/D Gain'
//  '<S427>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Filter'
//  '<S428>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Filter ICs'
//  '<S429>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/I Gain'
//  '<S430>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Ideal P Gain'
//  '<S431>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Ideal P Gain Fdbk'
//  '<S432>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Integrator'
//  '<S433>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Integrator ICs'
//  '<S434>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/N Copy'
//  '<S435>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/N Gain'
//  '<S436>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/P Copy'
//  '<S437>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Parallel P Gain'
//  '<S438>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Reset Signal'
//  '<S439>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Saturation'
//  '<S440>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Saturation Fdbk'
//  '<S441>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Sum'
//  '<S442>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Sum Fdbk'
//  '<S443>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tracking Mode'
//  '<S444>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tracking Mode Sum'
//  '<S445>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tsamp - Integral'
//  '<S446>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tsamp - Ngain'
//  '<S447>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/postSat Signal'
//  '<S448>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/preSat Signal'
//  '<S449>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Anti-windup/Disabled'
//  '<S450>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/D Gain/Disabled'
//  '<S451>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Filter/Disabled'
//  '<S452>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Filter ICs/Disabled'
//  '<S453>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/I Gain/Disabled'
//  '<S454>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Ideal P Gain/Passthrough'
//  '<S455>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Ideal P Gain Fdbk/Disabled'
//  '<S456>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Integrator/Disabled'
//  '<S457>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Integrator ICs/Disabled'
//  '<S458>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/N Copy/Disabled wSignal Specification'
//  '<S459>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/N Gain/Disabled'
//  '<S460>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/P Copy/Disabled'
//  '<S461>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Parallel P Gain/Internal Parameters'
//  '<S462>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Reset Signal/Disabled'
//  '<S463>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Saturation/Enabled'
//  '<S464>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Saturation Fdbk/Disabled'
//  '<S465>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Sum/Passthrough_P'
//  '<S466>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Sum Fdbk/Disabled'
//  '<S467>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tracking Mode/Disabled'
//  '<S468>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tracking Mode Sum/Passthrough'
//  '<S469>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tsamp - Integral/TsSignalSpecification'
//  '<S470>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/Tsamp - Ngain/Passthrough'
//  '<S471>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/postSat Signal/Forward_Path'
//  '<S472>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID Controller1/preSat Signal/Forward_Path'
//  '<S473>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Anti-windup'
//  '<S474>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/D Gain'
//  '<S475>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Filter'
//  '<S476>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Filter ICs'
//  '<S477>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/I Gain'
//  '<S478>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Ideal P Gain'
//  '<S479>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Ideal P Gain Fdbk'
//  '<S480>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Integrator'
//  '<S481>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Integrator ICs'
//  '<S482>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/N Copy'
//  '<S483>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/N Gain'
//  '<S484>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/P Copy'
//  '<S485>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Parallel P Gain'
//  '<S486>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Reset Signal'
//  '<S487>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Saturation'
//  '<S488>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Saturation Fdbk'
//  '<S489>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Sum'
//  '<S490>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Sum Fdbk'
//  '<S491>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tracking Mode'
//  '<S492>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tracking Mode Sum'
//  '<S493>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tsamp - Integral'
//  '<S494>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tsamp - Ngain'
//  '<S495>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/postSat Signal'
//  '<S496>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/preSat Signal'
//  '<S497>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Anti-windup/Disc. Clamping Parallel'
//  '<S498>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S499>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S500>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/D Gain/Internal Parameters'
//  '<S501>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Filter/Disc. Forward Euler Filter'
//  '<S502>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Filter ICs/Internal IC - Filter'
//  '<S503>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/I Gain/Internal Parameters'
//  '<S504>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Ideal P Gain/Passthrough'
//  '<S505>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Ideal P Gain Fdbk/Passthrough'
//  '<S506>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Integrator/Discrete'
//  '<S507>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Integrator ICs/Internal IC'
//  '<S508>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/N Copy/Disabled'
//  '<S509>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/N Gain/Internal Parameters'
//  '<S510>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/P Copy/Disabled'
//  '<S511>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Parallel P Gain/Internal Parameters'
//  '<S512>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Reset Signal/Disabled'
//  '<S513>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Saturation/Enabled'
//  '<S514>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Saturation Fdbk/Passthrough'
//  '<S515>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Sum/Sum_PID'
//  '<S516>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Sum Fdbk/Enabled'
//  '<S517>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tracking Mode/Disabled'
//  '<S518>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tracking Mode Sum/Passthrough'
//  '<S519>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tsamp - Integral/TsSignalSpecification'
//  '<S520>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/Tsamp - Ngain/Passthrough'
//  '<S521>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/postSat Signal/Feedback_Path'
//  '<S522>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_Altitude/preSat Signal/Feedback_Path'
//  '<S523>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Anti-windup'
//  '<S524>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/D Gain'
//  '<S525>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Filter'
//  '<S526>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Filter ICs'
//  '<S527>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/I Gain'
//  '<S528>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Ideal P Gain'
//  '<S529>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Ideal P Gain Fdbk'
//  '<S530>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Integrator'
//  '<S531>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Integrator ICs'
//  '<S532>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/N Copy'
//  '<S533>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/N Gain'
//  '<S534>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/P Copy'
//  '<S535>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Parallel P Gain'
//  '<S536>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Reset Signal'
//  '<S537>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Saturation'
//  '<S538>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Saturation Fdbk'
//  '<S539>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Sum'
//  '<S540>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Sum Fdbk'
//  '<S541>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tracking Mode'
//  '<S542>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tracking Mode Sum'
//  '<S543>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tsamp - Integral'
//  '<S544>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tsamp - Ngain'
//  '<S545>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/postSat Signal'
//  '<S546>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/preSat Signal'
//  '<S547>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Anti-windup/Disc. Clamping Parallel'
//  '<S548>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S549>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S550>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/D Gain/Internal Parameters'
//  '<S551>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Filter/Disc. Forward Euler Filter'
//  '<S552>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Filter ICs/Internal IC - Filter'
//  '<S553>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/I Gain/Internal Parameters'
//  '<S554>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Ideal P Gain/Passthrough'
//  '<S555>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Ideal P Gain Fdbk/Passthrough'
//  '<S556>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Integrator/Discrete'
//  '<S557>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Integrator ICs/Internal IC'
//  '<S558>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/N Copy/Disabled'
//  '<S559>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/N Gain/Internal Parameters'
//  '<S560>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/P Copy/Disabled'
//  '<S561>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Parallel P Gain/Internal Parameters'
//  '<S562>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Reset Signal/Disabled'
//  '<S563>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Saturation/Enabled'
//  '<S564>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Saturation Fdbk/Passthrough'
//  '<S565>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Sum/Sum_PID'
//  '<S566>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Sum Fdbk/Enabled'
//  '<S567>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tracking Mode/Disabled'
//  '<S568>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tracking Mode Sum/Passthrough'
//  '<S569>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tsamp - Integral/TsSignalSpecification'
//  '<S570>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/Tsamp - Ngain/Passthrough'
//  '<S571>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/postSat Signal/Feedback_Path'
//  '<S572>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Position & Altitude controller/PID_vz/preSat Signal/Feedback_Path'
//  '<S573>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternion Validity Check/Quaternion Norm'
//  '<S574>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Angle Calculation'
//  '<S575>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Quaternion Normalize'
//  '<S576>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input'
//  '<S577>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem'
//  '<S578>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem1'
//  '<S579>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem2'
//  '<S580>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus'
//  '<S581>' : 'Quadcopter_ControllerWithNavigation1/Position & Rate Controller/Controller/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus/Quaternion Norm'
//  '<S582>' : 'Quadcopter_ControllerWithNavigation1/Radio Control Transmitter/PX4 uORB Read'
//  '<S583>' : 'Quadcopter_ControllerWithNavigation1/Radio Control Transmitter/PX4 uORB Read/Enabled Subsystem'
//  '<S584>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller'
//  '<S585>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/PX4 ULog3'
//  '<S586>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/PX4 uORB Message'
//  '<S587>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/PX4 uORB Write'
//  '<S588>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Pitch axis (-1...1)'
//  '<S589>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternion Validity Check'
//  '<S590>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles'
//  '<S591>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Roll axis (-1...1)'
//  '<S592>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Throttle (0...1)'
//  '<S593>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Yaw axis (-1...1)'
//  '<S594>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/Calculate Transformation Matrix'
//  '<S595>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller'
//  '<S596>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1'
//  '<S597>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2'
//  '<S598>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3'
//  '<S599>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4'
//  '<S600>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5'
//  '<S601>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Anti-windup'
//  '<S602>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/D Gain'
//  '<S603>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Filter'
//  '<S604>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Filter ICs'
//  '<S605>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/I Gain'
//  '<S606>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Ideal P Gain'
//  '<S607>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Ideal P Gain Fdbk'
//  '<S608>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Integrator'
//  '<S609>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Integrator ICs'
//  '<S610>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/N Copy'
//  '<S611>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/N Gain'
//  '<S612>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/P Copy'
//  '<S613>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Parallel P Gain'
//  '<S614>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Reset Signal'
//  '<S615>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Saturation'
//  '<S616>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Saturation Fdbk'
//  '<S617>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Sum'
//  '<S618>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Sum Fdbk'
//  '<S619>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tracking Mode'
//  '<S620>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tracking Mode Sum'
//  '<S621>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tsamp - Integral'
//  '<S622>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tsamp - Ngain'
//  '<S623>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/postSat Signal'
//  '<S624>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/preSat Signal'
//  '<S625>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel'
//  '<S626>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S627>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S628>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/D Gain/Internal Parameters'
//  '<S629>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Filter/Disc. Forward Euler Filter'
//  '<S630>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Filter ICs/Internal IC - Filter'
//  '<S631>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/I Gain/Internal Parameters'
//  '<S632>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Ideal P Gain/Passthrough'
//  '<S633>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S634>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Integrator/Discrete'
//  '<S635>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Integrator ICs/Internal IC'
//  '<S636>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/N Copy/Disabled'
//  '<S637>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/N Gain/Internal Parameters'
//  '<S638>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/P Copy/Disabled'
//  '<S639>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Parallel P Gain/Internal Parameters'
//  '<S640>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Reset Signal/Disabled'
//  '<S641>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Saturation/Enabled'
//  '<S642>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Saturation Fdbk/Disabled'
//  '<S643>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Sum/Sum_PID'
//  '<S644>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Sum Fdbk/Disabled'
//  '<S645>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tracking Mode/Disabled'
//  '<S646>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S647>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tsamp - Integral/TsSignalSpecification'
//  '<S648>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S649>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/postSat Signal/Forward_Path'
//  '<S650>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller/preSat Signal/Forward_Path'
//  '<S651>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Anti-windup'
//  '<S652>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/D Gain'
//  '<S653>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Filter'
//  '<S654>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Filter ICs'
//  '<S655>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/I Gain'
//  '<S656>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Ideal P Gain'
//  '<S657>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Ideal P Gain Fdbk'
//  '<S658>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Integrator'
//  '<S659>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Integrator ICs'
//  '<S660>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/N Copy'
//  '<S661>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/N Gain'
//  '<S662>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/P Copy'
//  '<S663>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Parallel P Gain'
//  '<S664>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Reset Signal'
//  '<S665>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Saturation'
//  '<S666>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Saturation Fdbk'
//  '<S667>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Sum'
//  '<S668>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Sum Fdbk'
//  '<S669>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tracking Mode'
//  '<S670>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tracking Mode Sum'
//  '<S671>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tsamp - Integral'
//  '<S672>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tsamp - Ngain'
//  '<S673>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/postSat Signal'
//  '<S674>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/preSat Signal'
//  '<S675>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel'
//  '<S676>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S677>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S678>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/D Gain/Internal Parameters'
//  '<S679>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Filter/Disc. Forward Euler Filter'
//  '<S680>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Filter ICs/Internal IC - Filter'
//  '<S681>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/I Gain/Internal Parameters'
//  '<S682>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Ideal P Gain/Passthrough'
//  '<S683>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Ideal P Gain Fdbk/Disabled'
//  '<S684>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Integrator/Discrete'
//  '<S685>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Integrator ICs/Internal IC'
//  '<S686>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/N Copy/Disabled'
//  '<S687>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/N Gain/Internal Parameters'
//  '<S688>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/P Copy/Disabled'
//  '<S689>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Parallel P Gain/Internal Parameters'
//  '<S690>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Reset Signal/Disabled'
//  '<S691>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Saturation/Enabled'
//  '<S692>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Saturation Fdbk/Disabled'
//  '<S693>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Sum/Sum_PID'
//  '<S694>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Sum Fdbk/Disabled'
//  '<S695>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tracking Mode/Disabled'
//  '<S696>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tracking Mode Sum/Passthrough'
//  '<S697>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tsamp - Integral/TsSignalSpecification'
//  '<S698>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/Tsamp - Ngain/Passthrough'
//  '<S699>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/postSat Signal/Forward_Path'
//  '<S700>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller1/preSat Signal/Forward_Path'
//  '<S701>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Anti-windup'
//  '<S702>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/D Gain'
//  '<S703>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Filter'
//  '<S704>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Filter ICs'
//  '<S705>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/I Gain'
//  '<S706>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Ideal P Gain'
//  '<S707>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Ideal P Gain Fdbk'
//  '<S708>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Integrator'
//  '<S709>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Integrator ICs'
//  '<S710>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/N Copy'
//  '<S711>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/N Gain'
//  '<S712>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/P Copy'
//  '<S713>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Parallel P Gain'
//  '<S714>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Reset Signal'
//  '<S715>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Saturation'
//  '<S716>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Saturation Fdbk'
//  '<S717>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Sum'
//  '<S718>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Sum Fdbk'
//  '<S719>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tracking Mode'
//  '<S720>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tracking Mode Sum'
//  '<S721>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tsamp - Integral'
//  '<S722>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tsamp - Ngain'
//  '<S723>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/postSat Signal'
//  '<S724>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/preSat Signal'
//  '<S725>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel'
//  '<S726>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel/Dead Zone'
//  '<S727>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Anti-windup/Disc. Clamping Parallel/Dead Zone/Enabled'
//  '<S728>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/D Gain/Internal Parameters'
//  '<S729>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Filter/Disc. Forward Euler Filter'
//  '<S730>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Filter ICs/Internal IC - Filter'
//  '<S731>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/I Gain/Internal Parameters'
//  '<S732>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Ideal P Gain/Passthrough'
//  '<S733>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Ideal P Gain Fdbk/Disabled'
//  '<S734>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Integrator/Discrete'
//  '<S735>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Integrator ICs/Internal IC'
//  '<S736>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/N Copy/Disabled'
//  '<S737>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/N Gain/Internal Parameters'
//  '<S738>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/P Copy/Disabled'
//  '<S739>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Parallel P Gain/Internal Parameters'
//  '<S740>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Reset Signal/Disabled'
//  '<S741>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Saturation/Enabled'
//  '<S742>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Saturation Fdbk/Disabled'
//  '<S743>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Sum/Sum_PID'
//  '<S744>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Sum Fdbk/Disabled'
//  '<S745>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tracking Mode/Disabled'
//  '<S746>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tracking Mode Sum/Passthrough'
//  '<S747>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tsamp - Integral/TsSignalSpecification'
//  '<S748>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/Tsamp - Ngain/Passthrough'
//  '<S749>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/postSat Signal/Forward_Path'
//  '<S750>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller2/preSat Signal/Forward_Path'
//  '<S751>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Anti-windup'
//  '<S752>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/D Gain'
//  '<S753>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Filter'
//  '<S754>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Filter ICs'
//  '<S755>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/I Gain'
//  '<S756>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Ideal P Gain'
//  '<S757>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Ideal P Gain Fdbk'
//  '<S758>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Integrator'
//  '<S759>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Integrator ICs'
//  '<S760>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/N Copy'
//  '<S761>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/N Gain'
//  '<S762>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/P Copy'
//  '<S763>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Parallel P Gain'
//  '<S764>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Reset Signal'
//  '<S765>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Saturation'
//  '<S766>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Saturation Fdbk'
//  '<S767>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Sum'
//  '<S768>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Sum Fdbk'
//  '<S769>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tracking Mode'
//  '<S770>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tracking Mode Sum'
//  '<S771>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tsamp - Integral'
//  '<S772>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tsamp - Ngain'
//  '<S773>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/postSat Signal'
//  '<S774>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/preSat Signal'
//  '<S775>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Anti-windup/Disabled'
//  '<S776>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/D Gain/Disabled'
//  '<S777>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Filter/Disabled'
//  '<S778>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Filter ICs/Disabled'
//  '<S779>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/I Gain/Disabled'
//  '<S780>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Ideal P Gain/Passthrough'
//  '<S781>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Ideal P Gain Fdbk/Disabled'
//  '<S782>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Integrator/Disabled'
//  '<S783>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Integrator ICs/Disabled'
//  '<S784>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/N Copy/Disabled wSignal Specification'
//  '<S785>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/N Gain/Disabled'
//  '<S786>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/P Copy/Disabled'
//  '<S787>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Parallel P Gain/Internal Parameters'
//  '<S788>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Reset Signal/Disabled'
//  '<S789>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Saturation/Passthrough'
//  '<S790>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Saturation Fdbk/Disabled'
//  '<S791>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Sum/Passthrough_P'
//  '<S792>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Sum Fdbk/Disabled'
//  '<S793>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tracking Mode/Disabled'
//  '<S794>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tracking Mode Sum/Passthrough'
//  '<S795>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tsamp - Integral/TsSignalSpecification'
//  '<S796>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/Tsamp - Ngain/Passthrough'
//  '<S797>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/postSat Signal/Forward_Path'
//  '<S798>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller3/preSat Signal/Forward_Path'
//  '<S799>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Anti-windup'
//  '<S800>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/D Gain'
//  '<S801>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Filter'
//  '<S802>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Filter ICs'
//  '<S803>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/I Gain'
//  '<S804>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Ideal P Gain'
//  '<S805>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Ideal P Gain Fdbk'
//  '<S806>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Integrator'
//  '<S807>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Integrator ICs'
//  '<S808>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/N Copy'
//  '<S809>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/N Gain'
//  '<S810>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/P Copy'
//  '<S811>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Parallel P Gain'
//  '<S812>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Reset Signal'
//  '<S813>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Saturation'
//  '<S814>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Saturation Fdbk'
//  '<S815>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Sum'
//  '<S816>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Sum Fdbk'
//  '<S817>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tracking Mode'
//  '<S818>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tracking Mode Sum'
//  '<S819>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tsamp - Integral'
//  '<S820>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tsamp - Ngain'
//  '<S821>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/postSat Signal'
//  '<S822>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/preSat Signal'
//  '<S823>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Anti-windup/Disabled'
//  '<S824>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/D Gain/Disabled'
//  '<S825>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Filter/Disabled'
//  '<S826>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Filter ICs/Disabled'
//  '<S827>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/I Gain/Disabled'
//  '<S828>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Ideal P Gain/Passthrough'
//  '<S829>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Ideal P Gain Fdbk/Disabled'
//  '<S830>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Integrator/Disabled'
//  '<S831>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Integrator ICs/Disabled'
//  '<S832>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/N Copy/Disabled wSignal Specification'
//  '<S833>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/N Gain/Disabled'
//  '<S834>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/P Copy/Disabled'
//  '<S835>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Parallel P Gain/Internal Parameters'
//  '<S836>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Reset Signal/Disabled'
//  '<S837>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Saturation/Passthrough'
//  '<S838>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Saturation Fdbk/Disabled'
//  '<S839>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Sum/Passthrough_P'
//  '<S840>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Sum Fdbk/Disabled'
//  '<S841>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tracking Mode/Disabled'
//  '<S842>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tracking Mode Sum/Passthrough'
//  '<S843>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tsamp - Integral/TsSignalSpecification'
//  '<S844>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/Tsamp - Ngain/Passthrough'
//  '<S845>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/postSat Signal/Forward_Path'
//  '<S846>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller4/preSat Signal/Forward_Path'
//  '<S847>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Anti-windup'
//  '<S848>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/D Gain'
//  '<S849>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Filter'
//  '<S850>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Filter ICs'
//  '<S851>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/I Gain'
//  '<S852>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Ideal P Gain'
//  '<S853>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Ideal P Gain Fdbk'
//  '<S854>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Integrator'
//  '<S855>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Integrator ICs'
//  '<S856>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/N Copy'
//  '<S857>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/N Gain'
//  '<S858>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/P Copy'
//  '<S859>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Parallel P Gain'
//  '<S860>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Reset Signal'
//  '<S861>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Saturation'
//  '<S862>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Saturation Fdbk'
//  '<S863>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Sum'
//  '<S864>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Sum Fdbk'
//  '<S865>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tracking Mode'
//  '<S866>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tracking Mode Sum'
//  '<S867>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tsamp - Integral'
//  '<S868>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tsamp - Ngain'
//  '<S869>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/postSat Signal'
//  '<S870>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/preSat Signal'
//  '<S871>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Anti-windup/Disabled'
//  '<S872>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/D Gain/Disabled'
//  '<S873>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Filter/Disabled'
//  '<S874>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Filter ICs/Disabled'
//  '<S875>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/I Gain/Disabled'
//  '<S876>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Ideal P Gain/Passthrough'
//  '<S877>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Ideal P Gain Fdbk/Disabled'
//  '<S878>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Integrator/Disabled'
//  '<S879>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Integrator ICs/Disabled'
//  '<S880>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/N Copy/Disabled wSignal Specification'
//  '<S881>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/N Gain/Disabled'
//  '<S882>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/P Copy/Disabled'
//  '<S883>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Parallel P Gain/Internal Parameters'
//  '<S884>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Reset Signal/Disabled'
//  '<S885>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Saturation/Enabled'
//  '<S886>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Saturation Fdbk/Disabled'
//  '<S887>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Sum/Passthrough_P'
//  '<S888>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Sum Fdbk/Disabled'
//  '<S889>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tracking Mode/Disabled'
//  '<S890>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tracking Mode Sum/Passthrough'
//  '<S891>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tsamp - Integral/TsSignalSpecification'
//  '<S892>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/Tsamp - Ngain/Passthrough'
//  '<S893>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/postSat Signal/Forward_Path'
//  '<S894>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Attitude controller/PID Controller5/preSat Signal/Forward_Path'
//  '<S895>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/PX4 ULog3/PX4 uORB Message'
//  '<S896>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/PX4 ULog3/PX4_log_write'
//  '<S897>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternion Validity Check/Quaternion Norm'
//  '<S898>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Angle Calculation'
//  '<S899>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Quaternion Normalize'
//  '<S900>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input'
//  '<S901>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem'
//  '<S902>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem1'
//  '<S903>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Angle Calculation/Protect asincos input/If Action Subsystem2'
//  '<S904>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus'
//  '<S905>' : 'Quadcopter_ControllerWithNavigation1/controllerAttitude/Quaternions to Rotation Angles/Quaternion Normalize/Quaternion Modulus/Quaternion Norm'

#endif                    // RTW_HEADER_Quadcopter_ControllerWithNavigation1_h_

//
// File trailer for generated code.
//
// [EOF]
//
