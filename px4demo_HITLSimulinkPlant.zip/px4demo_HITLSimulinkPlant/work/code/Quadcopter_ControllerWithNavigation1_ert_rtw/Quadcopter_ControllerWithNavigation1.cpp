//
// File: Quadcopter_ControllerWithNavigation1.cpp
//
// Code generated for Simulink model 'Quadcopter_ControllerWithNavigation1'.
//
// Model version                  : 4.12
// Simulink Coder version         : 23.2 (R2023b) 01-Aug-2023
// C/C++ source code generated on : Wed Apr  3 23:18:28 2024
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM Cortex
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "Quadcopter_ControllerWithNavigation1.h"
#include <uORB/topics/vehicle_attitude_setpoint.h>
#include <uORB/topics/actuator_controls.h>
#include "rtwtypes.h"
#include "Quadcopter_ControllerWithNavigation1_private.h"
#include <math.h>

extern "C"
{

#include "rt_nonfinite.h"

}

#include <string.h>
#include <uORB/topics/vehicle_rates_setpoint.h>
#include <uORB/topics/rate_ctrl_status.h>
#include "rt_defines.h"
#include <float.h>

const real_T Quadcopter_ControllerWithNavigation1_period = 0.01;

// Block signals (default storage)
B_Quadcopter_ControllerWithNavigation1_T Quadcopter_ControllerWithNavigation1_B;

// Block states (default storage)
DW_Quadcopter_ControllerWithNavigation1_T
  Quadcopter_ControllerWithNavigation1_DW;

// Real-time model
RT_MODEL_Quadcopter_ControllerWithNavigation1_T
  Quadcopter_ControllerWithNavigation1_M_ =
  RT_MODEL_Quadcopter_ControllerWithNavigation1_T();
RT_MODEL_Quadcopter_ControllerWithNavigation1_T *const
  Quadcopter_ControllerWithNavigation1_M =
  &Quadcopter_ControllerWithNavigation1_M_;

// Forward declaration for local functions
static real_T Quadcopter_ControllerWithNavigation1_sind(real_T x);

// Forward declaration for local functions
static real_T Quadcopter_ControllerWithNavigation1_rt_remd_snf(real_T u0, real_T
  u1);
static real_T Quadcopter_ControllerWithNavigation1_sind_n(real_T x);
static real_T Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(real_T u0,
  real_T u1);
static void Quadcopter_ControllerWithNavigation1_lla2ned(const real_T lla[3],
  const real_T lla0[3], real_T xyzNED[3]);
static real_T Quadcopter_ControllerWithNavigation1_norm(const real_T x[3]);

// System initialize for atomic system:
void Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
  (DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Start for MATLABSystem: '<S64>/PX4 Timestamp'
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
  localDW->obj.isSetupComplete = true;
}

// Output and update for atomic system:
void Quadcopter_ControllerWithNavigation1_PX4Timestamp
  (B_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T *localB)
{
  // MATLABSystem: '<S64>/PX4 Timestamp'
  localB->PX4Timestamp = hrt_absolute_time();
}

// Termination for atomic system:
void Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
  (DW_PX4Timestamp_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Terminate for MATLABSystem: '<S64>/PX4 Timestamp'
  if (!localDW->obj.matlabCodegenIsDeleted) {
    localDW->obj.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S64>/PX4 Timestamp'
}

// System initialize for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock_Init(const
  px4_Bus_vehicle_attitude_setpoint *rtu_0,
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Start for MATLABSystem: '<S369>/SinkBlock'
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
  localDW->obj.orbMetadataObj = ORB_ID(vehicle_rates_setpoint);
  uORB_write_initialize(localDW->obj.orbMetadataObj,
                        &localDW->obj.orbAdvertiseObj, rtu_0, 1);
  localDW->obj.isSetupComplete = true;
}

// Output and update for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock(const
  px4_Bus_vehicle_attitude_setpoint *rtu_0,
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // MATLABSystem: '<S369>/SinkBlock'
  uORB_write_step(localDW->obj.orbMetadataObj, &localDW->obj.orbAdvertiseObj,
                  rtu_0);
}

// Termination for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock_Term
  (DW_SinkBlock_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Terminate for MATLABSystem: '<S369>/SinkBlock'
  if (!localDW->obj.matlabCodegenIsDeleted) {
    localDW->obj.matlabCodegenIsDeleted = true;
    if ((localDW->obj.isInitialized == 1) && localDW->obj.isSetupComplete) {
      uORB_write_terminate(&localDW->obj.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S369>/SinkBlock'
}

// System initialize for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock_h_Init(const
  px4_Bus_actuator_controls *rtu_0,
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T *localDW)
{
  // Start for MATLABSystem: '<S52>/SinkBlock'
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  localDW->obj.isInitialized = 1;
  localDW->obj.orbMetadataObj = ORB_ID(actuator_controls_0);
  uORB_write_initialize(localDW->obj.orbMetadataObj,
                        &localDW->obj.orbAdvertiseObj, rtu_0, 1);
  localDW->obj.isSetupComplete = true;
}

// Output and update for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock_l(const
  px4_Bus_actuator_controls *rtu_0,
  DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T *localDW)
{
  // MATLABSystem: '<S52>/SinkBlock'
  uORB_write_step(localDW->obj.orbMetadataObj, &localDW->obj.orbAdvertiseObj,
                  rtu_0);
}

// Termination for atomic system:
void Quadcopter_ControllerWithNavigation1_SinkBlock_i_Term
  (DW_SinkBlock_Quadcopter_ControllerWithNavigation1_m_T *localDW)
{
  // Terminate for MATLABSystem: '<S52>/SinkBlock'
  if (!localDW->obj.matlabCodegenIsDeleted) {
    localDW->obj.matlabCodegenIsDeleted = true;
    if ((localDW->obj.isInitialized == 1) && localDW->obj.isSetupComplete) {
      uORB_write_terminate(&localDW->obj.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S52>/SinkBlock'
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    real_T q;
    if (u1 < 0.0) {
      q = ceil(u1);
    } else {
      q = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != q)) {
      q = fabs(u0 / u1);
      if (!(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q)) {
        y = 0.0 * u0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

static real_T Quadcopter_ControllerWithNavigation1_sind(real_T x)
{
  real_T absx;
  real_T b_x;

  // Start for MATLABSystem: '<S38>/MATLAB System'
  if (rtIsInf(x) || rtIsNaN(x)) {
    b_x = (rtNaN);
  } else {
    b_x = rt_remd_snf(x, 360.0);
    absx = fabs(b_x);
    if (absx > 180.0) {
      if (b_x > 0.0) {
        b_x -= 360.0;
      } else {
        b_x += 360.0;
      }

      absx = fabs(b_x);
    }

    if (absx <= 45.0) {
      b_x = sin(0.017453292519943295 * b_x);
    } else if (absx <= 135.0) {
      if (b_x > 0.0) {
        b_x = cos((b_x - 90.0) * 0.017453292519943295);
      } else {
        b_x = -cos((b_x + 90.0) * 0.017453292519943295);
      }
    } else {
      if (b_x > 0.0) {
        b_x = (b_x - 180.0) * 0.017453292519943295;
      } else {
        b_x = (b_x + 180.0) * 0.017453292519943295;
      }

      b_x = -sin(b_x);
    }
  }

  // End of Start for MATLABSystem: '<S38>/MATLAB System'
  return b_x;
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    int32_T tmp;
    int32_T tmp_0;
    if (u0 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u1 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = atan2(static_cast<real_T>(tmp), static_cast<real_T>(tmp_0));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

// System initialize for atomic system:
void Quadcopter_ControllerWithNavigation1_MATLABSystem_Init
  (DW_MATLABSystem_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Start for MATLABSystem: '<S38>/MATLAB System'
  localDW->obj.matlabCodegenIsDeleted = false;
  localDW->objisempty = true;
  localDW->obj.isSetupComplete = true;
}

// Output and update for atomic system:
void Quadcopter_ControllerWithNavigation1_MATLABSystem(const real_T rtu_0[3],
  const real_T rtu_1[3], boolean_T rtu_2, uint8_T rtu_3,
  B_MATLABSystem_Quadcopter_ControllerWithNavigation1_T *localB)
{
  real_T Rn_tmp;
  real_T absx;
  real_T dLon;
  real_T flat;
  real_T u;
  int32_T b_k;
  boolean_T b[3];
  boolean_T exitg1;
  boolean_T latp2;

  // MATLABSystem: '<S38>/MATLAB System'
  if (rtu_2 && (rtu_3 != 5)) {
    localB->dLat = rtu_0[0] - rtu_1[0];
    dLon = rtu_0[1] - rtu_1[1];
    flat = fabs(localB->dLat);
    if (flat > 180.0) {
      if (rtIsNaN(localB->dLat + 180.0) || rtIsInf(localB->dLat + 180.0)) {
        flat = (rtNaN);
      } else if (localB->dLat + 180.0 == 0.0) {
        flat = 0.0;
      } else {
        flat = fmod(localB->dLat + 180.0, 360.0);
        if (flat == 0.0) {
          flat = 0.0;
        } else if (localB->dLat + 180.0 < 0.0) {
          flat += 360.0;
        }
      }

      localB->dLat = localB->dLat * 0.0 + (flat - 180.0);
      flat = fabs(localB->dLat);
    }

    if (flat > 90.0) {
      flat = fabs(localB->dLat);
      latp2 = (flat > 90.0);
      dLon += 180.0;
      u = localB->dLat * static_cast<real_T>(latp2);
      if (rtIsNaN(u)) {
        u = (rtNaN);
      } else if (u < 0.0) {
        u = -1.0;
      } else {
        u = (u > 0.0);
      }

      localB->dLat = (90.0 - (flat * static_cast<real_T>(latp2) - 90.0)) * u *
        static_cast<real_T>(latp2) + localB->dLat * static_cast<real_T>(!latp2);
    }

    if ((dLon > 180.0) || (dLon < -180.0)) {
      flat = rt_remd_snf(dLon, 360.0);
      u = flat / 180.0;
      if (u < 0.0) {
        u = ceil(u);
      } else {
        u = floor(u);
      }

      dLon = (flat - 360.0 * u) + dLon * 0.0;
    }

    flat = Quadcopter_ControllerWithNavigation1_sind(rtu_1[0]);
    Rn_tmp = 1.0 - 0.0066943799901413165 * flat * flat;
    flat = 6.378137E+6 / sqrt(Rn_tmp);
    if (rtIsInf(rtu_1[0]) || rtIsNaN(rtu_1[0])) {
      u = (rtNaN);
    } else {
      u = rt_remd_snf(rtu_1[0], 360.0);
      absx = fabs(u);
      if (absx > 180.0) {
        if (u > 0.0) {
          u -= 360.0;
        } else {
          u += 360.0;
        }

        absx = fabs(u);
      }

      if (absx <= 45.0) {
        u = cos(0.017453292519943295 * u);
      } else if (absx <= 135.0) {
        if (u > 0.0) {
          u = -sin((u - 90.0) * 0.017453292519943295);
        } else {
          u = sin((u + 90.0) * 0.017453292519943295);
        }
      } else {
        if (u > 0.0) {
          u = (u - 180.0) * 0.017453292519943295;
        } else {
          u = (u + 180.0) * 0.017453292519943295;
        }

        u = -cos(u);
      }
    }

    localB->dLat /= rt_atan2d_snf(1.0, 0.99330562000985867 / Rn_tmp * flat) *
      57.295779513082323;
    dLon /= rt_atan2d_snf(1.0, flat * u) * 57.295779513082323;
    flat = -rtu_0[2] + rtu_1[2];
    b[0] = rtIsNaN(localB->dLat);
    b[1] = rtIsNaN(dLon);
    b[2] = rtIsNaN(flat);
    latp2 = false;
    b_k = 0;
    exitg1 = false;
    while ((!exitg1) && (b_k < 3)) {
      if (b[b_k]) {
        latp2 = true;
        exitg1 = true;
      } else {
        b_k++;
      }
    }

    u = 0.0 / static_cast<real_T>(!latp2);
    localB->MATLABSystem[0] = static_cast<real32_T>(u + localB->dLat);
    localB->MATLABSystem[1] = static_cast<real32_T>(u + dLon);
    localB->MATLABSystem[2] = static_cast<real32_T>(u + flat);
  } else {
    localB->MATLABSystem[0] = 0.0F;
    localB->MATLABSystem[1] = 0.0F;
    localB->MATLABSystem[2] = 0.0F;
  }

  // End of MATLABSystem: '<S38>/MATLAB System'
}

// Termination for atomic system:
void Quadcopter_ControllerWithNavigation1_MATLABSystem_Term
  (DW_MATLABSystem_Quadcopter_ControllerWithNavigation1_T *localDW)
{
  // Terminate for MATLABSystem: '<S38>/MATLAB System'
  if (!localDW->obj.matlabCodegenIsDeleted) {
    localDW->obj.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S38>/MATLAB System'
}

static real_T Quadcopter_ControllerWithNavigation1_rt_remd_snf(real_T u0, real_T
  u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    if (u1 < 0.0) {
      Quadcopter_ControllerWithNavigation1_B.q = ceil(u1);
    } else {
      Quadcopter_ControllerWithNavigation1_B.q = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != Quadcopter_ControllerWithNavigation1_B.q)) {
      Quadcopter_ControllerWithNavigation1_B.q = fabs(u0 / u1);
      if (!(fabs(Quadcopter_ControllerWithNavigation1_B.q - floor
                 (Quadcopter_ControllerWithNavigation1_B.q + 0.5)) > DBL_EPSILON
            * Quadcopter_ControllerWithNavigation1_B.q)) {
        y = 0.0 * u0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

static real_T Quadcopter_ControllerWithNavigation1_sind_n(real_T x)
{
  real_T b_x;

  // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates' incorporates:
  //   MATLABSystem: '<S41>/MATLAB System'

  if (rtIsInf(x) || rtIsNaN(x)) {
    b_x = (rtNaN);
  } else {
    b_x = Quadcopter_ControllerWithNavigation1_rt_remd_snf(x, 360.0);
    Quadcopter_ControllerWithNavigation1_B.absx_n = fabs(b_x);
    if (Quadcopter_ControllerWithNavigation1_B.absx_n > 180.0) {
      if (b_x > 0.0) {
        b_x -= 360.0;
      } else {
        b_x += 360.0;
      }

      Quadcopter_ControllerWithNavigation1_B.absx_n = fabs(b_x);
    }

    if (Quadcopter_ControllerWithNavigation1_B.absx_n <= 45.0) {
      b_x = sin(0.017453292519943295 * b_x);
    } else if (Quadcopter_ControllerWithNavigation1_B.absx_n <= 135.0) {
      if (b_x > 0.0) {
        b_x = cos((b_x - 90.0) * 0.017453292519943295);
      } else {
        b_x = -cos((b_x + 90.0) * 0.017453292519943295);
      }
    } else {
      if (b_x > 0.0) {
        b_x = (b_x - 180.0) * 0.017453292519943295;
      } else {
        b_x = (b_x + 180.0) * 0.017453292519943295;
      }

      b_x = -sin(b_x);
    }
  }

  // End of Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
  return b_x;
}

static real_T Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(real_T u0,
  real_T u1)
{
  real_T y;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u0 > 0.0) {
      Quadcopter_ControllerWithNavigation1_B.i = 1;
    } else {
      Quadcopter_ControllerWithNavigation1_B.i = -1;
    }

    if (u1 > 0.0) {
      Quadcopter_ControllerWithNavigation1_B.i1_j = 1;
    } else {
      Quadcopter_ControllerWithNavigation1_B.i1_j = -1;
    }

    y = atan2(static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.i),
              static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.i1_j));
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

static void Quadcopter_ControllerWithNavigation1_lla2ned(const real_T lla[3],
  const real_T lla0[3], real_T xyzNED[3])
{
  boolean_T exitg1;

  // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
  Quadcopter_ControllerWithNavigation1_B.dLat = lla[0] - lla0[0];
  Quadcopter_ControllerWithNavigation1_B.dLon = lla[1] - lla0[1];
  Quadcopter_ControllerWithNavigation1_B.flat = fabs
    (Quadcopter_ControllerWithNavigation1_B.dLat);
  if (Quadcopter_ControllerWithNavigation1_B.flat > 180.0) {
    // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
    if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.dLat + 180.0) || rtIsInf
        (Quadcopter_ControllerWithNavigation1_B.dLat + 180.0)) {
      Quadcopter_ControllerWithNavigation1_B.flat = (rtNaN);
    } else if (Quadcopter_ControllerWithNavigation1_B.dLat + 180.0 == 0.0) {
      Quadcopter_ControllerWithNavigation1_B.flat = 0.0;
    } else {
      Quadcopter_ControllerWithNavigation1_B.flat = fmod
        (Quadcopter_ControllerWithNavigation1_B.dLat + 180.0, 360.0);
      if (Quadcopter_ControllerWithNavigation1_B.flat == 0.0) {
        Quadcopter_ControllerWithNavigation1_B.flat = 0.0;
      } else if (Quadcopter_ControllerWithNavigation1_B.dLat + 180.0 < 0.0) {
        Quadcopter_ControllerWithNavigation1_B.flat += 360.0;
      }
    }

    Quadcopter_ControllerWithNavigation1_B.dLat =
      Quadcopter_ControllerWithNavigation1_B.dLat * 0.0 +
      (Quadcopter_ControllerWithNavigation1_B.flat - 180.0);
    Quadcopter_ControllerWithNavigation1_B.flat = fabs
      (Quadcopter_ControllerWithNavigation1_B.dLat);
  }

  if (Quadcopter_ControllerWithNavigation1_B.flat > 90.0) {
    // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
    Quadcopter_ControllerWithNavigation1_B.flat = fabs
      (Quadcopter_ControllerWithNavigation1_B.dLat);
    Quadcopter_ControllerWithNavigation1_B.latp2 =
      (Quadcopter_ControllerWithNavigation1_B.flat > 90.0);

    // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
    Quadcopter_ControllerWithNavigation1_B.dLon += 180.0;
    Quadcopter_ControllerWithNavigation1_B.Rn =
      Quadcopter_ControllerWithNavigation1_B.dLat * static_cast<real_T>
      (Quadcopter_ControllerWithNavigation1_B.latp2);
    if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.Rn)) {
      Quadcopter_ControllerWithNavigation1_B.Rn = (rtNaN);
    } else if (Quadcopter_ControllerWithNavigation1_B.Rn < 0.0) {
      Quadcopter_ControllerWithNavigation1_B.Rn = -1.0;
    } else {
      Quadcopter_ControllerWithNavigation1_B.Rn =
        (Quadcopter_ControllerWithNavigation1_B.Rn > 0.0);
    }

    Quadcopter_ControllerWithNavigation1_B.dLat = (90.0 -
      (Quadcopter_ControllerWithNavigation1_B.flat * static_cast<real_T>
       (Quadcopter_ControllerWithNavigation1_B.latp2) - 90.0)) *
      Quadcopter_ControllerWithNavigation1_B.Rn * static_cast<real_T>
      (Quadcopter_ControllerWithNavigation1_B.latp2) +
      Quadcopter_ControllerWithNavigation1_B.dLat * static_cast<real_T>
      (!Quadcopter_ControllerWithNavigation1_B.latp2);
  }

  // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
  if ((Quadcopter_ControllerWithNavigation1_B.dLon > 180.0) ||
      (Quadcopter_ControllerWithNavigation1_B.dLon < -180.0)) {
    Quadcopter_ControllerWithNavigation1_B.flat =
      Quadcopter_ControllerWithNavigation1_rt_remd_snf
      (Quadcopter_ControllerWithNavigation1_B.dLon, 360.0);
    Quadcopter_ControllerWithNavigation1_B.Rn =
      Quadcopter_ControllerWithNavigation1_B.flat / 180.0;
    if (Quadcopter_ControllerWithNavigation1_B.Rn < 0.0) {
      Quadcopter_ControllerWithNavigation1_B.Rn = ceil
        (Quadcopter_ControllerWithNavigation1_B.Rn);
    } else {
      Quadcopter_ControllerWithNavigation1_B.Rn = floor
        (Quadcopter_ControllerWithNavigation1_B.Rn);
    }

    Quadcopter_ControllerWithNavigation1_B.dLon =
      (Quadcopter_ControllerWithNavigation1_B.flat - 360.0 *
       Quadcopter_ControllerWithNavigation1_B.Rn) +
      Quadcopter_ControllerWithNavigation1_B.dLon * 0.0;
  }

  Quadcopter_ControllerWithNavigation1_B.flat =
    Quadcopter_ControllerWithNavigation1_sind_n(lla0[0]);
  Quadcopter_ControllerWithNavigation1_B.flat = 1.0 - 0.0066943799901413165 *
    Quadcopter_ControllerWithNavigation1_B.flat *
    Quadcopter_ControllerWithNavigation1_B.flat;
  Quadcopter_ControllerWithNavigation1_B.Rn = 6.378137E+6 / sqrt
    (Quadcopter_ControllerWithNavigation1_B.flat);
  if (rtIsInf(lla0[0]) || rtIsNaN(lla0[0])) {
    Quadcopter_ControllerWithNavigation1_B.b_x = (rtNaN);
  } else {
    Quadcopter_ControllerWithNavigation1_B.b_x =
      Quadcopter_ControllerWithNavigation1_rt_remd_snf(lla0[0], 360.0);
    Quadcopter_ControllerWithNavigation1_B.absx = fabs
      (Quadcopter_ControllerWithNavigation1_B.b_x);
    if (Quadcopter_ControllerWithNavigation1_B.absx > 180.0) {
      if (Quadcopter_ControllerWithNavigation1_B.b_x > 0.0) {
        Quadcopter_ControllerWithNavigation1_B.b_x -= 360.0;
      } else {
        Quadcopter_ControllerWithNavigation1_B.b_x += 360.0;
      }

      Quadcopter_ControllerWithNavigation1_B.absx = fabs
        (Quadcopter_ControllerWithNavigation1_B.b_x);
    }

    if (Quadcopter_ControllerWithNavigation1_B.absx <= 45.0) {
      Quadcopter_ControllerWithNavigation1_B.b_x = cos(0.017453292519943295 *
        Quadcopter_ControllerWithNavigation1_B.b_x);
    } else if (Quadcopter_ControllerWithNavigation1_B.absx <= 135.0) {
      if (Quadcopter_ControllerWithNavigation1_B.b_x > 0.0) {
        Quadcopter_ControllerWithNavigation1_B.b_x = -sin
          ((Quadcopter_ControllerWithNavigation1_B.b_x - 90.0) *
           0.017453292519943295);
      } else {
        Quadcopter_ControllerWithNavigation1_B.b_x = sin
          ((Quadcopter_ControllerWithNavigation1_B.b_x + 90.0) *
           0.017453292519943295);
      }
    } else {
      if (Quadcopter_ControllerWithNavigation1_B.b_x > 0.0) {
        Quadcopter_ControllerWithNavigation1_B.b_x =
          (Quadcopter_ControllerWithNavigation1_B.b_x - 180.0) *
          0.017453292519943295;
      } else {
        Quadcopter_ControllerWithNavigation1_B.b_x =
          (Quadcopter_ControllerWithNavigation1_B.b_x + 180.0) *
          0.017453292519943295;
      }

      Quadcopter_ControllerWithNavigation1_B.b_x = -cos
        (Quadcopter_ControllerWithNavigation1_B.b_x);
    }
  }

  xyzNED[0] = Quadcopter_ControllerWithNavigation1_B.dLat /
    (Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(1.0, 0.99330562000985867
      / Quadcopter_ControllerWithNavigation1_B.flat *
      Quadcopter_ControllerWithNavigation1_B.Rn) * 57.295779513082323);
  xyzNED[1] = Quadcopter_ControllerWithNavigation1_B.dLon /
    (Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(1.0,
      Quadcopter_ControllerWithNavigation1_B.Rn *
      Quadcopter_ControllerWithNavigation1_B.b_x) * 57.295779513082323);
  xyzNED[2] = -lla[2] + lla0[2];
  Quadcopter_ControllerWithNavigation1_B.b[0] = rtIsNaN(xyzNED[0]);
  Quadcopter_ControllerWithNavigation1_B.b[1] = rtIsNaN(xyzNED[1]);
  Quadcopter_ControllerWithNavigation1_B.b[2] = rtIsNaN(xyzNED[2]);
  Quadcopter_ControllerWithNavigation1_B.latp2 = false;
  Quadcopter_ControllerWithNavigation1_B.b_k = 0;
  exitg1 = false;
  while ((!exitg1) && (Quadcopter_ControllerWithNavigation1_B.b_k < 3)) {
    if (Quadcopter_ControllerWithNavigation1_B.b[Quadcopter_ControllerWithNavigation1_B.b_k])
    {
      Quadcopter_ControllerWithNavigation1_B.latp2 = true;
      exitg1 = true;
    } else {
      Quadcopter_ControllerWithNavigation1_B.b_k++;
    }
  }

  // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
  Quadcopter_ControllerWithNavigation1_B.dLat = 0.0 / static_cast<real_T>
    (!Quadcopter_ControllerWithNavigation1_B.latp2);
  xyzNED[0] += Quadcopter_ControllerWithNavigation1_B.dLat;
  xyzNED[1] += Quadcopter_ControllerWithNavigation1_B.dLat;
  xyzNED[2] += Quadcopter_ControllerWithNavigation1_B.dLat;
}

static real_T Quadcopter_ControllerWithNavigation1_norm(const real_T x[3])
{
  real_T y;
  Quadcopter_ControllerWithNavigation1_B.scale = 3.3121686421112381E-170;

  // Start for MATLABSystem: '<S19>/UAV Waypoint Follower'
  Quadcopter_ControllerWithNavigation1_B.absxk = fabs(x[0]);
  if (Quadcopter_ControllerWithNavigation1_B.absxk > 3.3121686421112381E-170) {
    y = 1.0;
    Quadcopter_ControllerWithNavigation1_B.scale =
      Quadcopter_ControllerWithNavigation1_B.absxk;
  } else {
    Quadcopter_ControllerWithNavigation1_B.t =
      Quadcopter_ControllerWithNavigation1_B.absxk / 3.3121686421112381E-170;
    y = Quadcopter_ControllerWithNavigation1_B.t *
      Quadcopter_ControllerWithNavigation1_B.t;
  }

  // Start for MATLABSystem: '<S19>/UAV Waypoint Follower'
  Quadcopter_ControllerWithNavigation1_B.absxk = fabs(x[1]);
  if (Quadcopter_ControllerWithNavigation1_B.absxk >
      Quadcopter_ControllerWithNavigation1_B.scale) {
    Quadcopter_ControllerWithNavigation1_B.t =
      Quadcopter_ControllerWithNavigation1_B.scale /
      Quadcopter_ControllerWithNavigation1_B.absxk;
    y = y * Quadcopter_ControllerWithNavigation1_B.t *
      Quadcopter_ControllerWithNavigation1_B.t + 1.0;
    Quadcopter_ControllerWithNavigation1_B.scale =
      Quadcopter_ControllerWithNavigation1_B.absxk;
  } else {
    Quadcopter_ControllerWithNavigation1_B.t =
      Quadcopter_ControllerWithNavigation1_B.absxk /
      Quadcopter_ControllerWithNavigation1_B.scale;
    y += Quadcopter_ControllerWithNavigation1_B.t *
      Quadcopter_ControllerWithNavigation1_B.t;
  }

  // Start for MATLABSystem: '<S19>/UAV Waypoint Follower'
  Quadcopter_ControllerWithNavigation1_B.absxk = fabs(x[2]);
  if (Quadcopter_ControllerWithNavigation1_B.absxk >
      Quadcopter_ControllerWithNavigation1_B.scale) {
    Quadcopter_ControllerWithNavigation1_B.t =
      Quadcopter_ControllerWithNavigation1_B.scale /
      Quadcopter_ControllerWithNavigation1_B.absxk;
    y = y * Quadcopter_ControllerWithNavigation1_B.t *
      Quadcopter_ControllerWithNavigation1_B.t + 1.0;
    Quadcopter_ControllerWithNavigation1_B.scale =
      Quadcopter_ControllerWithNavigation1_B.absxk;
  } else {
    Quadcopter_ControllerWithNavigation1_B.t =
      Quadcopter_ControllerWithNavigation1_B.absxk /
      Quadcopter_ControllerWithNavigation1_B.scale;
    y += Quadcopter_ControllerWithNavigation1_B.t *
      Quadcopter_ControllerWithNavigation1_B.t;
  }

  return Quadcopter_ControllerWithNavigation1_B.scale * sqrt(y);
}

// Model step function
void Quadcopter_ControllerWithNavigation1_step(void)
{
  boolean_T exitg1;
  boolean_T guard1;
  boolean_T guard2;

  // MATLABSystem: '<S9>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_m.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_m.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_cx, false, 1.0);

  // Outputs for Enabled SubSystem: '<S9>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S13>/Enable'

  // Start for MATLABSystem: '<S9>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S13>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_c =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_cx;
  }

  // End of Outputs for SubSystem: '<S9>/Enabled Subsystem'

  // MATLABSystem: '<S15>/Read Parameter'
  if (Quadcopter_ControllerWithNavigation1_DW.obj_p.SampleTime !=
      Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime) {
    Quadcopter_ControllerWithNavigation1_DW.obj_p.SampleTime =
      Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime;
  }

  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = MW_Param_Step
    (Quadcopter_ControllerWithNavigation1_DW.obj_p.MW_PARAMHANDLE, MW_INT32,
     &Quadcopter_ControllerWithNavigation1_B.ParamStep_p);
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    Quadcopter_ControllerWithNavigation1_B.ParamStep_p = 0;
  }

  // MATLABSystem: '<S36>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_l.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_l.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2, false, 1.0);

  // Outputs for Enabled SubSystem: '<S36>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S37>/Enable'

  // Start for MATLABSystem: '<S36>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S37>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1 =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2;
  }

  // End of Outputs for SubSystem: '<S36>/Enabled Subsystem'

  // MATLABSystem: '<S34>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_b.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_b.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_k, false, 1.0);

  // Outputs for Enabled SubSystem: '<S34>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S49>/Enable'

  // Start for MATLABSystem: '<S34>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S49>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_g =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_k;
  }

  // End of Outputs for SubSystem: '<S34>/Enabled Subsystem'

  // MATLABSystem: '<S33>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_h.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_h.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_f, false, 1.0);

  // Outputs for Enabled SubSystem: '<S33>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S48>/Enable'

  // Start for MATLABSystem: '<S33>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S48>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_o =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_f;
  }

  // End of Outputs for SubSystem: '<S33>/Enabled Subsystem'

  // MATLABSystem: '<S15>/LLA2LocalCoordinates' incorporates:
  //   MATLABSystem: '<S15>/Read Parameter'
  //   SignalConversion generated from: '<S48>/In1'
  //
  Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.b_varargout_3[2] = 0.0;
  Quadcopter_ControllerWithNavigation1_B.lla0[0] =
    Quadcopter_ControllerWithNavigation1_B.In1_o.lat;
  Quadcopter_ControllerWithNavigation1_B.lla0[1] =
    Quadcopter_ControllerWithNavigation1_B.In1_o.lon;
  Quadcopter_ControllerWithNavigation1_B.lla0[2] =
    Quadcopter_ControllerWithNavigation1_B.In1_o.alt;
  if (Quadcopter_ControllerWithNavigation1_B.In1_g.previous.valid &&
      (!Quadcopter_ControllerWithNavigation1_DW.obj_i.previousValidReceived)) {
    Quadcopter_ControllerWithNavigation1_DW.obj_i.previousValidReceived = true;
  }

  if (Quadcopter_ControllerWithNavigation1_B.In1_g.next.valid &&
      (!Quadcopter_ControllerWithNavigation1_DW.obj_i.nextValidReceived)) {
    Quadcopter_ControllerWithNavigation1_DW.obj_i.nextValidReceived = true;
  }

  if (Quadcopter_ControllerWithNavigation1_B.In1_o.valid_hpos &&
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.valid &&
      (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type != 5)) {
    if (Quadcopter_ControllerWithNavigation1_B.ParamStep_p != 0) {
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
        Quadcopter_ControllerWithNavigation1_B.In1.waypoints[0].position[0];
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
        Quadcopter_ControllerWithNavigation1_B.In1.waypoints[0].position[1];
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
        Quadcopter_ControllerWithNavigation1_B.In1.waypoints[0].position[2];
    } else {
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
        Quadcopter_ControllerWithNavigation1_B.In1_g.current.lat;
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
        Quadcopter_ControllerWithNavigation1_B.In1_g.current.lon;
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
        Quadcopter_ControllerWithNavigation1_B.In1_g.current.alt;
      Quadcopter_ControllerWithNavigation1_lla2ned
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g,
         Quadcopter_ControllerWithNavigation1_B.lla0,
         Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p);
    }
  }

  if (Quadcopter_ControllerWithNavigation1_B.In1_o.valid_hpos &&
      (Quadcopter_ControllerWithNavigation1_B.In1_g.previous.valid ||
       Quadcopter_ControllerWithNavigation1_DW.obj_i.previousValidReceived)) {
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.previous.lat;
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.previous.lon;
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.previous.alt;
    Quadcopter_ControllerWithNavigation1_lla2ned
      (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g,
       Quadcopter_ControllerWithNavigation1_B.lla0,
       Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2);
  }

  if (Quadcopter_ControllerWithNavigation1_B.In1_o.valid_hpos &&
      (Quadcopter_ControllerWithNavigation1_B.In1_g.next.valid ||
       Quadcopter_ControllerWithNavigation1_DW.obj_i.nextValidReceived)) {
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.next.lat;
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.next.lon;
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.next.alt;
    Quadcopter_ControllerWithNavigation1_lla2ned
      (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g,
       Quadcopter_ControllerWithNavigation1_B.lla0,
       Quadcopter_ControllerWithNavigation1_B.b_varargout_3);
  }

  // If: '<S14>/If' incorporates:
  //   Delay: '<S20>/Delay'
  //   Delay: '<S23>/Delay'
  //   Delay: '<S27>/Delay'
  //   MATLABSystem: '<S15>/LLA2LocalCoordinates'
  //
  Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem;
  if (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type == 3) {
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem = 0;
  } else if (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type == 4) {
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem = 1;
  } else if (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type == 0) {
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem = 2;
  } else {
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem = 3;
  }

  switch (Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem) {
   case 0:
    if (Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem !=
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction) {
      // InitializeConditions for IfAction SubSystem: '<S14>/Take-off' incorporates:
      //   ActionPort: '<S18>/Action Port'

      // InitializeConditions for If: '<S14>/If' incorporates:
      //   Delay: '<S26>/Delay'
      //   Delay: '<S27>/Delay'

      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_i =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition;
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_n =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_c;

      // End of InitializeConditions for SubSystem: '<S14>/Take-off'
    }

    // Outputs for IfAction SubSystem: '<S14>/Take-off' incorporates:
    //   ActionPort: '<S18>/Action Port'

    // Sum: '<S26>/Sum' incorporates:
    //   Constant: '<S26>/Rate'
    //   Delay: '<S26>/Delay'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_i +=
      Quadcopter_ControllerWithNavigation1_P.Rate_Value;

    // Gain: '<S26>/Gain1'
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_P.Gain1_Gain_i *
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2];

    // Outputs for Enabled SubSystem: '<S27>/Enabled Subsystem2' incorporates:
    //   EnablePort: '<S28>/Enable'

    if (Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_n > 0.0) {
      // SignalConversion generated from: '<S28>/yaw_In' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'

      Quadcopter_ControllerWithNavigation1_B.yaw_In_ik =
        Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
    }

    // End of Outputs for SubSystem: '<S27>/Enabled Subsystem2'

    // Reshape: '<S18>/Reshape' incorporates:
    //   Delay: '<S27>/Delay'
    //   Merge: '<S14>/Merge'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0];
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1];

    // Gain: '<S26>/Gain' incorporates:
    //   Delay: '<S26>/Delay'
    //   RelationalOperator: '<S26>/Relational Operator'
    //   Switch: '<S26>/Switch'

    if (!(Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 <=
          Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_i)) {
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_i;
    }

    // Reshape: '<S18>/Reshape' incorporates:
    //   Gain: '<S26>/Gain'
    //   Merge: '<S14>/Merge'
    //   Switch: '<S26>/Switch'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
      Quadcopter_ControllerWithNavigation1_P.Gain_Gain_l *
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_B.yaw_In_ik;

    // Update for Delay: '<S27>/Delay' incorporates:
    //   Constant: '<S27>/Constant'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_n =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_ki;

    // End of Outputs for SubSystem: '<S14>/Take-off'
    break;

   case 1:
    if (Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem !=
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction) {
      // InitializeConditions for IfAction SubSystem: '<S14>/Land' incorporates:
      //   ActionPort: '<S17>/Action Port'

      // InitializeConditions for If: '<S14>/If' incorporates:
      //   Delay: '<S17>/Delay'
      //   Delay: '<S22>/Delay'
      //   Delay: '<S23>/Delay'
      //   Gain: '<S22>/Gain1'

      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[0] =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_h;
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[1] =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_h;
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_l;
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_e =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_k;

      // End of InitializeConditions for SubSystem: '<S14>/Land'
    }

    // Outputs for IfAction SubSystem: '<S14>/Land' incorporates:
    //   ActionPort: '<S17>/Action Port'

    // Switch: '<S17>/Switch' incorporates:
    //   Delay: '<S17>/Delay'
    //   Logic: '<S17>/OR'
    //   RelationalOperator: '<S17>/IsNaN'

    if ((!rtIsNaN(Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0]))
        && (!rtIsNaN(Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p
                     [1]))) {
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[0] =
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0];
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[1] =
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1];
    }

    // End of Switch: '<S17>/Switch'

    // Switch: '<S22>/Switch' incorporates:
    //   Delay: '<S22>/Delay'

    if (!(Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g >
          Quadcopter_ControllerWithNavigation1_P.Switch_Threshold_h)) {
      // Gain: '<S22>/Gain1' incorporates:
      //   Gain: '<S22>/Gain'

      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
        Quadcopter_ControllerWithNavigation1_P.Gain_Gain_lz *
        Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2];
    }

    // End of Switch: '<S22>/Switch'

    // Sum: '<S22>/Subtract' incorporates:
    //   Constant: '<S22>/Rate of descent'

    Quadcopter_ControllerWithNavigation1_B.Subtract =
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g -
      Quadcopter_ControllerWithNavigation1_P.Rateofdescent_Value;

    // Gain: '<S22>/Gain1' incorporates:
    //   Gain: '<S22>/Gain2'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
      Quadcopter_ControllerWithNavigation1_P.Gain2_Gain *
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2];

    // Outputs for Enabled SubSystem: '<S23>/Enabled Subsystem2' incorporates:
    //   EnablePort: '<S25>/Enable'

    if (Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_e > 0.0) {
      // SignalConversion generated from: '<S25>/yaw_In' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'

      Quadcopter_ControllerWithNavigation1_B.yaw_In_i =
        Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
    }

    // End of Outputs for SubSystem: '<S23>/Enabled Subsystem2'

    // Reshape: '<S17>/Reshape' incorporates:
    //   Delay: '<S17>/Delay'
    //   Delay: '<S23>/Delay'
    //   Merge: '<S14>/Merge'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[0];
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[1];

    // Switch: '<S22>/Switch1' incorporates:
    //   RelationalOperator: '<S22>/GreaterThan'

    if (!(Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g >
          Quadcopter_ControllerWithNavigation1_B.Subtract)) {
      // Gain: '<S22>/Gain1'
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
        Quadcopter_ControllerWithNavigation1_B.Subtract;
    }

    // Reshape: '<S17>/Reshape' incorporates:
    //   Gain: '<S22>/Gain1'
    //   Merge: '<S14>/Merge'
    //   Switch: '<S22>/Switch1'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
      Quadcopter_ControllerWithNavigation1_P.Gain1_Gain_m *
      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g;
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_B.yaw_In_i;

    // Outputs for Enabled SubSystem: '<S22>/Enabled Subsystem' incorporates:
    //   EnablePort: '<S24>/Enable'

    if (Quadcopter_ControllerWithNavigation1_B.Subtract > 0.0) {
      // SignalConversion generated from: '<S24>/In'
      Quadcopter_ControllerWithNavigation1_B.In =
        Quadcopter_ControllerWithNavigation1_B.Subtract;
    }

    // End of Outputs for SubSystem: '<S22>/Enabled Subsystem'

    // Update for Delay: '<S17>/Delay' incorporates:
    //   DataTypeConversion: '<S1>/Data Type Conversion1'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_c.x;
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_c.y;

    // Update for Gain: '<S22>/Gain1' incorporates:
    //   Delay: '<S22>/Delay'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
      Quadcopter_ControllerWithNavigation1_B.In;

    // Update for Delay: '<S23>/Delay' incorporates:
    //   Constant: '<S23>/Constant'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_e =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_fn;

    // End of Outputs for SubSystem: '<S14>/Land'
    break;

   case 2:
    if (Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem !=
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction) {
      // SystemReset for IfAction SubSystem: '<S14>/Waypoint' incorporates:
      //   ActionPort: '<S19>/Action Port'

      // SystemReset for If: '<S14>/If' incorporates:
      //   MATLABSystem: '<S19>/UAV Waypoint Follower'
      //
      Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex = 1.0;
      for (Quadcopter_ControllerWithNavigation1_B.j = 0;
           Quadcopter_ControllerWithNavigation1_B.j < 9;
           Quadcopter_ControllerWithNavigation1_B.j++) {
        Quadcopter_ControllerWithNavigation1_DW.obj.WaypointsInternal[Quadcopter_ControllerWithNavigation1_B.j]
          *= 0.0;
      }

      // End of SystemReset for If: '<S14>/If'
      // End of SystemReset for SubSystem: '<S14>/Waypoint'
    }

    // Outputs for IfAction SubSystem: '<S14>/Waypoint' incorporates:
    //   ActionPort: '<S19>/Action Port'

    // Concatenate: '<S19>/Matrix Concatenate'
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[0] =
      Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[1] =
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[2] =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[3] =
      Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[4] =
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[5] =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[6] =
      Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[7] =
      Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2];
    Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[8] =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_3[2];

    // MATLABSystem: '<S19>/UAV Waypoint Follower' incorporates:
    //   Concatenate: '<S19>/Matrix Concatenate'
    //   Constant: '<S19>/Constant'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_fa;
    Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistFlag = 0U;
    if (Quadcopter_ControllerWithNavigation1_P.Constant_Value_fa < 0.3) {
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 = 0.3;
      Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistFlag = 1U;
    }

    Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[0] = 0.0;
    Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[1] = 0.0;
    Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[2] = 0.0;
    Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[3] = 0.0;
    Quadcopter_ControllerWithNavigation1_DW.obj.NumWaypoints = 3.0;
    Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = false;
    Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b = true;
    Quadcopter_ControllerWithNavigation1_B.i1 = 0;
    exitg1 = false;
    while ((!exitg1) && (Quadcopter_ControllerWithNavigation1_B.i1 <= 8)) {
      Quadcopter_ControllerWithNavigation1_B.j =
        Quadcopter_ControllerWithNavigation1_B.i1 / 3 * 3 +
        Quadcopter_ControllerWithNavigation1_B.i1 % 3;
      if (!(Quadcopter_ControllerWithNavigation1_DW.obj.WaypointsInternal[Quadcopter_ControllerWithNavigation1_B.j]
            ==
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[Quadcopter_ControllerWithNavigation1_B.j]))
      {
        Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b = false;
        exitg1 = true;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i1++;
      }
    }

    if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b) {
      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = true;
    }

    if (!Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
      memcpy(&Quadcopter_ControllerWithNavigation1_DW.obj.WaypointsInternal[0],
             &Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[0], 9U *
             sizeof(real_T));
      Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex = 1.0;
    }

    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 3;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[Quadcopter_ControllerWithNavigation1_B.j]
        = true;
      Quadcopter_ControllerWithNavigation1_B.Subtract =
        Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[3 *
        Quadcopter_ControllerWithNavigation1_B.j + 1];
      Quadcopter_ControllerWithNavigation1_B.i1 =
        Quadcopter_ControllerWithNavigation1_B.j << 1;
      Quadcopter_ControllerWithNavigation1_B.x[Quadcopter_ControllerWithNavigation1_B.i1]
        = (Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[3 *
           Quadcopter_ControllerWithNavigation1_B.j] !=
           Quadcopter_ControllerWithNavigation1_B.Subtract);
      Quadcopter_ControllerWithNavigation1_B.x[Quadcopter_ControllerWithNavigation1_B.i1
        + 1] = (Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[3 *
                Quadcopter_ControllerWithNavigation1_B.j + 2] !=
                Quadcopter_ControllerWithNavigation1_B.Subtract);
    }

    Quadcopter_ControllerWithNavigation1_B.IsNaN_b[0] = false;
    Quadcopter_ControllerWithNavigation1_B.IsNaN_b[1] = false;
    Quadcopter_ControllerWithNavigation1_B.i1 = 0;
    Quadcopter_ControllerWithNavigation1_B.i2 = 4;
    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 2;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      Quadcopter_ControllerWithNavigation1_B.i1++;
      Quadcopter_ControllerWithNavigation1_B.i2++;
      Quadcopter_ControllerWithNavigation1_B.ix =
        Quadcopter_ControllerWithNavigation1_B.i1;
      exitg1 = false;
      while ((!exitg1) && (Quadcopter_ControllerWithNavigation1_B.ix <=
                           Quadcopter_ControllerWithNavigation1_B.i2)) {
        if (Quadcopter_ControllerWithNavigation1_B.x[Quadcopter_ControllerWithNavigation1_B.ix
            - 1]) {
          Quadcopter_ControllerWithNavigation1_B.IsNaN_b[Quadcopter_ControllerWithNavigation1_B.j]
            = true;
          exitg1 = true;
        } else {
          Quadcopter_ControllerWithNavigation1_B.ix += 2;
        }
      }
    }

    Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[0] =
      Quadcopter_ControllerWithNavigation1_B.IsNaN_b[0];
    Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[1] =
      Quadcopter_ControllerWithNavigation1_B.IsNaN_b[1];

    // End of Outputs for SubSystem: '<S14>/Waypoint'
    Quadcopter_ControllerWithNavigation1_B.i1 = 0;
    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 3;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      // Outputs for IfAction SubSystem: '<S14>/Waypoint' incorporates:
      //   ActionPort: '<S19>/Action Port'

      if (Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[Quadcopter_ControllerWithNavigation1_B.j])
      {
        Quadcopter_ControllerWithNavigation1_B.i1++;
      }

      // End of Outputs for SubSystem: '<S14>/Waypoint'
    }

    Quadcopter_ControllerWithNavigation1_B.ix =
      Quadcopter_ControllerWithNavigation1_B.i1;
    Quadcopter_ControllerWithNavigation1_B.i1 = 0;
    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 3;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      // Outputs for IfAction SubSystem: '<S14>/Waypoint' incorporates:
      //   ActionPort: '<S19>/Action Port'

      if (Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[Quadcopter_ControllerWithNavigation1_B.j])
      {
        // Start for MATLABSystem: '<S19>/UAV Waypoint Follower'
        Quadcopter_ControllerWithNavigation1_B.tmp_data[Quadcopter_ControllerWithNavigation1_B.i1]
          = static_cast<int8_T>(Quadcopter_ControllerWithNavigation1_B.j);
        Quadcopter_ControllerWithNavigation1_B.i1++;
      }

      // End of Outputs for SubSystem: '<S14>/Waypoint'
    }

    // Outputs for IfAction SubSystem: '<S14>/Waypoint' incorporates:
    //   ActionPort: '<S19>/Action Port'

    // MATLABSystem: '<S19>/UAV Waypoint Follower' incorporates:
    //   Concatenate: '<S19>/Matrix Concatenate'
    //   DataTypeConversion: '<S1>/Data Type Conversion1'
    //   Reshape: '<S19>/Reshape1'

    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 3;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      for (Quadcopter_ControllerWithNavigation1_B.i2 = 0;
           Quadcopter_ControllerWithNavigation1_B.i2 <
           Quadcopter_ControllerWithNavigation1_B.ix;
           Quadcopter_ControllerWithNavigation1_B.i2++) {
        Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[Quadcopter_ControllerWithNavigation1_B.i2
          + Quadcopter_ControllerWithNavigation1_B.ix *
          Quadcopter_ControllerWithNavigation1_B.j] =
          Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[3 *
          Quadcopter_ControllerWithNavigation1_B.j +
          Quadcopter_ControllerWithNavigation1_B.tmp_data[Quadcopter_ControllerWithNavigation1_B.i2]];
      }
    }

    Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistance =
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
    if (Quadcopter_ControllerWithNavigation1_B.ix == 0) {
      Quadcopter_ControllerWithNavigation1_B.lla0[0] =
        Quadcopter_ControllerWithNavigation1_B.In1_c.x;
      Quadcopter_ControllerWithNavigation1_B.lla0[1] =
        Quadcopter_ControllerWithNavigation1_B.In1_c.y;
      Quadcopter_ControllerWithNavigation1_B.lla0[2] =
        Quadcopter_ControllerWithNavigation1_B.In1_c.z;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
    } else {
      guard1 = false;
      if (Quadcopter_ControllerWithNavigation1_B.ix == 1) {
        if (Quadcopter_ControllerWithNavigation1_DW.obj.StartFlag) {
          Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x;
          Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y;
          Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z;
          Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[3] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
        }

        Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] =
          Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[0] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.x;
        Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] =
          Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[1] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.y;
        Quadcopter_ControllerWithNavigation1_B.b_varargout_3[2] =
          Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[2] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.z;
        if (Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.b_varargout_3) <
            1.4901161193847656E-8) {
          Quadcopter_ControllerWithNavigation1_B.lla0[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x;
          Quadcopter_ControllerWithNavigation1_B.lla0[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y;
          Quadcopter_ControllerWithNavigation1_B.lla0[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z;
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
          Quadcopter_ControllerWithNavigation1_DW.obj.StartFlag = false;
        } else {
          Quadcopter_ControllerWithNavigation1_DW.obj.StartFlag = false;
          Quadcopter_ControllerWithNavigation1_DW.obj.NumWaypoints = 2.0;
          Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 =
            Quadcopter_ControllerWithNavigation1_B.ix + 1;
          for (Quadcopter_ControllerWithNavigation1_B.j = 0;
               Quadcopter_ControllerWithNavigation1_B.j < 3;
               Quadcopter_ControllerWithNavigation1_B.j++) {
            Quadcopter_ControllerWithNavigation1_B.i1 =
              (Quadcopter_ControllerWithNavigation1_B.ix + 1) *
              Quadcopter_ControllerWithNavigation1_B.j;
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[Quadcopter_ControllerWithNavigation1_B.i1]
              =
              Quadcopter_ControllerWithNavigation1_DW.obj.InitialPose[Quadcopter_ControllerWithNavigation1_B.j];
            for (Quadcopter_ControllerWithNavigation1_B.i2 = 0;
                 Quadcopter_ControllerWithNavigation1_B.i2 <
                 Quadcopter_ControllerWithNavigation1_B.ix;
                 Quadcopter_ControllerWithNavigation1_B.i2++) {
              Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a
                [(Quadcopter_ControllerWithNavigation1_B.i2 +
                  Quadcopter_ControllerWithNavigation1_B.i1) + 1] =
                Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[Quadcopter_ControllerWithNavigation1_B.ix
                * Quadcopter_ControllerWithNavigation1_B.j +
                Quadcopter_ControllerWithNavigation1_B.i2];
            }
          }

          guard1 = true;
        }
      } else {
        Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 =
          Quadcopter_ControllerWithNavigation1_B.ix;
        Quadcopter_ControllerWithNavigation1_B.i1 =
          Quadcopter_ControllerWithNavigation1_B.ix * 3;
        if (Quadcopter_ControllerWithNavigation1_B.i1 - 1 >= 0) {
          memcpy(&Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[0],
                 &Quadcopter_ControllerWithNavigation1_B.b_waypointsIn_data[0],
                 static_cast<uint32_T>(Quadcopter_ControllerWithNavigation1_B.i1)
                 * sizeof(real_T));
        }

        guard1 = true;
      }

      if (guard1) {
        Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = false;
        if (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex ==
            Quadcopter_ControllerWithNavigation1_DW.obj.NumWaypoints) {
          Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = true;
        }

        if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
          Quadcopter_ControllerWithNavigation1_DW.obj.LastWaypointFlag = true;
          Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex--;
        }

        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
          Quadcopter_ControllerWithNavigation1_B.In1_c.x -
          Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
          static_cast<int32_T>
          (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) - 1];
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
          Quadcopter_ControllerWithNavigation1_B.In1_c.y -
          Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
          static_cast<int32_T>
          (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
          Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
          Quadcopter_ControllerWithNavigation1_B.In1_c.z -
          Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
          static_cast<int32_T>
          (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
          (Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 << 1)) -
          1];
        guard2 = false;
        if (Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g) <=
            2.0) {
          guard2 = true;
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) -
            1];
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] =
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 -
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) - 1];
          Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x -
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
            Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] =
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 -
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) +
            Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
          Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y -
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
            (Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 << 1))
            - 1];
          Quadcopter_ControllerWithNavigation1_B.Subtract =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a
            [((Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 << 1)
              + static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex)) - 1];
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] =
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
            Quadcopter_ControllerWithNavigation1_B.Subtract;
          Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z -
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2);
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p);
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            (Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] /
             Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
             * (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] /
                Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] /
             Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
             * (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] /
                Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3)) +
            Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] /
            Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
            (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] /
             Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3);
          if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) ||
              (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 < 0.0)) {
            Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] =
              Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
              static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) - 1];
            Quadcopter_ControllerWithNavigation1_B.lla0[0] =
              Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
              static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0)
              - 1];
            Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] =
              Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
              static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) +
              Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
            Quadcopter_ControllerWithNavigation1_B.lla0[1] =
              Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
              static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0)
              + Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
            Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] =
              Quadcopter_ControllerWithNavigation1_B.Subtract;
            Quadcopter_ControllerWithNavigation1_B.lla0[2] =
              Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;
          } else {
            guard2 = true;
          }
        }

        if (guard2) {
          Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex++;
          Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = false;
          if (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex ==
              Quadcopter_ControllerWithNavigation1_DW.obj.NumWaypoints) {
            Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = true;
          }

          if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
            Quadcopter_ControllerWithNavigation1_DW.obj.LastWaypointFlag = true;
            Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex--;
          }

          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) - 1];
          Quadcopter_ControllerWithNavigation1_B.lla0[0] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) -
            1];
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex) +
            Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
          Quadcopter_ControllerWithNavigation1_B.lla0[1] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
            Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0) - 1];
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a
            [((Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 << 1)
              + static_cast<int32_T>
              (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex)) - 1];
          Quadcopter_ControllerWithNavigation1_B.lla0[2] =
            Quadcopter_ControllerWithNavigation1_B.MatrixConcatenate_a[(
            static_cast<int32_T>
            (Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex + 1.0) +
            (Quadcopter_ControllerWithNavigation1_B.waypoints_size_idx_0 << 1))
            - 1];
        }

        Quadcopter_ControllerWithNavigation1_B.Subtract =
          Quadcopter_ControllerWithNavigation1_B.In1_c.x -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0];
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
          Quadcopter_ControllerWithNavigation1_B.Subtract;
        Quadcopter_ControllerWithNavigation1_B.Product2 =
          Quadcopter_ControllerWithNavigation1_B.lla0[0] -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0];
        Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] =
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_B.Subtract *
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
          Quadcopter_ControllerWithNavigation1_B.Product2 *
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          Quadcopter_ControllerWithNavigation1_B.In1_c.y -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1];
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1;
        Quadcopter_ControllerWithNavigation1_B.Product2 =
          Quadcopter_ControllerWithNavigation1_B.lla0[1] -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1];
        Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] =
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 +=
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 +=
          Quadcopter_ControllerWithNavigation1_B.Product2 *
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.dist =
          Quadcopter_ControllerWithNavigation1_B.In1_c.z -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2];
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
          Quadcopter_ControllerWithNavigation1_B.dist;
        Quadcopter_ControllerWithNavigation1_B.Product2 =
          Quadcopter_ControllerWithNavigation1_B.lla0[2] -
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2];
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 +=
          Quadcopter_ControllerWithNavigation1_B.Product2 *
          Quadcopter_ControllerWithNavigation1_B.Product2;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          (Quadcopter_ControllerWithNavigation1_B.dist *
           Quadcopter_ControllerWithNavigation1_B.Product2 +
           Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2) /
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
        if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 < 0.0) {
          Quadcopter_ControllerWithNavigation1_B.dist =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p);
        } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 1.0)
        {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x -
            Quadcopter_ControllerWithNavigation1_B.lla0[0];
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y -
            Quadcopter_ControllerWithNavigation1_B.lla0[1];
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z -
            Quadcopter_ControllerWithNavigation1_B.lla0[2];
          Quadcopter_ControllerWithNavigation1_B.dist =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g);
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0]);
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1]);
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.Product2 +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2]);
          Quadcopter_ControllerWithNavigation1_B.dist =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g);
        }

        if (Quadcopter_ControllerWithNavigation1_DW.obj.LastWaypointFlag) {
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
            ((Quadcopter_ControllerWithNavigation1_B.Subtract *
              Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] +
              Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
              * Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1]) +
             (Quadcopter_ControllerWithNavigation1_B.In1_c.z -
              Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2]) *
             Quadcopter_ControllerWithNavigation1_B.Product2) /
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[0] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.x -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0]);
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[1] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.y -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1]);
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g[2] =
            Quadcopter_ControllerWithNavigation1_B.In1_c.z -
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
             Quadcopter_ControllerWithNavigation1_B.Product2 +
             Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2]);
          Quadcopter_ControllerWithNavigation1_B.dist =
            Quadcopter_ControllerWithNavigation1_norm
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_g);
        }

        Quadcopter_ControllerWithNavigation1_B.Subtract = fabs
          (Quadcopter_ControllerWithNavigation1_B.dist);
        if (rtIsInf(Quadcopter_ControllerWithNavigation1_B.Subtract) || rtIsNaN
            (Quadcopter_ControllerWithNavigation1_B.Subtract)) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            (rtNaN);
          Quadcopter_ControllerWithNavigation1_B.Subtract = (rtNaN);
        } else if (Quadcopter_ControllerWithNavigation1_B.Subtract <
                   4.4501477170144028E-308) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            4.94065645841247E-324;
          Quadcopter_ControllerWithNavigation1_B.Subtract =
            4.94065645841247E-324;
        } else {
          frexp(Quadcopter_ControllerWithNavigation1_B.Subtract,
                &Quadcopter_ControllerWithNavigation1_B.b_exponent);
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            ldexp(1.0, Quadcopter_ControllerWithNavigation1_B.b_exponent - 53);
          frexp(Quadcopter_ControllerWithNavigation1_B.Subtract,
                &Quadcopter_ControllerWithNavigation1_B.b_exponent_l);
          Quadcopter_ControllerWithNavigation1_B.Subtract = ldexp(1.0,
            Quadcopter_ControllerWithNavigation1_B.b_exponent_l - 53);
        }

        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = sqrt
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1);
        Quadcopter_ControllerWithNavigation1_B.Subtract *= 5.0;
        if ((Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >=
             Quadcopter_ControllerWithNavigation1_B.Subtract) || rtIsNaN
            (Quadcopter_ControllerWithNavigation1_B.Subtract)) {
          Quadcopter_ControllerWithNavigation1_B.Subtract =
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;
        }

        if (Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistance <=
            Quadcopter_ControllerWithNavigation1_B.dist +
            Quadcopter_ControllerWithNavigation1_B.Subtract) {
          Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistance =
            Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadFactor *
            Quadcopter_ControllerWithNavigation1_B.dist;
        }

        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.x;
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.y;
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] -
          Quadcopter_ControllerWithNavigation1_B.In1_c.z;
        Quadcopter_ControllerWithNavigation1_B.Subtract =
          ((Quadcopter_ControllerWithNavigation1_B.b_varargout_3[0] *
            Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] +
            Quadcopter_ControllerWithNavigation1_B.b_varargout_3[1] *
            Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1]) +
           Quadcopter_ControllerWithNavigation1_B.Product2 *
           Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2]) * 2.0;
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          sqrt(Quadcopter_ControllerWithNavigation1_B.Subtract *
               Quadcopter_ControllerWithNavigation1_B.Subtract -
               (((Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] *
                  Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0]
                  + Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1]
                  * Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1])
                 + Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2]
                 * Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2])
                - Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistance *
                Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadDistance) *
               (4.0 * Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3));
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          (-Quadcopter_ControllerWithNavigation1_B.Subtract +
           Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) /
          2.0 / Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
          (-Quadcopter_ControllerWithNavigation1_B.Subtract -
           Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) /
          2.0 / Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
        if ((Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >=
             Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) || rtIsNaN
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3)) {
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;
        }

        Quadcopter_ControllerWithNavigation1_B.lla0[0] = (1.0 -
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) *
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] +
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 *
          Quadcopter_ControllerWithNavigation1_B.lla0[0];
        Quadcopter_ControllerWithNavigation1_B.lla0[1] = (1.0 -
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) *
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] +
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 *
          Quadcopter_ControllerWithNavigation1_B.lla0[1];
        Quadcopter_ControllerWithNavigation1_B.lla0[2] = (1.0 -
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3) *
          Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] +
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 *
          Quadcopter_ControllerWithNavigation1_B.lla0[2];
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
          Quadcopter_ControllerWithNavigation1_rt_atan2d_snf
          (Quadcopter_ControllerWithNavigation1_B.lla0[1] -
           Quadcopter_ControllerWithNavigation1_B.In1_c.y,
           Quadcopter_ControllerWithNavigation1_B.lla0[0] -
           Quadcopter_ControllerWithNavigation1_B.In1_c.x);
        Quadcopter_ControllerWithNavigation1_DW.obj.LastWaypointFlag = false;
      }
    }

    // Switch: '<S29>/Switch1' incorporates:
    //   Constant: '<S30>/Constant'
    //   DataTypeConversion: '<S1>/Data Type Conversion1'
    //   Logic: '<S29>/OR'
    //   Logic: '<S29>/OR1'
    //   MATLABSystem: '<S19>/UAV Waypoint Follower'
    //   Merge: '<S14>/Merge'
    //   RelationalOperator: '<S29>/IsNaN'
    //   RelationalOperator: '<S29>/IsNaN1'
    //   RelationalOperator: '<S30>/Compare'
    //   Switch: '<S29>/Switch'
    //
    if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.lla0[0]) || rtIsNaN
        (Quadcopter_ControllerWithNavigation1_B.lla0[1]) || rtIsNaN
        (Quadcopter_ControllerWithNavigation1_B.lla0[2]) ||
        (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type ==
         Quadcopter_ControllerWithNavigation1_P.CompareToConstant_const)) {
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        Quadcopter_ControllerWithNavigation1_B.In1_c.x;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        Quadcopter_ControllerWithNavigation1_B.In1_c.y;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.In1_c.z;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
    } else {
      if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3)) {
        // Switch: '<S29>/Switch' incorporates:
        //   Constant: '<S29>/Constant'
        //   Merge: '<S14>/Merge'
        //   Reshape: '<S29>/Reshape2'

        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_dx;
      }

      // Math: '<S29>/Transpose1' incorporates:
      //   Merge: '<S14>/Merge'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        Quadcopter_ControllerWithNavigation1_B.lla0[0];
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        Quadcopter_ControllerWithNavigation1_B.lla0[1];
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.lla0[2];
    }

    // End of Switch: '<S29>/Switch1'
    // End of Outputs for SubSystem: '<S14>/Waypoint'
    break;

   default:
    if (Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem !=
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction) {
      // InitializeConditions for IfAction SubSystem: '<S14>/IDLE' incorporates:
      //   ActionPort: '<S16>/Action Port'

      // InitializeConditions for If: '<S14>/If' incorporates:
      //   Delay: '<S20>/Delay'

      Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE =
        Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_n;

      // End of InitializeConditions for SubSystem: '<S14>/IDLE'
    }

    // Outputs for IfAction SubSystem: '<S14>/IDLE' incorporates:
    //   ActionPort: '<S16>/Action Port'

    // Outputs for Enabled SubSystem: '<S20>/Enabled Subsystem2' incorporates:
    //   EnablePort: '<S21>/Enable'

    if (Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE > 0.0) {
      // SignalConversion generated from: '<S21>/yaw_In' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'

      Quadcopter_ControllerWithNavigation1_B.yaw_In =
        Quadcopter_ControllerWithNavigation1_B.In1_c.heading;
    }

    // End of Outputs for SubSystem: '<S20>/Enabled Subsystem2'

    // Reshape: '<S16>/Reshape1' incorporates:
    //   DataTypeConversion: '<S1>/Data Type Conversion1'
    //   Delay: '<S20>/Delay'
    //   Merge: '<S14>/Merge'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
      Quadcopter_ControllerWithNavigation1_B.In1_c.x;
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
      Quadcopter_ControllerWithNavigation1_B.In1_c.y;
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
      Quadcopter_ControllerWithNavigation1_B.In1_c.z;
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_B.yaw_In;

    // Update for Delay: '<S20>/Delay' incorporates:
    //   Constant: '<S20>/Constant'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_gj;

    // End of Outputs for SubSystem: '<S14>/IDLE'
    break;
  }

  // End of If: '<S14>/If'

  // MATLABSystem: '<S582>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_n.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_n.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_b, false, 5000.0);

  // Outputs for Enabled SubSystem: '<S582>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S583>/Enable'

  // Start for MATLABSystem: '<S582>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S583>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_d =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_b;
  }

  // End of Outputs for SubSystem: '<S582>/Enabled Subsystem'

  // MATLABSystem: '<S6>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_po.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_po.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_c, false, 1.0);

  // Outputs for Enabled SubSystem: '<S6>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S10>/Enable'

  // Start for MATLABSystem: '<S6>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S10>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_l =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_c;
  }

  // End of Outputs for SubSystem: '<S6>/Enabled Subsystem'

  // MATLABSystem: '<S8>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_g.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_g.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_p, false, 1.0);

  // Outputs for Enabled SubSystem: '<S8>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S12>/Enable'

  // Start for MATLABSystem: '<S8>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S12>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_m =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_p;
  }

  // End of Outputs for SubSystem: '<S8>/Enabled Subsystem'

  // DataTypeConversion: '<S1>/Data Type Conversion'
  Quadcopter_ControllerWithNavigation1_B.Subtract =
    Quadcopter_ControllerWithNavigation1_B.In1_m.q[0];
  Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
    Quadcopter_ControllerWithNavigation1_B.In1_m.q[1];
  Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
    Quadcopter_ControllerWithNavigation1_B.In1_m.q[2];
  Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
    Quadcopter_ControllerWithNavigation1_B.In1_m.q[3];

  // MATLABSystem: '<S7>/SourceBlock'
  Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = uORB_read_step
    (Quadcopter_ControllerWithNavigation1_DW.obj_d0.orbMetadataObj,
     &Quadcopter_ControllerWithNavigation1_DW.obj_d0.eventStructObj,
     &Quadcopter_ControllerWithNavigation1_B.b_varargout_2_g, false, 1.0);

  // Outputs for Enabled SubSystem: '<S7>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S11>/Enable'

  // Start for MATLABSystem: '<S7>/SourceBlock'
  if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
    // SignalConversion generated from: '<S11>/In1'
    Quadcopter_ControllerWithNavigation1_B.In1_b =
      Quadcopter_ControllerWithNavigation1_B.b_varargout_2_g;
  }

  // End of Outputs for SubSystem: '<S7>/Enabled Subsystem'

  // If: '<Root>/If'
  if (Quadcopter_ControllerWithNavigation1_B.In1_d.values[5] > 1199) {
    // Outputs for IfAction SubSystem: '<Root>/Position & Rate Controller' incorporates:
    //   ActionPort: '<S3>/Action Port'

    // Switch: '<S55>/Switch' incorporates:
    //   Constant: '<S55>/Constant'
    //   DataTypeConversion: '<S1>/Data Type Conversion'
    //   Product: '<S573>/Product'
    //   Product: '<S573>/Product1'
    //   Product: '<S573>/Product2'
    //   Product: '<S573>/Product3'
    //   Sum: '<S573>/Sum'

    if (!(((static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[0])
            * Quadcopter_ControllerWithNavigation1_B.In1_m.q[0] +
            static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[1])
            * Quadcopter_ControllerWithNavigation1_B.In1_m.q[1]) +
           static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[2])
           * Quadcopter_ControllerWithNavigation1_B.In1_m.q[2]) +
          static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[3])
          * Quadcopter_ControllerWithNavigation1_B.In1_m.q[3] >
          Quadcopter_ControllerWithNavigation1_P.Switch_Threshold_l)) {
      Quadcopter_ControllerWithNavigation1_B.Subtract =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_im[0];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_im[1];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_im[2];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_im[3];
    }

    // End of Switch: '<S55>/Switch'

    // Sqrt: '<S580>/sqrt' incorporates:
    //   Product: '<S581>/Product'
    //   Product: '<S581>/Product1'
    //   Product: '<S581>/Product2'
    //   Product: '<S581>/Product3'
    //   Sum: '<S581>/Sum'

    Quadcopter_ControllerWithNavigation1_B.Product2 = sqrt
      (((Quadcopter_ControllerWithNavigation1_B.Subtract *
         Quadcopter_ControllerWithNavigation1_B.Subtract +
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) +
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2) +
       Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 *
       Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3);

    // Product: '<S575>/Product'
    Quadcopter_ControllerWithNavigation1_B.dist =
      Quadcopter_ControllerWithNavigation1_B.Subtract /
      Quadcopter_ControllerWithNavigation1_B.Product2;

    // Product: '<S575>/Product1'
    Quadcopter_ControllerWithNavigation1_B.Integrator_a =
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 /
      Quadcopter_ControllerWithNavigation1_B.Product2;

    // Product: '<S575>/Product2'
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 /=
      Quadcopter_ControllerWithNavigation1_B.Product2;

    // Product: '<S575>/Product3'
    Quadcopter_ControllerWithNavigation1_B.Product2 =
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 /
      Quadcopter_ControllerWithNavigation1_B.Product2;

    // Fcn: '<S56>/fcn2' incorporates:
    //   Fcn: '<S56>/fcn5'

    Quadcopter_ControllerWithNavigation1_B.Subtract =
      Quadcopter_ControllerWithNavigation1_B.dist *
      Quadcopter_ControllerWithNavigation1_B.dist;
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
      Quadcopter_ControllerWithNavigation1_B.Integrator_a *
      Quadcopter_ControllerWithNavigation1_B.Integrator_a;
    Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp =
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 *
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;
    Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp_m =
      Quadcopter_ControllerWithNavigation1_B.Product2 *
      Quadcopter_ControllerWithNavigation1_B.Product2;

    // Trigonometry: '<S574>/Trigonometric Function1' incorporates:
    //   Fcn: '<S56>/fcn1'
    //   Fcn: '<S56>/fcn2'

    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
      Quadcopter_ControllerWithNavigation1_rt_atan2d_snf
      ((Quadcopter_ControllerWithNavigation1_B.Integrator_a *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 +
        Quadcopter_ControllerWithNavigation1_B.dist *
        Quadcopter_ControllerWithNavigation1_B.Product2) * 2.0,
       ((Quadcopter_ControllerWithNavigation1_B.Subtract +
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) -
        Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp) -
       Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp_m);

    // Fcn: '<S56>/fcn3'
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
      (Quadcopter_ControllerWithNavigation1_B.Integrator_a *
       Quadcopter_ControllerWithNavigation1_B.Product2 -
       Quadcopter_ControllerWithNavigation1_B.dist *
       Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2) *
      -2.0;

    // Outputs for Enabled SubSystem: '<S50>/Attitude controller' incorporates:
    //   EnablePort: '<S53>/Enable'

    // Outputs for Enabled SubSystem: '<S50>/Position & Altitude controller' incorporates:
    //   EnablePort: '<S54>/Enable'

    if (Quadcopter_ControllerWithNavigation1_B.In1_b.armed) {
      // Gain: '<S370>/Gain1' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'

      Quadcopter_ControllerWithNavigation1_B.Gain1 =
        Quadcopter_ControllerWithNavigation1_P.Gain1_Gain *
        Quadcopter_ControllerWithNavigation1_B.In1_c.z;

      // Switch: '<S376>/Switch' incorporates:
      //   Constant: '<S370>/Constant'
      //   RelationalOperator: '<S376>/UpperRelop'
      //   Switch: '<S376>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.Gain1 <
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_j4) {
        Quadcopter_ControllerWithNavigation1_B.Gain1 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_j4;
      }

      // Sum: '<S54>/Sum2' incorporates:
      //   Gain: '<S50>/Gain'
      //   Switch: '<S376>/Switch'
      //   Switch: '<S376>/Switch2'

      Quadcopter_ControllerWithNavigation1_B.Filter_l =
        Quadcopter_ControllerWithNavigation1_P.Gain_Gain_c *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
        Quadcopter_ControllerWithNavigation1_B.Gain1;

      // Gain: '<S511>/Proportional Gain'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_P.PID_Altitude_P *
        Quadcopter_ControllerWithNavigation1_B.Filter_l;

      // Gain: '<S509>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S501>/Filter'
      //   Gain: '<S500>/Derivative Gain'
      //   Sum: '<S501>/SumD'

      Quadcopter_ControllerWithNavigation1_B.Gain1 =
        (Quadcopter_ControllerWithNavigation1_P.PID_Altitude_D *
         Quadcopter_ControllerWithNavigation1_B.Filter_l -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_ij) *
        Quadcopter_ControllerWithNavigation1_P.PID_Altitude_N;

      // Sum: '<S516>/Sum Fdbk'
      Quadcopter_ControllerWithNavigation1_B.SinCos_o2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_a) +
        Quadcopter_ControllerWithNavigation1_B.Gain1;

      // DeadZone: '<S499>/DeadZone'
      if (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 >
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_UpperSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o2 -=
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_UpperSaturationLimit;
      } else if (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 >=
                 Quadcopter_ControllerWithNavigation1_P.PID_Altitude_LowerSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o2 = 0.0;
      } else {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o2 -=
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_LowerSaturationLimit;
      }

      // End of DeadZone: '<S499>/DeadZone'

      // Gain: '<S503>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.Filter_l *=
        Quadcopter_ControllerWithNavigation1_P.PID_Altitude_I;

      // Switch: '<S497>/Switch1' incorporates:
      //   Constant: '<S497>/Clamping_zero'
      //   Constant: '<S497>/Constant'
      //   Constant: '<S497>/Constant2'
      //   RelationalOperator: '<S497>/fix for DT propagation issue'

      if (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_m) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_hk;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_l;
      }

      // Switch: '<S497>/Switch2' incorporates:
      //   Constant: '<S497>/Clamping_zero'
      //   Constant: '<S497>/Constant3'
      //   Constant: '<S497>/Constant4'
      //   RelationalOperator: '<S497>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.Filter_l >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_m) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_gn;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_g;
      }

      // Switch: '<S497>/Switch' incorporates:
      //   Constant: '<S497>/Clamping_zero'
      //   Constant: '<S497>/Constant1'
      //   Logic: '<S497>/AND3'
      //   RelationalOperator: '<S497>/Equal1'
      //   RelationalOperator: '<S497>/Relational Operator'
      //   Switch: '<S497>/Switch1'
      //   Switch: '<S497>/Switch2'

      if ((Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_m !=
           Quadcopter_ControllerWithNavigation1_B.SinCos_o2) &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.Filter_l =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_f;
      }

      // DiscreteIntegrator: '<S506>/Integrator' incorporates:
      //   Switch: '<S497>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_a +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_a *
        Quadcopter_ControllerWithNavigation1_B.Filter_l;

      // Sum: '<S515>/Sum'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_a) +
        Quadcopter_ControllerWithNavigation1_B.Gain1;

      // Saturate: '<S513>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_UpperSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_UpperSaturationLimit;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PID_Altitude_LowerSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PID_Altitude_LowerSaturationLimit;
      }

      // Sum: '<S54>/Sum3' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'
      //   Saturate: '<S513>/Saturation'
      //   UnaryMinus: '<S54>/Unary Minus'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -=
        -static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_c.vz);

      // Gain: '<S561>/Proportional Gain'
      Quadcopter_ControllerWithNavigation1_B.SinCos_o2 =
        Quadcopter_ControllerWithNavigation1_P.PID_vz_P *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Gain: '<S559>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S551>/Filter'
      //   Gain: '<S550>/Derivative Gain'
      //   Sum: '<S551>/SumD'

      Quadcopter_ControllerWithNavigation1_B.Filter_l =
        (Quadcopter_ControllerWithNavigation1_P.PID_vz_D *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_m) *
        Quadcopter_ControllerWithNavigation1_P.PID_vz_N;

      // Sum: '<S566>/Sum Fdbk'
      Quadcopter_ControllerWithNavigation1_B.SinCos_o1 =
        (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_c) +
        Quadcopter_ControllerWithNavigation1_B.Filter_l;

      // DeadZone: '<S549>/DeadZone'
      if (Quadcopter_ControllerWithNavigation1_B.SinCos_o1 >
          Quadcopter_ControllerWithNavigation1_P.PID_vz_UpperSaturationLimit) {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o1 -=
          Quadcopter_ControllerWithNavigation1_P.PID_vz_UpperSaturationLimit;
      } else if (Quadcopter_ControllerWithNavigation1_B.SinCos_o1 >=
                 Quadcopter_ControllerWithNavigation1_P.PID_vz_LowerSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o1 = 0.0;
      } else {
        Quadcopter_ControllerWithNavigation1_B.SinCos_o1 -=
          Quadcopter_ControllerWithNavigation1_P.PID_vz_LowerSaturationLimit;
      }

      // End of DeadZone: '<S549>/DeadZone'

      // Gain: '<S553>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *=
        Quadcopter_ControllerWithNavigation1_P.PID_vz_I;

      // Switch: '<S547>/Switch1' incorporates:
      //   Constant: '<S547>/Clamping_zero'
      //   Constant: '<S547>/Constant'
      //   Constant: '<S547>/Constant2'
      //   RelationalOperator: '<S547>/fix for DT propagation issue'

      if (Quadcopter_ControllerWithNavigation1_B.SinCos_o1 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_et) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_mp;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_k;
      }

      // Switch: '<S547>/Switch2' incorporates:
      //   Constant: '<S547>/Clamping_zero'
      //   Constant: '<S547>/Constant3'
      //   Constant: '<S547>/Constant4'
      //   RelationalOperator: '<S547>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_et) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_i;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_ja;
      }

      // Switch: '<S547>/Switch' incorporates:
      //   Constant: '<S547>/Clamping_zero'
      //   Constant: '<S547>/Constant1'
      //   Logic: '<S547>/AND3'
      //   RelationalOperator: '<S547>/Equal1'
      //   RelationalOperator: '<S547>/Relational Operator'
      //   Switch: '<S547>/Switch1'
      //   Switch: '<S547>/Switch2'

      if ((Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_et !=
           Quadcopter_ControllerWithNavigation1_B.SinCos_o1) &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_o;
      }

      // DiscreteIntegrator: '<S556>/Integrator' incorporates:
      //   Switch: '<S547>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_c +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_g *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Sum: '<S565>/Sum'
      Quadcopter_ControllerWithNavigation1_B.Saturation_d =
        (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_c) +
        Quadcopter_ControllerWithNavigation1_B.Filter_l;

      // Saturate: '<S563>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.Saturation_d >
          Quadcopter_ControllerWithNavigation1_P.PID_vz_UpperSaturationLimit) {
        // Sum: '<S565>/Sum' incorporates:
        //   Saturate: '<S563>/Saturation'

        Quadcopter_ControllerWithNavigation1_B.Saturation_d =
          Quadcopter_ControllerWithNavigation1_P.PID_vz_UpperSaturationLimit;
      } else if (Quadcopter_ControllerWithNavigation1_B.Saturation_d <
                 Quadcopter_ControllerWithNavigation1_P.PID_vz_LowerSaturationLimit)
      {
        // Sum: '<S565>/Sum' incorporates:
        //   Saturate: '<S563>/Saturation'

        Quadcopter_ControllerWithNavigation1_B.Saturation_d =
          Quadcopter_ControllerWithNavigation1_P.PID_vz_LowerSaturationLimit;
      }

      // End of Saturate: '<S563>/Saturation'

      // Trigonometry: '<S371>/SinCos'
      Quadcopter_ControllerWithNavigation1_B.SinCos_o1 = sin
        (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0]);
      Quadcopter_ControllerWithNavigation1_B.SinCos_o2 = cos
        (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0]);

      // Saturate: '<S463>/Saturation' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'
      //   Gain: '<S461>/Proportional Gain'
      //   Sum: '<S54>/Sum1'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 -
         Quadcopter_ControllerWithNavigation1_B.In1_c.x) *
        Quadcopter_ControllerWithNavigation1_P.PIDController1_P;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_h)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_h;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_j)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_j;
      }

      // Sum: '<S54>/Sum' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'
      //   Saturate: '<S463>/Saturation'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
        Quadcopter_ControllerWithNavigation1_B.In1_c.vx;

      // Saturate: '<S463>/Saturation' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'
      //   Gain: '<S461>/Proportional Gain'
      //   Sum: '<S54>/Sum1'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 -
         Quadcopter_ControllerWithNavigation1_B.In1_c.y) *
        Quadcopter_ControllerWithNavigation1_P.PIDController1_P;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_h)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_h;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_j)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_j;
      }

      // Sum: '<S54>/Sum' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion1'
      //   Saturate: '<S463>/Saturation'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
        Quadcopter_ControllerWithNavigation1_B.In1_c.vy;

      // Saturate: '<S415>/Saturation' incorporates:
      //   Gain: '<S371>/Gain'
      //   Gain: '<S413>/Proportional Gain'
      //   Product: '<S54>/MatrixMultiply'
      //   Reshape: '<S371>/Reshape'
      //   Reshape: '<S371>/Reshape1'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.SinCos_o2 *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 +
         Quadcopter_ControllerWithNavigation1_B.SinCos_o1 *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1) *
        Quadcopter_ControllerWithNavigation1_P.PIDController_P;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        (Quadcopter_ControllerWithNavigation1_P.Gain_Gain *
         Quadcopter_ControllerWithNavigation1_B.SinCos_o1 *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 +
         Quadcopter_ControllerWithNavigation1_B.SinCos_o2 *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1) *
        Quadcopter_ControllerWithNavigation1_P.PIDController_P;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 >
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_i)
      {
        // Saturate: '<S415>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_i;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f)
      {
        // Saturate: '<S415>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f;
      }

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_i)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_i;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f;
      }

      // Gain: '<S54>/Gain1' incorporates:
      //   Saturate: '<S415>/Saturation'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        Quadcopter_ControllerWithNavigation1_P.Gain1_Gain_f *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Update for DiscreteIntegrator: '<S501>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_ij +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_g *
        Quadcopter_ControllerWithNavigation1_B.Gain1;

      // Update for DiscreteIntegrator: '<S551>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_m +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_k *
        Quadcopter_ControllerWithNavigation1_B.Filter_l;
      Quadcopter_ControllerWithNavigation1_PX4Timestamp
        (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_b);

      // RateLimiter: '<S53>/Rate Limiter1'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 -
        Quadcopter_ControllerWithNavigation1_DW.PrevY_b;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_RisingLim *
          Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_RisingLim *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_b;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.RateLimiter1_FallingLim *
                 Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_FallingLim *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_b;
      }

      Quadcopter_ControllerWithNavigation1_DW.PrevY_b =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1;

      // End of RateLimiter: '<S53>/Rate Limiter1'

      // Saturate: '<S53>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 >
          Quadcopter_ControllerWithNavigation1_P.Saturation_UpperSat) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.Saturation_UpperSat;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 <
                 Quadcopter_ControllerWithNavigation1_P.Saturation_LowerSat) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.Saturation_LowerSat;
      }

      // End of Saturate: '<S53>/Saturation'

      // Gain: '<S302>/Proportional Gain' incorporates:
      //   Fcn: '<S56>/fcn4'
      //   Fcn: '<S56>/fcn5'
      //   Sum: '<S53>/Sum3'
      //   Trigonometry: '<S574>/Trigonometric Function3'

      Quadcopter_ControllerWithNavigation1_B.Subtract =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 -
         Quadcopter_ControllerWithNavigation1_rt_atan2d_snf
         ((Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 *
           Quadcopter_ControllerWithNavigation1_B.Product2 +
           Quadcopter_ControllerWithNavigation1_B.dist *
           Quadcopter_ControllerWithNavigation1_B.Integrator_a) * 2.0,
          ((Quadcopter_ControllerWithNavigation1_B.Subtract -
            Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1)
           - Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp)
          + Quadcopter_ControllerWithNavigation1_B.rtb_VectorConcatenate_p_tmp_m))
        * Quadcopter_ControllerWithNavigation1_P.rollP;

      // RateLimiter: '<S53>/Rate Limiter2'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 -
        Quadcopter_ControllerWithNavigation1_DW.PrevY_g;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_RisingLim *
          Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_RisingLim *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_g;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.RateLimiter2_FallingLim *
                 Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_FallingLim *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_g;
      }

      Quadcopter_ControllerWithNavigation1_DW.PrevY_g =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0;

      // End of RateLimiter: '<S53>/Rate Limiter2'

      // Saturate: '<S53>/Saturation1'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 >
          Quadcopter_ControllerWithNavigation1_P.Saturation1_UpperSat) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.Saturation1_UpperSat;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 <
                 Quadcopter_ControllerWithNavigation1_P.Saturation1_LowerSat) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.Saturation1_LowerSat;
      }

      // End of Saturate: '<S53>/Saturation1'

      // If: '<S576>/If' incorporates:
      //   Constant: '<S577>/Constant'
      //   Constant: '<S578>/Constant'
      //   Trigonometry: '<S574>/trigFcn'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 >
          1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_b;
      } else if
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 <
           -1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_m;
      }

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 >
          1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
          1.0;
      } else if
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 <
           -1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
          -1.0;
      }

      // End of If: '<S576>/If'

      // Gain: '<S254>/Proportional Gain' incorporates:
      //   Sum: '<S53>/Sum2'
      //   Trigonometry: '<S574>/trigFcn'

      Quadcopter_ControllerWithNavigation1_B.dist =
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 - asin
         (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3)) *
        Quadcopter_ControllerWithNavigation1_P.pitchP;

      // Sum: '<S53>/Sum5'
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 -
        Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0];

      // Switch: '<S57>/Switch' incorporates:
      //   Abs: '<S57>/Abs'

      if (fabs
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) >
          Quadcopter_ControllerWithNavigation1_P.Switch_Threshold) {
        // Switch: '<S57>/Switch1' incorporates:
        //   Constant: '<S57>/Constant'
        //   Sum: '<S57>/Add'
        //   Sum: '<S57>/Subtract'

        if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 >
            Quadcopter_ControllerWithNavigation1_P.Switch1_Threshold) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 -=
            Quadcopter_ControllerWithNavigation1_P.Constant_Value_p;
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +=
            Quadcopter_ControllerWithNavigation1_P.Constant_Value_p;
        }

        // End of Switch: '<S57>/Switch1'
      }

      // Gain: '<S350>/Proportional Gain' incorporates:
      //   Switch: '<S57>/Switch'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *=
        Quadcopter_ControllerWithNavigation1_P.PIDController5_P;

      // Saturate: '<S352>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 >
          Quadcopter_ControllerWithNavigation1_P.PIDController5_UpperSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.PIDController5_UpperSaturationLimit;
      } else if
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 <
           Quadcopter_ControllerWithNavigation1_P.PIDController5_LowerSaturationLimit)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          Quadcopter_ControllerWithNavigation1_P.PIDController5_LowerSaturationLimit;
      }

      // End of Saturate: '<S352>/Saturation'

      // BusAssignment: '<S64>/Bus Assignment' incorporates:
      //   Constant: '<S53>/Constant1'
      //   DataTypeConversion: '<S53>/Data Type Conversion'
      //   DataTypeConversion: '<S53>/Data Type Conversion1'
      //   DataTypeConversion: '<S53>/Data Type Conversion2'
      //   MATLABSystem: '<S64>/PX4 Timestamp'

      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.timestamp =
        Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_b.PX4Timestamp;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.roll =
        static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Subtract);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.pitch =
        static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.dist);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.yaw =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.thrust_body[0] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.thrust_body[1] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_c.thrust_body[2] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[2];

      // MATLABSystem: '<S363>/SinkBlock' incorporates:
      //   BusAssignment: '<S64>/Bus Assignment'

      uORB_write_step
        (Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbMetadataObj,
         &Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbAdvertiseObj,
         &Quadcopter_ControllerWithNavigation1_B.BusAssignment_c);

      // Sum: '<S53>/Sum4' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 -=
        Quadcopter_ControllerWithNavigation1_B.In1_l.yawspeed;

      // Gain: '<S104>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S96>/Filter'
      //   Gain: '<S95>/Derivative Gain'
      //   Sum: '<S96>/SumD'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_P.yawRateD *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_f) *
        Quadcopter_ControllerWithNavigation1_P.PIDController_N;

      // Sum: '<S110>/Sum' incorporates:
      //   DiscreteIntegrator: '<S101>/Integrator'
      //   Gain: '<S106>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.Product2 =
        (Quadcopter_ControllerWithNavigation1_P.yawRateP *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_h) +
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Saturate: '<S108>/Saturation' incorporates:
      //   DeadZone: '<S94>/DeadZone'

      if (Quadcopter_ControllerWithNavigation1_B.Product2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit)
      {
        // Saturate: '<S108>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_h =
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit;
        Quadcopter_ControllerWithNavigation1_B.Product2 -=
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit;
      } else {
        if (Quadcopter_ControllerWithNavigation1_B.Product2 <
            Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit)
        {
          // Saturate: '<S108>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_h =
            Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit;
        } else {
          // Saturate: '<S108>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_h =
            Quadcopter_ControllerWithNavigation1_B.Product2;
        }

        if (Quadcopter_ControllerWithNavigation1_B.Product2 >=
            Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit)
        {
          Quadcopter_ControllerWithNavigation1_B.Product2 = 0.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.Product2 -=
            Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit;
        }
      }

      // End of Saturate: '<S108>/Saturation'

      // RelationalOperator: '<S92>/Relational Operator' incorporates:
      //   Constant: '<S92>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h =
        (Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value !=
         Quadcopter_ControllerWithNavigation1_B.Product2);

      // RelationalOperator: '<S92>/fix for DT propagation issue' incorporates:
      //   Constant: '<S92>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b =
        (Quadcopter_ControllerWithNavigation1_B.Product2 >
         Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value);

      // Gain: '<S98>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.Product2 =
        Quadcopter_ControllerWithNavigation1_P.yawRateI *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1;

      // Sum: '<S53>/Sum' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'

      Quadcopter_ControllerWithNavigation1_B.dist -=
        Quadcopter_ControllerWithNavigation1_B.In1_l.pitchspeed;

      // Gain: '<S154>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S146>/Filter'
      //   Gain: '<S145>/Derivative Gain'
      //   Sum: '<S146>/SumD'

      Quadcopter_ControllerWithNavigation1_B.Integrator_a =
        (Quadcopter_ControllerWithNavigation1_P.pitchRateD *
         Quadcopter_ControllerWithNavigation1_B.dist -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_n) *
        Quadcopter_ControllerWithNavigation1_P.PIDController1_N;

      // Sum: '<S160>/Sum' incorporates:
      //   DiscreteIntegrator: '<S151>/Integrator'
      //   Gain: '<S156>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        (Quadcopter_ControllerWithNavigation1_P.pitchRateP *
         Quadcopter_ControllerWithNavigation1_B.dist +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_o) +
        Quadcopter_ControllerWithNavigation1_B.Integrator_a;

      // Saturate: '<S158>/Saturation' incorporates:
      //   DeadZone: '<S144>/DeadZone'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit)
      {
        // Saturate: '<S158>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_c =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit;
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -=
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit;
      } else {
        if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 <
            Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit)
        {
          // Saturate: '<S158>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_c =
            Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit;
        } else {
          // Saturate: '<S158>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_c =
            Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;
        }

        if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >=
            Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit)
        {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
            0.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -=
            Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit;
        }
      }

      // End of Saturate: '<S158>/Saturation'

      // RelationalOperator: '<S142>/Relational Operator' incorporates:
      //   Constant: '<S142>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_c =
        (Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_e !=
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2);

      // RelationalOperator: '<S142>/fix for DT propagation issue' incorporates:
      //   Constant: '<S142>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.fixforDTpropagationissue_ne =
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
         Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_e);

      // Gain: '<S148>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        Quadcopter_ControllerWithNavigation1_P.pitchRateI *
        Quadcopter_ControllerWithNavigation1_B.dist;
      Quadcopter_ControllerWithNavigation1_PX4Timestamp
        (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_k);

      // BusAssignment: '<S66>/Bus Assignment' incorporates:
      //   Constant: '<S53>/Constant1'
      //   Constant: '<S53>/Constant2'
      //   Constant: '<S53>/Constant3'
      //   Constant: '<S53>/Constant4'
      //   DataTypeConversion: '<S53>/Data Type Conversion3'
      //   DataTypeConversion: '<S53>/Data Type Conversion4'
      //   DataTypeConversion: '<S53>/Data Type Conversion5'
      //   MATLABSystem: '<S66>/PX4 Timestamp'

      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.timestamp =
        Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_k.PX4Timestamp;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.roll_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.pitch_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.yaw_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.yaw_sp_move_rate =
        Quadcopter_ControllerWithNavigation1_P.Constant4_Value;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.q_d[0] =
        Quadcopter_ControllerWithNavigation1_P.Constant2_Value[0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.q_d[1] =
        Quadcopter_ControllerWithNavigation1_P.Constant2_Value[1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.q_d[2] =
        Quadcopter_ControllerWithNavigation1_P.Constant2_Value[2];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.q_d[3] =
        Quadcopter_ControllerWithNavigation1_P.Constant2_Value[3];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.thrust_body[0] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.thrust_body[1] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp.thrust_body[2] =
        Quadcopter_ControllerWithNavigation1_P.Constant1_Value_i[2];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp._padding0[0] =
        Quadcopter_ControllerWithNavigation1_P.Constant3_Value_m[0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp._padding0[1] =
        Quadcopter_ControllerWithNavigation1_P.Constant3_Value_m[1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp._padding0[2] =
        Quadcopter_ControllerWithNavigation1_P.Constant3_Value_m[2];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp._padding0[3] =
        Quadcopter_ControllerWithNavigation1_P.Constant3_Value_m[3];

      // MATLABSystem: '<S367>/SinkBlock' incorporates:
      //   BusAssignment: '<S66>/Bus Assignment'

      uORB_write_step
        (Quadcopter_ControllerWithNavigation1_DW.obj_a.orbMetadataObj,
         &Quadcopter_ControllerWithNavigation1_DW.obj_a.orbAdvertiseObj,
         &Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp);
      Quadcopter_ControllerWithNavigation1_PX4Timestamp
        (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_d);

      // BusAssignment: '<S67>/Bus Assignment' incorporates:
      //   Constant: '<S53>/Constant4'
      //   DataTypeConversion: '<S53>/Data Type Conversion3'
      //   DataTypeConversion: '<S53>/Data Type Conversion4'
      //   DataTypeConversion: '<S53>/Data Type Conversion5'
      //   MATLABSystem: '<S67>/PX4 Timestamp'

      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.timestamp =
        Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_d.PX4Timestamp;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.roll_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.pitch_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.yaw_body =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.yaw_sp_move_rate =
        Quadcopter_ControllerWithNavigation1_P.Constant4_Value;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.q_d[0] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.q_d[1] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.q_d[2] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.q_d[3] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.thrust_body[0] =
        0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.thrust_body[1] =
        0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.thrust_body[2] =
        0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.roll_reset_integral
        = false;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.pitch_reset_integral
        = false;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.yaw_reset_integral =
        false;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.fw_control_yaw =
        false;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_p.apply_flaps = 0U;
      for (Quadcopter_ControllerWithNavigation1_B.j = 0;
           Quadcopter_ControllerWithNavigation1_B.j < 7;
           Quadcopter_ControllerWithNavigation1_B.j++) {
        Quadcopter_ControllerWithNavigation1_B.BusAssignment_p._padding0[Quadcopter_ControllerWithNavigation1_B.j]
          = 0U;
      }

      // End of BusAssignment: '<S67>/Bus Assignment'
      Quadcopter_ControllerWithNavigation1_SinkBlock
        (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_p,
         &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_c);

      // Sum: '<S53>/Sum1' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        Quadcopter_ControllerWithNavigation1_B.Subtract -
        Quadcopter_ControllerWithNavigation1_B.In1_l.rollspeed;

      // Gain: '<S204>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S196>/Filter'
      //   Gain: '<S195>/Derivative Gain'
      //   Sum: '<S196>/SumD'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        (Quadcopter_ControllerWithNavigation1_P.rollRateD *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_k) *
        Quadcopter_ControllerWithNavigation1_P.PIDController2_N;

      // Sum: '<S210>/Sum' incorporates:
      //   DiscreteIntegrator: '<S201>/Integrator'
      //   Gain: '<S206>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.Subtract =
        (Quadcopter_ControllerWithNavigation1_P.rollRateP *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_i) +
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1;

      // Saturate: '<S208>/Saturation' incorporates:
      //   DeadZone: '<S194>/DeadZone'

      if (Quadcopter_ControllerWithNavigation1_B.Subtract >
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit)
      {
        // Saturate: '<S208>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_d2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit;
        Quadcopter_ControllerWithNavigation1_B.Subtract -=
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit;
      } else {
        if (Quadcopter_ControllerWithNavigation1_B.Subtract <
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit)
        {
          // Saturate: '<S208>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_d2 =
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit;
        } else {
          // Saturate: '<S208>/Saturation'
          Quadcopter_ControllerWithNavigation1_B.Saturation_d2 =
            Quadcopter_ControllerWithNavigation1_B.Subtract;
        }

        if (Quadcopter_ControllerWithNavigation1_B.Subtract >=
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit)
        {
          Quadcopter_ControllerWithNavigation1_B.Subtract = 0.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.Subtract -=
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit;
        }
      }

      // End of Saturate: '<S208>/Saturation'

      // RelationalOperator: '<S192>/Relational Operator' incorporates:
      //   Constant: '<S192>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_a =
        (Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_p !=
         Quadcopter_ControllerWithNavigation1_B.Subtract);

      // RelationalOperator: '<S192>/fix for DT propagation issue' incorporates:
      //   Constant: '<S192>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.fixforDTpropagationissue_bu =
        (Quadcopter_ControllerWithNavigation1_B.Subtract >
         Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_p);

      // Gain: '<S198>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.Subtract =
        Quadcopter_ControllerWithNavigation1_P.rollRateI *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
      Quadcopter_ControllerWithNavigation1_PX4Timestamp
        (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_h);

      // BusAssignment: '<S65>/Bus Assignment' incorporates:
      //   Constant: '<S53>/Constant'
      //   DataTypeConversion: '<S53>/Data Type Conversion10'
      //   DataTypeConversion: '<S53>/Data Type Conversion8'
      //   DataTypeConversion: '<S53>/Data Type Conversion9'
      //   DiscreteIntegrator: '<S53>/Discrete-Time Integrator'
      //   DiscreteIntegrator: '<S53>/Discrete-Time Integrator1'
      //   DiscreteIntegrator: '<S53>/Discrete-Time Integrator2'
      //   MATLABSystem: '<S65>/PX4 Timestamp'

      Quadcopter_ControllerWithNavigation1_B.BusAssignment_n.timestamp =
        Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_h.PX4Timestamp;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_n.rollspeed_integ =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator2_DSTATE);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_n.pitchspeed_integ =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator1_DSTATE);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_n.yawspeed_integ =
        static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator_DSTATE);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_n.additional_integ1 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_c0;

      // MATLABSystem: '<S365>/SinkBlock' incorporates:
      //   BusAssignment: '<S65>/Bus Assignment'

      uORB_write_step
        (Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbMetadataObj,
         &Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbAdvertiseObj,
         &Quadcopter_ControllerWithNavigation1_B.BusAssignment_n);

      // Switch: '<S92>/Switch1' incorporates:
      //   Constant: '<S92>/Constant'
      //   Constant: '<S92>/Constant2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_kt;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_e;
      }

      // Switch: '<S92>/Switch2' incorporates:
      //   Constant: '<S92>/Clamping_zero'
      //   Constant: '<S92>/Constant3'
      //   Constant: '<S92>/Constant4'
      //   RelationalOperator: '<S92>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.Product2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_g;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_j;
      }

      // Switch: '<S92>/Switch' incorporates:
      //   Constant: '<S92>/Constant1'
      //   Logic: '<S92>/AND3'
      //   RelationalOperator: '<S92>/Equal1'
      //   Switch: '<S92>/Switch1'
      //   Switch: '<S92>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.Product2 =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value;
      }

      // Update for DiscreteIntegrator: '<S101>/Integrator' incorporates:
      //   Switch: '<S92>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_h +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval *
        Quadcopter_ControllerWithNavigation1_B.Product2;

      // Update for DiscreteIntegrator: '<S96>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_f +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Switch: '<S142>/Switch1' incorporates:
      //   Constant: '<S142>/Constant'
      //   Constant: '<S142>/Constant2'

      if (Quadcopter_ControllerWithNavigation1_B.fixforDTpropagationissue_ne) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_hp;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_f;
      }

      // Switch: '<S142>/Switch2' incorporates:
      //   Constant: '<S142>/Clamping_zero'
      //   Constant: '<S142>/Constant3'
      //   Constant: '<S142>/Constant4'
      //   RelationalOperator: '<S142>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_e) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_c;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_e;
      }

      // Switch: '<S142>/Switch' incorporates:
      //   Constant: '<S142>/Constant1'
      //   Logic: '<S142>/AND3'
      //   RelationalOperator: '<S142>/Equal1'
      //   Switch: '<S142>/Switch1'
      //   Switch: '<S142>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_c &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_e;
      }

      // Update for DiscreteIntegrator: '<S151>/Integrator' incorporates:
      //   Switch: '<S142>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_o +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_k *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;

      // Update for DiscreteIntegrator: '<S146>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_n +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_p *
        Quadcopter_ControllerWithNavigation1_B.Integrator_a;

      // Switch: '<S192>/Switch1' incorporates:
      //   Constant: '<S192>/Constant'
      //   Constant: '<S192>/Constant2'

      if (Quadcopter_ControllerWithNavigation1_B.fixforDTpropagationissue_bu) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_is;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_a;
      }

      // Switch: '<S192>/Switch2' incorporates:
      //   Constant: '<S192>/Clamping_zero'
      //   Constant: '<S192>/Constant3'
      //   Constant: '<S192>/Constant4'
      //   RelationalOperator: '<S192>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.Subtract >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_p) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_b;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_k;
      }

      // Switch: '<S192>/Switch' incorporates:
      //   Constant: '<S192>/Constant1'
      //   Logic: '<S192>/AND3'
      //   RelationalOperator: '<S192>/Equal1'
      //   Switch: '<S192>/Switch1'
      //   Switch: '<S192>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_a &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.Subtract =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_a;
      }

      // Update for DiscreteIntegrator: '<S201>/Integrator' incorporates:
      //   Switch: '<S192>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_i +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_i *
        Quadcopter_ControllerWithNavigation1_B.Subtract;

      // Update for DiscreteIntegrator: '<S196>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_k +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_h *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1;

      // Update for DiscreteIntegrator: '<S53>/Discrete-Time Integrator2'
      Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator2_DSTATE +=
        Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator2_gainval *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

      // Update for DiscreteIntegrator: '<S53>/Discrete-Time Integrator1'
      Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator1_DSTATE +=
        Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator1_gainval *
        Quadcopter_ControllerWithNavigation1_B.dist;

      // Update for DiscreteIntegrator: '<S53>/Discrete-Time Integrator'
      Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator_DSTATE +=
        Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator_gainval *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1;
    }

    // End of Outputs for SubSystem: '<S50>/Position & Altitude controller'
    // End of Outputs for SubSystem: '<S50>/Attitude controller'

    // BusAssignment: '<S3>/Bus Assignment' incorporates:
    //   Constant: '<S51>/Constant'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_h;

    // BusAssignment: '<S3>/Bus Assignment' incorporates:
    //   Constant: '<S3>/Constant'
    //   DataTypeConversion: '<S3>/Data Type Conversion'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[0] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_d2);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[1] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_c);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[2] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_h);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[3] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_d);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[4] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_mw[0]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[5] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_mw[1]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[6] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_mw[2]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_g.control[7] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_mw[3]);
    Quadcopter_ControllerWithNavigation1_SinkBlock_l
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_g,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock);

    // End of Outputs for SubSystem: '<Root>/Position & Rate Controller'
  } else {
    // Outputs for IfAction SubSystem: '<Root>/controllerAttitude' incorporates:
    //   ActionPort: '<S5>/Action Port'

    // BusAssignment: '<S5>/Bus Assignment' incorporates:
    //   Constant: '<S586>/Constant'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_j;

    // Switch: '<S589>/Switch' incorporates:
    //   Constant: '<S589>/Constant'
    //   DataTypeConversion: '<S1>/Data Type Conversion'
    //   Product: '<S897>/Product'
    //   Product: '<S897>/Product1'
    //   Product: '<S897>/Product2'
    //   Product: '<S897>/Product3'
    //   Sum: '<S897>/Sum'

    if (!(((static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[0])
            * Quadcopter_ControllerWithNavigation1_B.In1_m.q[0] +
            static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[1])
            * Quadcopter_ControllerWithNavigation1_B.In1_m.q[1]) +
           static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[2])
           * Quadcopter_ControllerWithNavigation1_B.In1_m.q[2]) +
          static_cast<real_T>(Quadcopter_ControllerWithNavigation1_B.In1_m.q[3])
          * Quadcopter_ControllerWithNavigation1_B.In1_m.q[3] >
          Quadcopter_ControllerWithNavigation1_P.Switch_Threshold_j)) {
      Quadcopter_ControllerWithNavigation1_B.Subtract =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_kv[0];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_kv[1];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_kv[2];
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value_kv[3];
    }

    // End of Switch: '<S589>/Switch'

    // Sqrt: '<S904>/sqrt' incorporates:
    //   Product: '<S905>/Product'
    //   Product: '<S905>/Product1'
    //   Product: '<S905>/Product2'
    //   Product: '<S905>/Product3'
    //   Sum: '<S905>/Sum'

    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 = sqrt
      (((Quadcopter_ControllerWithNavigation1_B.Subtract *
         Quadcopter_ControllerWithNavigation1_B.Subtract +
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) +
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2) +
       Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 *
       Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3);

    // Product: '<S899>/Product'
    Quadcopter_ControllerWithNavigation1_B.Subtract /=
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

    // Product: '<S899>/Product1'
    Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 /=
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

    // Product: '<S899>/Product2'
    Quadcopter_ControllerWithNavigation1_B.Product2 =
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 /
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

    // Product: '<S899>/Product3'
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_3 /
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

    // Fcn: '<S590>/fcn3'
    Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
      (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
       Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 -
       Quadcopter_ControllerWithNavigation1_B.Subtract *
       Quadcopter_ControllerWithNavigation1_B.Product2) * -2.0;

    // Outputs for Enabled SubSystem: '<S5>/Attitude controller' incorporates:
    //   EnablePort: '<S584>/Enable'

    if (Quadcopter_ControllerWithNavigation1_B.In1_b.armed) {
      // Gain: '<S883>/Proportional Gain' incorporates:
      //   Bias: '<S593>/Bias'
      //   DataTypeConversion: '<S593>/Data Type Conversion'
      //   Gain: '<S593>/Gain'
      //   Gain: '<S5>/Gain3'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (static_cast<real32_T>
         (Quadcopter_ControllerWithNavigation1_B.In1_d.values[0]) +
         Quadcopter_ControllerWithNavigation1_P.Bias_Bias_e) *
        Quadcopter_ControllerWithNavigation1_P.Gain_Gain_m *
        Quadcopter_ControllerWithNavigation1_P.Gain3_Gain *
        Quadcopter_ControllerWithNavigation1_P.PIDController5_P_d;

      // Saturate: '<S885>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController5_UpperSaturationLimit_g)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController5_UpperSaturationLimit_g;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController5_LowerSaturationLimit_g)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.PIDController5_LowerSaturationLimit_g;
      }

      // Sum: '<S584>/Sum4' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'
      //   Saturate: '<S885>/Saturation'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -=
        Quadcopter_ControllerWithNavigation1_B.In1_l.yawspeed;

      // Gain: '<S631>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.dist =
        Quadcopter_ControllerWithNavigation1_P.PIDController_I *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Gain: '<S637>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S629>/Filter'
      //   Gain: '<S628>/Derivative Gain'
      //   Sum: '<S629>/SumD'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1 =
        (Quadcopter_ControllerWithNavigation1_P.PIDController_D *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE) *
        Quadcopter_ControllerWithNavigation1_P.PIDController_N_h;

      // Sum: '<S643>/Sum' incorporates:
      //   DiscreteIntegrator: '<S634>/Integrator'
      //   Gain: '<S639>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.Integrator_a =
        (Quadcopter_ControllerWithNavigation1_P.PIDController_P_j *
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE) +
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1;

      // DeadZone: '<S627>/DeadZone'
      if (Quadcopter_ControllerWithNavigation1_B.Integrator_a >
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_c)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_B.Integrator_a -
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_c;
      } else if (Quadcopter_ControllerWithNavigation1_B.Integrator_a >=
                 Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f4)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          0.0;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_B.Integrator_a -
          Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f4;
      }

      // End of DeadZone: '<S627>/DeadZone'

      // Switch: '<S625>/Switch1' incorporates:
      //   Constant: '<S625>/Clamping_zero'
      //   Constant: '<S625>/Constant'
      //   Constant: '<S625>/Constant2'
      //   RelationalOperator: '<S625>/fix for DT propagation issue'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_mk) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_dj;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_bl;
      }

      // Switch: '<S625>/Switch2' incorporates:
      //   Constant: '<S625>/Clamping_zero'
      //   Constant: '<S625>/Constant3'
      //   Constant: '<S625>/Constant4'
      //   RelationalOperator: '<S625>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.dist >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_mk) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_k;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_l;
      }

      // RelationalOperator: '<S625>/Relational Operator' incorporates:
      //   Constant: '<S625>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h =
        (Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_mk !=
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2);

      // Saturate: '<S641>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.Integrator_a >
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_c)
      {
        // Saturate: '<S641>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation =
          Quadcopter_ControllerWithNavigation1_P.PIDController_UpperSaturationLimit_c;
      } else if (Quadcopter_ControllerWithNavigation1_B.Integrator_a <
                 Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f4)
      {
        // Saturate: '<S641>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation =
          Quadcopter_ControllerWithNavigation1_P.PIDController_LowerSaturationLimit_f4;
      } else {
        // Saturate: '<S641>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation =
          Quadcopter_ControllerWithNavigation1_B.Integrator_a;
      }

      // End of Saturate: '<S641>/Saturation'

      // Sum: '<S584>/Sum5' incorporates:
      //   Bias: '<S588>/Bias'
      //   DataTypeConversion: '<S588>/Data Type Conversion'
      //   Gain: '<S588>/Gain'
      //   Gain: '<S5>/Gain1'
      //   UnaryMinus: '<S5>/Unary Minus1'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 = -(
        static_cast<real_T>((static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.In1_d.values[1]) +
        Quadcopter_ControllerWithNavigation1_P.Bias_Bias) *
                            Quadcopter_ControllerWithNavigation1_P.Gain_Gain_b) *
        Quadcopter_ControllerWithNavigation1_P.Gain1_Gain_j);

      // RateLimiter: '<S584>/Rate Limiter2'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
        Quadcopter_ControllerWithNavigation1_DW.PrevY;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_RisingLim_g *
          Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_RisingLim_g *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.RateLimiter2_FallingLim_k
                 * Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter2_FallingLim_k *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY;
      }

      Quadcopter_ControllerWithNavigation1_DW.PrevY =
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;

      // End of RateLimiter: '<S584>/Rate Limiter2'

      // If: '<S900>/If' incorporates:
      //   Constant: '<S901>/Constant'
      //   Constant: '<S902>/Constant'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 > 1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_mw1;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 < -1.0)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_bd;
      }

      // Saturate: '<S584>/Saturation1'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Saturation1_UpperSat_g) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Saturation1_UpperSat_g;
      } else if
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 <
           Quadcopter_ControllerWithNavigation1_P.Saturation1_LowerSat_j) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Saturation1_LowerSat_j;
      }

      // If: '<S900>/If' incorporates:
      //   Trigonometry: '<S898>/trigFcn'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 > 1.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 = 1.0;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 < -1.0)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 = -1.0;
      }

      // Sum: '<S584>/Sum' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'
      //   Gain: '<S787>/Proportional Gain'
      //   Saturate: '<S584>/Saturation1'
      //   Sum: '<S584>/Sum2'
      //   Trigonometry: '<S898>/trigFcn'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
         asin(Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0)) *
        Quadcopter_ControllerWithNavigation1_P.PIDController3_P -
        Quadcopter_ControllerWithNavigation1_B.In1_l.pitchspeed;

      // Gain: '<S681>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.Integrator_a =
        Quadcopter_ControllerWithNavigation1_P.PIDController1_I *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;

      // Gain: '<S687>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S679>/Filter'
      //   Gain: '<S678>/Derivative Gain'
      //   Sum: '<S679>/SumD'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        (Quadcopter_ControllerWithNavigation1_P.PIDController1_D *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_i) *
        Quadcopter_ControllerWithNavigation1_P.PIDController1_N_e;

      // Sum: '<S693>/Sum' incorporates:
      //   DiscreteIntegrator: '<S684>/Integrator'
      //   Gain: '<S689>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        (Quadcopter_ControllerWithNavigation1_P.PIDController1_P_e *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_p) +
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0;

      // DeadZone: '<S677>/DeadZone'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_f)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_f;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >=
                 Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_p)
      {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          0.0;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -
          Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_p;
      }

      // End of DeadZone: '<S677>/DeadZone'

      // RelationalOperator: '<S675>/Relational Operator' incorporates:
      //   Constant: '<S675>/Clamping_zero'

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b =
        (Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_o !=
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2);

      // Switch: '<S675>/Switch1' incorporates:
      //   Constant: '<S675>/Clamping_zero'
      //   Constant: '<S675>/Constant'
      //   Constant: '<S675>/Constant2'
      //   RelationalOperator: '<S675>/fix for DT propagation issue'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_o) {
        Quadcopter_ControllerWithNavigation1_B.i3 =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_p5;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i3 =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_n;
      }

      // Switch: '<S675>/Switch2' incorporates:
      //   Constant: '<S675>/Clamping_zero'
      //   Constant: '<S675>/Constant3'
      //   Constant: '<S675>/Constant4'
      //   RelationalOperator: '<S675>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.Integrator_a >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_o) {
        Quadcopter_ControllerWithNavigation1_B.i4 =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_o;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i4 =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_ly;
      }

      // Saturate: '<S691>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_f)
      {
        // Saturate: '<S691>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_i =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_UpperSaturationLimit_f;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_p)
      {
        // Saturate: '<S691>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_i =
          Quadcopter_ControllerWithNavigation1_P.PIDController1_LowerSaturationLimit_p;
      } else {
        // Saturate: '<S691>/Saturation'
        Quadcopter_ControllerWithNavigation1_B.Saturation_i =
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;
      }

      // End of Saturate: '<S691>/Saturation'

      // Sum: '<S584>/Sum6' incorporates:
      //   Bias: '<S591>/Bias'
      //   DataTypeConversion: '<S591>/Data Type Conversion'
      //   Gain: '<S591>/Gain'
      //   Gain: '<S5>/Gain'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        static_cast<real_T>((static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.In1_d.values[3]) +
        Quadcopter_ControllerWithNavigation1_P.Bias_Bias_o) *
                            Quadcopter_ControllerWithNavigation1_P.Gain_Gain_o) *
        Quadcopter_ControllerWithNavigation1_P.Gain_Gain_d;

      // RateLimiter: '<S584>/Rate Limiter1'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
        Quadcopter_ControllerWithNavigation1_DW.PrevY_m;
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_RisingLim_e *
          Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_RisingLim_e *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_m;
      } else if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 <
                 Quadcopter_ControllerWithNavigation1_P.RateLimiter1_FallingLim_d
                 * Quadcopter_ControllerWithNavigation1_period) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.RateLimiter1_FallingLim_d *
          Quadcopter_ControllerWithNavigation1_period +
          Quadcopter_ControllerWithNavigation1_DW.PrevY_m;
      }

      Quadcopter_ControllerWithNavigation1_DW.PrevY_m =
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;

      // End of RateLimiter: '<S584>/Rate Limiter1'

      // Saturate: '<S584>/Saturation'
      if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Saturation_UpperSat_f) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Saturation_UpperSat_f;
      } else if
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 <
           Quadcopter_ControllerWithNavigation1_P.Saturation_LowerSat_n) {
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Saturation_LowerSat_n;
      }

      // Sum: '<S584>/Sum1' incorporates:
      //   DataTypeConversion: '<S1>/Data Type Conversion2'
      //   Fcn: '<S590>/fcn4'
      //   Fcn: '<S590>/fcn5'
      //   Gain: '<S835>/Proportional Gain'
      //   Saturate: '<S584>/Saturation'
      //   Sum: '<S584>/Sum3'
      //   Trigonometry: '<S898>/Trigonometric Function3'

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 =
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
         Quadcopter_ControllerWithNavigation1_rt_atan2d_snf
         ((Quadcopter_ControllerWithNavigation1_B.Product2 *
           Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 +
           Quadcopter_ControllerWithNavigation1_B.Subtract *
           Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) *
          2.0, ((Quadcopter_ControllerWithNavigation1_B.Subtract *
                 Quadcopter_ControllerWithNavigation1_B.Subtract -
                 Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
                 * Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1)
                - Quadcopter_ControllerWithNavigation1_B.Product2 *
                Quadcopter_ControllerWithNavigation1_B.Product2) +
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 *
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3)) *
        Quadcopter_ControllerWithNavigation1_P.PIDController4_P -
        Quadcopter_ControllerWithNavigation1_B.In1_l.rollspeed;

      // Gain: '<S731>/Integral Gain'
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        Quadcopter_ControllerWithNavigation1_P.PIDController2_I *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2;

      // Gain: '<S737>/Filter Coefficient' incorporates:
      //   DiscreteIntegrator: '<S729>/Filter'
      //   Gain: '<S728>/Derivative Gain'
      //   Sum: '<S729>/SumD'

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        (Quadcopter_ControllerWithNavigation1_P.PIDController2_D *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 -
         Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_h) *
        Quadcopter_ControllerWithNavigation1_P.PIDController2_N_p;

      // Sum: '<S743>/Sum' incorporates:
      //   DiscreteIntegrator: '<S734>/Integrator'
      //   Gain: '<S739>/Proportional Gain'

      Quadcopter_ControllerWithNavigation1_B.Saturation_g =
        (Quadcopter_ControllerWithNavigation1_P.PIDController2_P *
         Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_2 +
         Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_b) +
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;

      // DeadZone: '<S727>/DeadZone' incorporates:
      //   Saturate: '<S741>/Saturation'

      if (Quadcopter_ControllerWithNavigation1_B.Saturation_g >
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit_k)
      {
        Quadcopter_ControllerWithNavigation1_B.Subtract =
          Quadcopter_ControllerWithNavigation1_B.Saturation_g -
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit_k;

        // Sum: '<S743>/Sum' incorporates:
        //   Saturate: '<S741>/Saturation'

        Quadcopter_ControllerWithNavigation1_B.Saturation_g =
          Quadcopter_ControllerWithNavigation1_P.PIDController2_UpperSaturationLimit_k;
      } else {
        if (Quadcopter_ControllerWithNavigation1_B.Saturation_g >=
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit_f)
        {
          Quadcopter_ControllerWithNavigation1_B.Subtract = 0.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.Subtract =
            Quadcopter_ControllerWithNavigation1_B.Saturation_g -
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit_f;
        }

        if (Quadcopter_ControllerWithNavigation1_B.Saturation_g <
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit_f)
        {
          // Sum: '<S743>/Sum' incorporates:
          //   Saturate: '<S741>/Saturation'

          Quadcopter_ControllerWithNavigation1_B.Saturation_g =
            Quadcopter_ControllerWithNavigation1_P.PIDController2_LowerSaturationLimit_f;
        }
      }

      // End of DeadZone: '<S727>/DeadZone'

      // Switch: '<S625>/Switch' incorporates:
      //   Constant: '<S625>/Constant1'
      //   Logic: '<S625>/AND3'
      //   RelationalOperator: '<S625>/Equal1'
      //   Switch: '<S625>/Switch1'
      //   Switch: '<S625>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.dist =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_j;
      }

      // Update for DiscreteIntegrator: '<S634>/Integrator' incorporates:
      //   Switch: '<S625>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_c *
        Quadcopter_ControllerWithNavigation1_B.dist;

      // Update for DiscreteIntegrator: '<S629>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_c *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_1;

      // Switch: '<S675>/Switch' incorporates:
      //   Constant: '<S675>/Constant1'
      //   Logic: '<S675>/AND3'
      //   RelationalOperator: '<S675>/Equal1'
      //   Switch: '<S675>/Switch1'
      //   Switch: '<S675>/Switch2'

      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_b &&
          (Quadcopter_ControllerWithNavigation1_B.i3 ==
           Quadcopter_ControllerWithNavigation1_B.i4)) {
        Quadcopter_ControllerWithNavigation1_B.Integrator_a =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_h;
      }

      // Update for DiscreteIntegrator: '<S684>/Integrator' incorporates:
      //   Switch: '<S675>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_p +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_iw *
        Quadcopter_ControllerWithNavigation1_B.Integrator_a;

      // Update for DiscreteIntegrator: '<S679>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_i +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_pb *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0;

      // Switch: '<S725>/Switch1' incorporates:
      //   Constant: '<S725>/Clamping_zero'
      //   Constant: '<S725>/Constant'
      //   Constant: '<S725>/Constant2'
      //   RelationalOperator: '<S725>/fix for DT propagation issue'

      if (Quadcopter_ControllerWithNavigation1_B.Subtract >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_j) {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant_Value_c4;
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtPrevAction =
          Quadcopter_ControllerWithNavigation1_P.Constant2_Value_nn;
      }

      // Switch: '<S725>/Switch2' incorporates:
      //   Constant: '<S725>/Clamping_zero'
      //   Constant: '<S725>/Constant3'
      //   Constant: '<S725>/Constant4'
      //   RelationalOperator: '<S725>/fix for DT propagation issue1'

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 >
          Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_j) {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant3_Value_ie;
      } else {
        Quadcopter_ControllerWithNavigation1_B.i2_d =
          Quadcopter_ControllerWithNavigation1_P.Constant4_Value_d;
      }

      // Switch: '<S725>/Switch' incorporates:
      //   Constant: '<S725>/Clamping_zero'
      //   Constant: '<S725>/Constant1'
      //   Logic: '<S725>/AND3'
      //   RelationalOperator: '<S725>/Equal1'
      //   RelationalOperator: '<S725>/Relational Operator'
      //   Switch: '<S725>/Switch1'
      //   Switch: '<S725>/Switch2'

      if ((Quadcopter_ControllerWithNavigation1_P.Clamping_zero_Value_j !=
           Quadcopter_ControllerWithNavigation1_B.Subtract) &&
          (Quadcopter_ControllerWithNavigation1_B.rtPrevAction ==
           Quadcopter_ControllerWithNavigation1_B.i2_d)) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_P.Constant1_Value_m;
      }

      // Update for DiscreteIntegrator: '<S734>/Integrator' incorporates:
      //   Switch: '<S725>/Switch'

      Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_b +=
        Quadcopter_ControllerWithNavigation1_P.Integrator_gainval_f *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2;

      // Update for DiscreteIntegrator: '<S729>/Filter'
      Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_h +=
        Quadcopter_ControllerWithNavigation1_P.Filter_gainval_ga *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3;
    }

    // End of Outputs for SubSystem: '<S5>/Attitude controller'

    // BusAssignment: '<S5>/Bus Assignment' incorporates:
    //   Bias: '<S592>/Bias'
    //   Constant: '<S5>/Constant'
    //   DataTypeConversion: '<S592>/Data Type Conversion'
    //   DataTypeConversion: '<S5>/Data Type Conversion'
    //   Gain: '<S592>/Gain'
    //   Gain: '<S5>/Gain2'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[0] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_g);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[1] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation_i);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[2] =
      static_cast<real32_T>(Quadcopter_ControllerWithNavigation1_B.Saturation);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[3] =
      static_cast<real32_T>(static_cast<real_T>((static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_B.In1_d.values[2]) +
      Quadcopter_ControllerWithNavigation1_P.Bias_Bias_m) *
      Quadcopter_ControllerWithNavigation1_P.Gain_Gain_k) *
      Quadcopter_ControllerWithNavigation1_P.Gain2_Gain_k);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[4] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_f5[0]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[5] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_f5[1]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[6] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_f5[2]);
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_e.control[7] =
      static_cast<real32_T>
      (Quadcopter_ControllerWithNavigation1_P.Constant_Value_f5[3]);
    Quadcopter_ControllerWithNavigation1_SinkBlock_l
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_e,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_k);
    Quadcopter_ControllerWithNavigation1_PX4Timestamp
      (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_c);

    // BusAssignment: '<S585>/Bus Assignment' incorporates:
    //   MATLABSystem: '<S585>/PX4 Timestamp'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.timestamp =
      Quadcopter_ControllerWithNavigation1_B.PX4Timestamp_c.PX4Timestamp;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.roll_body = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.pitch_body = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.yaw_body = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.yaw_sp_move_rate =
      0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.q_d[0] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.q_d[1] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.q_d[2] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.q_d[3] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.thrust_body[0] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.thrust_body[1] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.thrust_body[2] = 0.0F;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.roll_reset_integral =
      false;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.pitch_reset_integral =
      false;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.yaw_reset_integral =
      false;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.fw_control_yaw =
      false;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment_b.apply_flaps = 0U;
    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 7;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      Quadcopter_ControllerWithNavigation1_B.BusAssignment_b._padding0[Quadcopter_ControllerWithNavigation1_B.j]
        = 0U;
    }

    // End of BusAssignment: '<S585>/Bus Assignment'
    Quadcopter_ControllerWithNavigation1_SinkBlock
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_b,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_g);

    // End of Outputs for SubSystem: '<Root>/controllerAttitude'
  }

  // End of If: '<Root>/If'

  // Outputs for Enabled SubSystem: '<S15>/Send waypoints to OBC' incorporates:
  //   EnablePort: '<S32>/Enable'

  // Start for MATLABSystem: '<S15>/Read Parameter'
  if (Quadcopter_ControllerWithNavigation1_B.ParamStep_p > 0) {
    // BusAssignment: '<S32>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment'
    //   Constant: '<S42>/Constant'
    //   SignalConversion generated from: '<S38>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value.waypoints[0];

    // SignalConversion generated from: '<S38>/Matrix Concatenate1'
    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.lat;

    // SignalConversion generated from: '<S38>/Matrix Concatenate1'
    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.lon;

    // DataTypeConversion: '<S38>/Data Type Conversion'
    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.alt;

    // SignalConversion generated from: '<S32>/Matrix Concatenate1'
    Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_o.lat;

    // SignalConversion generated from: '<S32>/Matrix Concatenate1'
    Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_o.lon;

    // DataTypeConversion: '<S32>/Data Type Conversion'
    Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2[2] =
      Quadcopter_ControllerWithNavigation1_B.In1_o.alt;
    Quadcopter_ControllerWithNavigation1_MATLABSystem
      (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p,
       Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2,
       Quadcopter_ControllerWithNavigation1_B.In1_g.current.valid,
       Quadcopter_ControllerWithNavigation1_B.In1_g.current.type,
       &Quadcopter_ControllerWithNavigation1_B.MATLABSystem);

    // SignalConversion generated from: '<S44>/Matrix Concatenate' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S38>/Bus Assignment1'
    //   MATLABSystem: '<S38>/MATLAB System'
    //   SignalConversion generated from: '<S38>/MATLAB System'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].position
      [0] = Quadcopter_ControllerWithNavigation1_B.MATLABSystem.MATLABSystem[0];

    // SignalConversion generated from: '<S44>/Matrix Concatenate' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S38>/Bus Assignment1'
    //   MATLABSystem: '<S38>/MATLAB System'
    //   SignalConversion generated from: '<S38>/MATLAB System'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].position
      [1] = Quadcopter_ControllerWithNavigation1_B.MATLABSystem.MATLABSystem[1];

    // If: '<S44>/If' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S38>/Bus Assignment1'
    //   Constant: '<S46>/Constant'
    //   Constant: '<S46>/Constant1'
    //   Constant: '<S47>/Constant'
    //   Constant: '<S47>/Constant1'

    if (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type == 4) {
      // Outputs for IfAction SubSystem: '<S44>/If Action Subsystem2' incorporates:
      //   ActionPort: '<S47>/Action Port'

      // MATLABSystem: '<S47>/Read Parameter' incorporates:
      //   BusAssignment: '<S32>/Bus Assignment1'
      //   BusAssignment: '<S38>/Bus Assignment1'
      //   SignalConversion generated from: '<S47>/Read Parameter'

      if (Quadcopter_ControllerWithNavigation1_DW.obj_j.SampleTime !=
          Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_i) {
        Quadcopter_ControllerWithNavigation1_DW.obj_j.SampleTime =
          Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_i;
      }

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h =
        MW_Param_Step
        (Quadcopter_ControllerWithNavigation1_DW.obj_j.MW_PARAMHANDLE, MW_SINGLE,
         &Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
         velocity[2]);
      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
        Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
          velocity[2] = 0.0F;
      }

      // End of MATLABSystem: '<S47>/Read Parameter'
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[0] = Quadcopter_ControllerWithNavigation1_P.Constant1_Value_e3
        [0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[1] = Quadcopter_ControllerWithNavigation1_P.Constant1_Value_e3
        [1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        position[2] = Quadcopter_ControllerWithNavigation1_P.Constant_Value_kl;

      // End of Outputs for SubSystem: '<S44>/If Action Subsystem2'
    } else if (Quadcopter_ControllerWithNavigation1_B.In1_g.current.type == 3) {
      // Outputs for IfAction SubSystem: '<S44>/If Action Subsystem1' incorporates:
      //   ActionPort: '<S46>/Action Port'

      // MATLABSystem: '<S46>/Read Parameter'
      if (Quadcopter_ControllerWithNavigation1_DW.obj_d.SampleTime !=
          Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_l) {
        Quadcopter_ControllerWithNavigation1_DW.obj_d.SampleTime =
          Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_l;
      }

      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h =
        MW_Param_Step
        (Quadcopter_ControllerWithNavigation1_DW.obj_d.MW_PARAMHANDLE, MW_SINGLE,
         &Quadcopter_ControllerWithNavigation1_B.ParamStep);
      if (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) {
        Quadcopter_ControllerWithNavigation1_B.ParamStep = 0.0F;
      }

      // Gain: '<S46>/Gain' incorporates:
      //   BusAssignment: '<S32>/Bus Assignment1'
      //   BusAssignment: '<S38>/Bus Assignment1'
      //   MATLABSystem: '<S46>/Read Parameter'
      //
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[2] = Quadcopter_ControllerWithNavigation1_P.Gain_Gain_g *
        Quadcopter_ControllerWithNavigation1_B.ParamStep;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[0] = Quadcopter_ControllerWithNavigation1_P.Constant1_Value_k[0];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[1] = Quadcopter_ControllerWithNavigation1_P.Constant1_Value_k[1];
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        position[2] = Quadcopter_ControllerWithNavigation1_P.Constant_Value_co;

      // End of Outputs for SubSystem: '<S44>/If Action Subsystem1'
    } else {
      // Outputs for IfAction SubSystem: '<S44>/If Action Subsystem' incorporates:
      //   ActionPort: '<S45>/Action Port'

      // SignalConversion generated from: '<S45>/In1' incorporates:
      //   BusAssignment: '<S32>/Bus Assignment1'
      //   BusAssignment: '<S38>/Bus Assignment1'
      //   MATLABSystem: '<S38>/MATLAB System'
      //   SignalConversion generated from: '<S38>/MATLAB System'

      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        position[2] =
        Quadcopter_ControllerWithNavigation1_B.MATLABSystem.MATLABSystem[2];

      // BusAssignment: '<S38>/Bus Assignment1' incorporates:
      //   BusAssignment: '<S32>/Bus Assignment1'
      //   SignalConversion generated from: '<S44>/Matrix Concatenate1'
      //   SignalConversion generated from: '<S45>/In2'
      //
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[0] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vx;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[1] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vy;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
        velocity[2] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vz;

      // End of Outputs for SubSystem: '<S44>/If Action Subsystem'
    }

    // End of If: '<S44>/If'

    // BusAssignment: '<S38>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   Constant: '<S38>/Constant5'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].timestamp
      = Quadcopter_ControllerWithNavigation1_B.In1_g.current.timestamp;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].type =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.type;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].yaw =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.yaw;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].yaw_speed
      = Quadcopter_ControllerWithNavigation1_B.In1_g.current.yawspeed;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[0].
      point_valid = Quadcopter_ControllerWithNavigation1_P.Constant5_Value;

    // BusAssignment: '<S32>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment'
    //   Constant: '<S42>/Constant'
    //   SignalConversion generated from: '<S39>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value.waypoints[1];

    // SignalConversion generated from: '<S39>/Matrix Concatenate' incorporates:
    //   SignalConversion generated from: '<S38>/Matrix Concatenate1'

    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[0] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.lat;

    // SignalConversion generated from: '<S39>/Matrix Concatenate' incorporates:
    //   SignalConversion generated from: '<S38>/Matrix Concatenate1'

    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[1] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.lon;

    // DataTypeConversion: '<S39>/Data Type Conversion' incorporates:
    //   DataTypeConversion: '<S38>/Data Type Conversion'

    Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p[2] =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.alt;
    Quadcopter_ControllerWithNavigation1_MATLABSystem
      (Quadcopter_ControllerWithNavigation1_B.VectorConcatenate_p,
       Quadcopter_ControllerWithNavigation1_B.DataTypeConversion2,
       Quadcopter_ControllerWithNavigation1_B.In1_g.current.valid,
       Quadcopter_ControllerWithNavigation1_B.In1_g.current.type,
       &Quadcopter_ControllerWithNavigation1_B.MATLABSystem_p);

    // SignalConversion generated from: '<S39>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S39>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].velocity
      [0] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vx;

    // SignalConversion generated from: '<S39>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S39>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].velocity
      [1] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vy;

    // SignalConversion generated from: '<S39>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S39>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].velocity
      [2] = Quadcopter_ControllerWithNavigation1_B.In1_g.current.vz;

    // BusAssignment: '<S39>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S38>/Bus Assignment1'
    //   Constant: '<S39>/Constant5'
    //   MATLABSystem: '<S39>/MATLAB System'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].timestamp
      = Quadcopter_ControllerWithNavigation1_B.In1_g.current.timestamp;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].position
      [0] = Quadcopter_ControllerWithNavigation1_B.MATLABSystem_p.MATLABSystem[0];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].position
      [1] = Quadcopter_ControllerWithNavigation1_B.MATLABSystem_p.MATLABSystem[1];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].position
      [2] = Quadcopter_ControllerWithNavigation1_B.MATLABSystem_p.MATLABSystem[2];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].yaw =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.yaw;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].yaw_speed
      = Quadcopter_ControllerWithNavigation1_B.In1_g.current.yawspeed;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].
      point_valid = Quadcopter_ControllerWithNavigation1_P.Constant5_Value_m;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[1].type =
      Quadcopter_ControllerWithNavigation1_B.In1_g.current.type;

    // BusAssignment: '<S32>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment'
    //   Constant: '<S42>/Constant'
    //   SignalConversion generated from: '<S41>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value.waypoints[2];

    // MATLABSystem: '<S41>/MATLAB System' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   DataTypeConversion: '<S32>/Data Type Conversion'
    //   DataTypeConversion: '<S41>/Data Type Conversion'
    //   SignalConversion generated from: '<S32>/Matrix Concatenate1'
    //   SignalConversion generated from: '<S41>/Matrix Concatenate'
    //
    if (Quadcopter_ControllerWithNavigation1_B.In1_g.next.valid) {
      Quadcopter_ControllerWithNavigation1_B.Subtract =
        Quadcopter_ControllerWithNavigation1_B.In1_g.next.lat -
        Quadcopter_ControllerWithNavigation1_B.In1_o.lat;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
        Quadcopter_ControllerWithNavigation1_B.In1_g.next.lon -
        Quadcopter_ControllerWithNavigation1_B.In1_o.lon;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = fabs
        (Quadcopter_ControllerWithNavigation1_B.Subtract);
      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 180.0) {
        if (rtIsNaN(Quadcopter_ControllerWithNavigation1_B.Subtract + 180.0) ||
            rtIsInf(Quadcopter_ControllerWithNavigation1_B.Subtract + 180.0)) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            (rtNaN);
        } else if (Quadcopter_ControllerWithNavigation1_B.Subtract + 180.0 ==
                   0.0) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            0.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            fmod(Quadcopter_ControllerWithNavigation1_B.Subtract + 180.0, 360.0);
          if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
              == 0.0) {
            Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
              0.0;
          } else if (Quadcopter_ControllerWithNavigation1_B.Subtract + 180.0 <
                     0.0) {
            Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +=
              360.0;
          }
        }

        Quadcopter_ControllerWithNavigation1_B.Subtract =
          Quadcopter_ControllerWithNavigation1_B.Subtract * 0.0 +
          (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 -
           180.0);
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = fabs
          (Quadcopter_ControllerWithNavigation1_B.Subtract);
      }

      if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 90.0) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = fabs
          (Quadcopter_ControllerWithNavigation1_B.Subtract);
        Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h =
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 90.0);
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 += 180.0;
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          Quadcopter_ControllerWithNavigation1_B.Subtract * static_cast<real_T>
          (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h);
        if (rtIsNaN
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1))
        {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            (rtNaN);
        } else if
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
             < 0.0) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            -1.0;
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1
             > 0.0);
        }

        Quadcopter_ControllerWithNavigation1_B.Subtract = (90.0 -
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 *
           static_cast<real_T>
           (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) - 90.0))
          * Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
          static_cast<real_T>
          (Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h) +
          Quadcopter_ControllerWithNavigation1_B.Subtract * static_cast<real_T>(
          !Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h);
      }

      if ((Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 > 180.0) ||
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 < -180.0)) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_rt_remd_snf
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3, 360.0);
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 / 180.0;
        if (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 <
            0.0) {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            ceil
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1);
        } else {
          Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
            floor
            (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1);
        }

        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 =
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 - 360.0 *
           Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1)
          + Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 * 0.0;
      }

      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 =
        Quadcopter_ControllerWithNavigation1_sind_n
        (Quadcopter_ControllerWithNavigation1_B.In1_o.lat);
      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 =
        6.378137E+6 / sqrt(1.0 - 0.0066943799901413165 *
                           Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0
                           * Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0);
      if (rtIsInf(Quadcopter_ControllerWithNavigation1_B.In1_o.lat) || rtIsNaN
          (Quadcopter_ControllerWithNavigation1_B.In1_o.lat)) {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = (rtNaN);
      } else {
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
          Quadcopter_ControllerWithNavigation1_rt_remd_snf
          (Quadcopter_ControllerWithNavigation1_B.In1_o.lat, 360.0);
        Quadcopter_ControllerWithNavigation1_B.Product2 = fabs
          (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
        if (Quadcopter_ControllerWithNavigation1_B.Product2 > 180.0) {
          if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 0.0) {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 -= 360.0;
          } else {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 += 360.0;
          }

          Quadcopter_ControllerWithNavigation1_B.Product2 = fabs
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
        }

        if (Quadcopter_ControllerWithNavigation1_B.Product2 <= 45.0) {
          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = cos
            (0.017453292519943295 *
             Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
        } else if (Quadcopter_ControllerWithNavigation1_B.Product2 <= 135.0) {
          if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 0.0) {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = -sin
              ((Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 - 90.0) *
               0.017453292519943295);
          } else {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = sin
              ((Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 + 90.0) *
               0.017453292519943295);
          }
        } else {
          if (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 > 0.0) {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
              (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 - 180.0) *
              0.017453292519943295;
          } else {
            Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
              (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 + 180.0) *
              0.017453292519943295;
          }

          Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 = -cos
            (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
        }
      }

      Quadcopter_ControllerWithNavigation1_B.Subtract /=
        Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(1.0,
        0.99330562000985867 / (1.0 - 0.0066943799901413165 *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0 *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_0) *
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1) *
        57.295779513082323;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3 /=
        Quadcopter_ControllerWithNavigation1_rt_atan2d_snf(1.0,
        Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 *
        Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2) *
        57.295779513082323;
      Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2 =
        -static_cast<real_T>
        (Quadcopter_ControllerWithNavigation1_B.In1_g.next.alt) +
        Quadcopter_ControllerWithNavigation1_B.In1_o.alt;
      Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[0] = rtIsNaN
        (Quadcopter_ControllerWithNavigation1_B.Subtract);
      Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[1] = rtIsNaN
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3);
      Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[2] = rtIsNaN
        (Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
      Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = false;
      Quadcopter_ControllerWithNavigation1_B.i1 = 0;
      exitg1 = false;
      while ((!exitg1) && (Quadcopter_ControllerWithNavigation1_B.i1 < 3)) {
        if (Quadcopter_ControllerWithNavigation1_B.distinctWptsIdx[Quadcopter_ControllerWithNavigation1_B.i1])
        {
          Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h = true;
          exitg1 = true;
        } else {
          Quadcopter_ControllerWithNavigation1_B.i1++;
        }
      }

      Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 = 0.0 /
        static_cast<real_T>
        (!Quadcopter_ControllerWithNavigation1_B.RelationalOperator_h);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[0] = static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +
         Quadcopter_ControllerWithNavigation1_B.Subtract);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[1] = static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_3);
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[2] = static_cast<real32_T>
        (Quadcopter_ControllerWithNavigation1_B.rtb_DataTypeConversion_idx_1 +
         Quadcopter_ControllerWithNavigation1_B.rtb_Merge_idx_2);
    } else {
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[0] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[1] = 0.0F;
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
        position[2] = 0.0F;
    }

    // End of MATLABSystem: '<S41>/MATLAB System'

    // SignalConversion generated from: '<S41>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S41>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].velocity
      [0] = Quadcopter_ControllerWithNavigation1_B.In1_g.next.vx;

    // SignalConversion generated from: '<S41>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S41>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].velocity
      [1] = Quadcopter_ControllerWithNavigation1_B.In1_g.next.vy;

    // SignalConversion generated from: '<S41>/Matrix Concatenate1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   BusAssignment: '<S41>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].velocity
      [2] = Quadcopter_ControllerWithNavigation1_B.In1_g.next.vz;

    // BusAssignment: '<S41>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'
    //   Constant: '<S41>/Constant5'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].timestamp
      = Quadcopter_ControllerWithNavigation1_B.In1_g.next.timestamp;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].yaw =
      Quadcopter_ControllerWithNavigation1_B.In1_g.next.yaw;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].yaw_speed
      = Quadcopter_ControllerWithNavigation1_B.In1_g.next.yawspeed;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].
      point_valid = Quadcopter_ControllerWithNavigation1_P.Constant5_Value_k;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[2].type =
      Quadcopter_ControllerWithNavigation1_B.In1_g.next.type;

    // SignalConversion generated from: '<S40>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment'
    //   BusAssignment: '<S40>/Bus Assignment1'
    //   Constant: '<S42>/Constant'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value.waypoints[0];

    // BusAssignment: '<S40>/Bus Assignment1' incorporates:
    //   Constant: '<S40>/Constant'
    //   Constant: '<S40>/Constant1'
    //   Constant: '<S40>/Constant2'
    //   Constant: '<S40>/Constant3'
    //   Constant: '<S40>/Constant4'
    //   Constant: '<S40>/Constant5'
    //   Constant: '<S40>/Constant6'
    //   Constant: '<S40>/Constant7'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.timestamp =
      Quadcopter_ControllerWithNavigation1_P.Constant7_Value;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.yaw =
      Quadcopter_ControllerWithNavigation1_P.Constant3_Value;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.yaw_speed =
      Quadcopter_ControllerWithNavigation1_P.Constant4_Value_p;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.position[0] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[0];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.velocity[0] =
      Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[0];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.acceleration[0] =
      Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[0];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.position[1] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[1];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.velocity[1] =
      Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[1];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.acceleration[1] =
      Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[1];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.position[2] =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[2];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.velocity[2] =
      Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[2];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.acceleration[2] =
      Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[2];
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.point_valid =
      Quadcopter_ControllerWithNavigation1_P.Constant5_Value_e;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d.type =
      Quadcopter_ControllerWithNavigation1_P.Constant6_Value;

    // BusAssignment: '<S32>/Bus Assignment1' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment'
    //   BusAssignment: '<S40>/Bus Assignment1'
    //   Concatenate: '<S32>/Matrix Concatenate'
    //   Constant: '<S32>/Constant'
    //   Constant: '<S42>/Constant'

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.timestamp =
      Quadcopter_ControllerWithNavigation1_B.In1_g.timestamp;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.type =
      Quadcopter_ControllerWithNavigation1_P.Constant_Value_cc;
    for (Quadcopter_ControllerWithNavigation1_B.j = 0;
         Quadcopter_ControllerWithNavigation1_B.j < 7;
         Quadcopter_ControllerWithNavigation1_B.j++) {
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1._padding0[Quadcopter_ControllerWithNavigation1_B.j]
        =
        Quadcopter_ControllerWithNavigation1_P.Constant_Value._padding0[Quadcopter_ControllerWithNavigation1_B.j];
    }

    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[3] =
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d;
    Quadcopter_ControllerWithNavigation1_B.BusAssignment1.waypoints[4] =
      Quadcopter_ControllerWithNavigation1_B.BusAssignment1_d;

    // MATLABSystem: '<S43>/SinkBlock' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'

    uORB_write_step
      (Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbAdvertiseObj,
       &Quadcopter_ControllerWithNavigation1_B.BusAssignment1);
  }

  // End of Outputs for SubSystem: '<S15>/Send waypoints to OBC'
  Quadcopter_ControllerWithNavigation1_PX4Timestamp
    (&Quadcopter_ControllerWithNavigation1_B.PX4Timestamp);
}

// Model initialize function
void Quadcopter_ControllerWithNavigation1_initialize(void)
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // non-finite (run-time) assignments
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_e3[0] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_e3[1] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant_Value_kl = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_k[0] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_k[1] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant_Value_co = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[0] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[1] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant_Value_ps[2] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[0] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[1] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant1_Value_d[2] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[0] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[1] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant2_Value_b[2] = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant3_Value = rtNaNF;
  Quadcopter_ControllerWithNavigation1_P.Constant4_Value_p = rtNaNF;

  {
    static const char_T ParameterNameStr[14] = "COM_OBS_AVOID";
    static const char_T ParameterNameStr_0[15] = "MPC_LAND_SPEED";
    static const char_T ParameterNameStr_1[14] = "MPC_TKO_SPEED";
    px4_Bus_rate_ctrl_status rtb_BusAssignment_i;
    px4_Bus_vehicle_rates_setpoint rtb_BusAssignment_ny;
    real_T tmp;

    // Start for If: '<S14>/If'
    Quadcopter_ControllerWithNavigation1_DW.If_ActiveSubsystem = -1;

    // SystemInitialize for Enabled SubSystem: '<S9>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S13>/In1' incorporates:
    //   Outport: '<S13>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_c =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_p;

    // End of SystemInitialize for SubSystem: '<S9>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S36>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S37>/In1' incorporates:
    //   Outport: '<S37>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1 =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0;

    // End of SystemInitialize for SubSystem: '<S36>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S34>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S49>/In1' incorporates:
    //   Outport: '<S49>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_g =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_o;

    // End of SystemInitialize for SubSystem: '<S34>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S33>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S48>/In1' incorporates:
    //   Outport: '<S48>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_o =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_ke;

    // End of SystemInitialize for SubSystem: '<S33>/Enabled Subsystem'

    // SystemInitialize for IfAction SubSystem: '<S14>/Take-off'
    // InitializeConditions for Delay: '<S26>/Delay'
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_i =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition;

    // InitializeConditions for Delay: '<S27>/Delay'
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_n =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_c;

    // SystemInitialize for Enabled SubSystem: '<S27>/Enabled Subsystem2'
    // SystemInitialize for SignalConversion generated from: '<S28>/yaw_In' incorporates:
    //   Outport: '<S28>/yaw_Out'

    Quadcopter_ControllerWithNavigation1_B.yaw_In_ik =
      Quadcopter_ControllerWithNavigation1_P.yaw_Out_Y0;

    // End of SystemInitialize for SubSystem: '<S27>/Enabled Subsystem2'
    // End of SystemInitialize for SubSystem: '<S14>/Take-off'

    // SystemInitialize for IfAction SubSystem: '<S14>/Land'
    // InitializeConditions for Delay: '<S17>/Delay'
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[0] =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_h;
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_o[1] =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_h;

    // InitializeConditions for Gain: '<S22>/Gain1' incorporates:
    //   Delay: '<S22>/Delay'

    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_g =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_l;

    // InitializeConditions for Delay: '<S23>/Delay'
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE_e =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_k;

    // SystemInitialize for Enabled SubSystem: '<S23>/Enabled Subsystem2'
    // SystemInitialize for SignalConversion generated from: '<S25>/yaw_In' incorporates:
    //   Outport: '<S25>/yaw_Out'

    Quadcopter_ControllerWithNavigation1_B.yaw_In_i =
      Quadcopter_ControllerWithNavigation1_P.yaw_Out_Y0_k;

    // End of SystemInitialize for SubSystem: '<S23>/Enabled Subsystem2'

    // SystemInitialize for Enabled SubSystem: '<S22>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S24>/In' incorporates:
    //   Outport: '<S24>/Out'

    Quadcopter_ControllerWithNavigation1_B.In =
      Quadcopter_ControllerWithNavigation1_P.Out_Y0;

    // End of SystemInitialize for SubSystem: '<S22>/Enabled Subsystem'
    // End of SystemInitialize for SubSystem: '<S14>/Land'

    // SystemInitialize for IfAction SubSystem: '<S14>/Waypoint'
    // Start for MATLABSystem: '<S19>/UAV Waypoint Follower'
    Quadcopter_ControllerWithNavigation1_DW.obj.LastWaypointFlag = false;
    Quadcopter_ControllerWithNavigation1_DW.obj.StartFlag = true;
    Quadcopter_ControllerWithNavigation1_DW.obj.LookaheadFactor = 1.01;
    Quadcopter_ControllerWithNavigation1_DW.obj.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj.NumWaypoints = 0.0;

    // InitializeConditions for MATLABSystem: '<S19>/UAV Waypoint Follower'
    Quadcopter_ControllerWithNavigation1_DW.obj.WaypointIndex = 1.0;
    memset(&Quadcopter_ControllerWithNavigation1_DW.obj.WaypointsInternal[0], 0,
           9U * sizeof(real_T));

    // End of SystemInitialize for SubSystem: '<S14>/Waypoint'

    // SystemInitialize for IfAction SubSystem: '<S14>/IDLE'
    // InitializeConditions for Delay: '<S20>/Delay'
    Quadcopter_ControllerWithNavigation1_DW.Delay_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.Delay_InitialCondition_n;

    // SystemInitialize for Enabled SubSystem: '<S20>/Enabled Subsystem2'
    // SystemInitialize for SignalConversion generated from: '<S21>/yaw_In' incorporates:
    //   Outport: '<S21>/yaw_Out'

    Quadcopter_ControllerWithNavigation1_B.yaw_In =
      Quadcopter_ControllerWithNavigation1_P.yaw_Out_Y0_g;

    // End of SystemInitialize for SubSystem: '<S20>/Enabled Subsystem2'
    // End of SystemInitialize for SubSystem: '<S14>/IDLE'

    // SystemInitialize for Enabled SubSystem: '<S582>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S583>/In1' incorporates:
    //   Outport: '<S583>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_d =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_i;

    // End of SystemInitialize for SubSystem: '<S582>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S6>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S10>/In1' incorporates:
    //   Outport: '<S10>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_l =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_e;

    // End of SystemInitialize for SubSystem: '<S6>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S8>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S12>/In1' incorporates:
    //   Outport: '<S12>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_m =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_k;

    // End of SystemInitialize for SubSystem: '<S8>/Enabled Subsystem'

    // SystemInitialize for Enabled SubSystem: '<S7>/Enabled Subsystem'
    // SystemInitialize for SignalConversion generated from: '<S11>/In1' incorporates:
    //   Outport: '<S11>/Out1'

    Quadcopter_ControllerWithNavigation1_B.In1_b =
      Quadcopter_ControllerWithNavigation1_P.Out1_Y0_d;

    // End of SystemInitialize for SubSystem: '<S7>/Enabled Subsystem'

    // SystemInitialize for IfAction SubSystem: '<Root>/Position & Rate Controller' 
    // SystemInitialize for Enabled SubSystem: '<S50>/Position & Altitude controller' 
    // InitializeConditions for DiscreteIntegrator: '<S501>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_ij =
      Quadcopter_ControllerWithNavigation1_P.PID_Altitude_InitialConditionForFilter;

    // InitializeConditions for DiscreteIntegrator: '<S506>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_a =
      Quadcopter_ControllerWithNavigation1_P.PID_Altitude_InitialConditionForIntegrator;

    // InitializeConditions for DiscreteIntegrator: '<S551>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_m =
      Quadcopter_ControllerWithNavigation1_P.PID_vz_InitialConditionForFilter;

    // InitializeConditions for DiscreteIntegrator: '<S556>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_c =
      Quadcopter_ControllerWithNavigation1_P.PID_vz_InitialConditionForIntegrator;

    // SystemInitialize for Sum: '<S565>/Sum' incorporates:
    //   Outport: '<S54>/tau_Thrust'
    //   Saturate: '<S563>/Saturation'

    Quadcopter_ControllerWithNavigation1_B.Saturation_d =
      Quadcopter_ControllerWithNavigation1_P.tau_Thrust_Y0;

    // End of SystemInitialize for SubSystem: '<S50>/Position & Altitude controller' 

    // SystemInitialize for Enabled SubSystem: '<S50>/Attitude controller'
    // InitializeConditions for RateLimiter: '<S53>/Rate Limiter1'
    Quadcopter_ControllerWithNavigation1_DW.PrevY_b =
      Quadcopter_ControllerWithNavigation1_P.RateLimiter1_IC;

    // InitializeConditions for RateLimiter: '<S53>/Rate Limiter2'
    Quadcopter_ControllerWithNavigation1_DW.PrevY_g =
      Quadcopter_ControllerWithNavigation1_P.RateLimiter2_IC;

    // InitializeConditions for DiscreteIntegrator: '<S101>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_h =
      Quadcopter_ControllerWithNavigation1_P.PIDController_InitialConditionForIntegrator;

    // InitializeConditions for DiscreteIntegrator: '<S96>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_f =
      Quadcopter_ControllerWithNavigation1_P.PIDController_InitialConditionForFilter;

    // InitializeConditions for DiscreteIntegrator: '<S151>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_o =
      Quadcopter_ControllerWithNavigation1_P.PIDController1_InitialConditionForIntegrator;

    // InitializeConditions for DiscreteIntegrator: '<S146>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_n =
      Quadcopter_ControllerWithNavigation1_P.PIDController1_InitialConditionForFilter;

    // InitializeConditions for DiscreteIntegrator: '<S201>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_i =
      Quadcopter_ControllerWithNavigation1_P.PIDController2_InitialConditionForIntegrator;

    // InitializeConditions for DiscreteIntegrator: '<S196>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_k =
      Quadcopter_ControllerWithNavigation1_P.PIDController2_InitialConditionForFilter;

    // InitializeConditions for DiscreteIntegrator: '<S53>/Discrete-Time Integrator2' 
    Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator2_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator2_IC;

    // InitializeConditions for DiscreteIntegrator: '<S53>/Discrete-Time Integrator1' 
    Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator1_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator1_IC;

    // InitializeConditions for DiscreteIntegrator: '<S53>/Discrete-Time Integrator' 
    Quadcopter_ControllerWithNavigation1_DW.DiscreteTimeIntegrator_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.DiscreteTimeIntegrator_IC;
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_b);

    // Start for MATLABSystem: '<S363>/SinkBlock' incorporates:
    //   BusAssignment: '<S64>/Bus Assignment'

    Quadcopter_ControllerWithNavigation1_DW.obj_jr.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_jr.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbMetadataObj = ORB_ID
      (vehicle_rates_setpoint);
    uORB_write_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbAdvertiseObj,
       &rtb_BusAssignment_ny, 1);
    Quadcopter_ControllerWithNavigation1_DW.obj_jr.isSetupComplete = true;
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_k);

    // Start for MATLABSystem: '<S367>/SinkBlock' incorporates:
    //   BusAssignment: '<S66>/Bus Assignment'

    Quadcopter_ControllerWithNavigation1_DW.obj_a.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_a.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_a.orbMetadataObj = ORB_ID
      (vehAttSet);
    uORB_write_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_a.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_a.orbAdvertiseObj,
       &Quadcopter_ControllerWithNavigation1_B.BusAssignment_bp_c, 1);
    Quadcopter_ControllerWithNavigation1_DW.obj_a.isSetupComplete = true;
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_d);
    Quadcopter_ControllerWithNavigation1_SinkBlock_Init
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_p,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_c);
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_h);

    // Start for MATLABSystem: '<S365>/SinkBlock' incorporates:
    //   BusAssignment: '<S65>/Bus Assignment'

    Quadcopter_ControllerWithNavigation1_DW.obj_gk.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_gk.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbMetadataObj = ORB_ID
      (rate_ctrl_status);
    uORB_write_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbAdvertiseObj,
       &rtb_BusAssignment_i, 1);
    Quadcopter_ControllerWithNavigation1_DW.obj_gk.isSetupComplete = true;

    // SystemInitialize for Saturate: '<S108>/Saturation' incorporates:
    //   Outport: '<S53>/tau_Yaw'

    Quadcopter_ControllerWithNavigation1_B.Saturation_h =
      Quadcopter_ControllerWithNavigation1_P.tau_Yaw_Y0;

    // SystemInitialize for Saturate: '<S158>/Saturation' incorporates:
    //   Outport: '<S53>/tau_Pitch'

    Quadcopter_ControllerWithNavigation1_B.Saturation_c =
      Quadcopter_ControllerWithNavigation1_P.tau_Pitch_Y0;

    // SystemInitialize for Saturate: '<S208>/Saturation' incorporates:
    //   Outport: '<S53>/tau_Roll'

    Quadcopter_ControllerWithNavigation1_B.Saturation_d2 =
      Quadcopter_ControllerWithNavigation1_P.tau_Roll_Y0;

    // End of SystemInitialize for SubSystem: '<S50>/Attitude controller'
    Quadcopter_ControllerWithNavigation1_SinkBlock_h_Init
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_g,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock);

    // End of SystemInitialize for SubSystem: '<Root>/Position & Rate Controller' 

    // SystemInitialize for IfAction SubSystem: '<Root>/controllerAttitude'
    // SystemInitialize for Enabled SubSystem: '<S5>/Attitude controller'
    // InitializeConditions for DiscreteIntegrator: '<S634>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.PIDController_InitialConditionForIntegrator_g;

    // InitializeConditions for DiscreteIntegrator: '<S629>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE =
      Quadcopter_ControllerWithNavigation1_P.PIDController_InitialConditionForFilter_o;

    // InitializeConditions for RateLimiter: '<S584>/Rate Limiter2'
    Quadcopter_ControllerWithNavigation1_DW.PrevY =
      Quadcopter_ControllerWithNavigation1_P.RateLimiter2_IC_b;

    // InitializeConditions for DiscreteIntegrator: '<S684>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_p =
      Quadcopter_ControllerWithNavigation1_P.PIDController1_InitialConditionForIntegrator_i;

    // InitializeConditions for DiscreteIntegrator: '<S679>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_i =
      Quadcopter_ControllerWithNavigation1_P.PIDController1_InitialConditionForFilter_k;

    // InitializeConditions for RateLimiter: '<S584>/Rate Limiter1'
    Quadcopter_ControllerWithNavigation1_DW.PrevY_m =
      Quadcopter_ControllerWithNavigation1_P.RateLimiter1_IC_n;

    // InitializeConditions for DiscreteIntegrator: '<S734>/Integrator'
    Quadcopter_ControllerWithNavigation1_DW.Integrator_DSTATE_b =
      Quadcopter_ControllerWithNavigation1_P.PIDController2_InitialConditionForIntegrator_e;

    // InitializeConditions for DiscreteIntegrator: '<S729>/Filter'
    Quadcopter_ControllerWithNavigation1_DW.Filter_DSTATE_h =
      Quadcopter_ControllerWithNavigation1_P.PIDController2_InitialConditionForFilter_m;

    // SystemInitialize for Saturate: '<S641>/Saturation' incorporates:
    //   Outport: '<S584>/tau_Yaw'

    Quadcopter_ControllerWithNavigation1_B.Saturation =
      Quadcopter_ControllerWithNavigation1_P.tau_Yaw_Y0_g;

    // SystemInitialize for Saturate: '<S691>/Saturation' incorporates:
    //   Outport: '<S584>/tau_Pitch'

    Quadcopter_ControllerWithNavigation1_B.Saturation_i =
      Quadcopter_ControllerWithNavigation1_P.tau_Pitch_Y0_j;

    // SystemInitialize for Sum: '<S743>/Sum' incorporates:
    //   Outport: '<S584>/tau_Roll'
    //   Saturate: '<S741>/Saturation'

    Quadcopter_ControllerWithNavigation1_B.Saturation_g =
      Quadcopter_ControllerWithNavigation1_P.tau_Roll_Y0_j;

    // End of SystemInitialize for SubSystem: '<S5>/Attitude controller'
    Quadcopter_ControllerWithNavigation1_SinkBlock_h_Init
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_e,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_k);
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_c);
    Quadcopter_ControllerWithNavigation1_SinkBlock_Init
      (&Quadcopter_ControllerWithNavigation1_B.BusAssignment_b,
       &Quadcopter_ControllerWithNavigation1_DW.SinkBlock_g);

    // End of SystemInitialize for SubSystem: '<Root>/controllerAttitude'

    // SystemInitialize for Enabled SubSystem: '<S15>/Send waypoints to OBC'
    // SystemInitialize for IfAction SubSystem: '<S44>/If Action Subsystem2'
    // Start for MATLABSystem: '<S47>/Read Parameter'
    Quadcopter_ControllerWithNavigation1_DW.obj_j.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_j.SampleTime =
      Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_i;
    Quadcopter_ControllerWithNavigation1_DW.obj_j.isInitialized = 1;
    if (Quadcopter_ControllerWithNavigation1_DW.obj_j.SampleTime == -1.0) {
      tmp = 0.2;
    } else {
      tmp = Quadcopter_ControllerWithNavigation1_DW.obj_j.SampleTime;
    }

    Quadcopter_ControllerWithNavigation1_DW.obj_j.MW_PARAMHANDLE = MW_Init_Param
      (&ParameterNameStr_0[0], true, tmp * 1000.0);
    Quadcopter_ControllerWithNavigation1_DW.obj_j.isSetupComplete = true;

    // End of Start for MATLABSystem: '<S47>/Read Parameter'
    // End of SystemInitialize for SubSystem: '<S44>/If Action Subsystem2'

    // SystemInitialize for IfAction SubSystem: '<S44>/If Action Subsystem1'
    // Start for MATLABSystem: '<S46>/Read Parameter'
    Quadcopter_ControllerWithNavigation1_DW.obj_d.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_d.SampleTime =
      Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime_l;
    Quadcopter_ControllerWithNavigation1_DW.obj_d.isInitialized = 1;
    if (Quadcopter_ControllerWithNavigation1_DW.obj_d.SampleTime == -1.0) {
      tmp = 0.2;
    } else {
      tmp = Quadcopter_ControllerWithNavigation1_DW.obj_d.SampleTime;
    }

    Quadcopter_ControllerWithNavigation1_DW.obj_d.MW_PARAMHANDLE = MW_Init_Param
      (&ParameterNameStr_1[0], true, tmp * 1000.0);
    Quadcopter_ControllerWithNavigation1_DW.obj_d.isSetupComplete = true;

    // End of Start for MATLABSystem: '<S46>/Read Parameter'
    // End of SystemInitialize for SubSystem: '<S44>/If Action Subsystem1'
    Quadcopter_ControllerWithNavigation1_MATLABSystem_Init
      (&Quadcopter_ControllerWithNavigation1_DW.MATLABSystem);
    Quadcopter_ControllerWithNavigation1_MATLABSystem_Init
      (&Quadcopter_ControllerWithNavigation1_DW.MATLABSystem_p);

    // Start for MATLABSystem: '<S41>/MATLAB System'
    Quadcopter_ControllerWithNavigation1_DW.obj_ls.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_ls.isSetupComplete = true;

    // Start for MATLABSystem: '<S43>/SinkBlock' incorporates:
    //   BusAssignment: '<S32>/Bus Assignment1'

    Quadcopter_ControllerWithNavigation1_DW.obj_gj.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_gj.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbMetadataObj = ORB_ID
      (vehicle_trajectory_waypoint_desired);
    uORB_write_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbAdvertiseObj,
       &Quadcopter_ControllerWithNavigation1_B.BusAssignment1_m, 1);
    Quadcopter_ControllerWithNavigation1_DW.obj_gj.isSetupComplete = true;

    // End of SystemInitialize for SubSystem: '<S15>/Send waypoints to OBC'

    // Start for MATLABSystem: '<S9>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_m.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_m.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_m.orbMetadataObj = ORB_ID
      (vehicle_local_position);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_m.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_m.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_m.isSetupComplete = true;

    // Start for MATLABSystem: '<S15>/Read Parameter'
    Quadcopter_ControllerWithNavigation1_DW.obj_p.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_p.SampleTime =
      Quadcopter_ControllerWithNavigation1_P.ReadParameter_SampleTime;
    Quadcopter_ControllerWithNavigation1_DW.obj_p.isInitialized = 1;
    if (Quadcopter_ControllerWithNavigation1_DW.obj_p.SampleTime == -1.0) {
      tmp = 0.2;
    } else {
      tmp = Quadcopter_ControllerWithNavigation1_DW.obj_p.SampleTime;
    }

    Quadcopter_ControllerWithNavigation1_DW.obj_p.MW_PARAMHANDLE = MW_Init_Param
      (&ParameterNameStr[0], true, tmp * 1000.0);
    Quadcopter_ControllerWithNavigation1_DW.obj_p.isSetupComplete = true;

    // End of Start for MATLABSystem: '<S15>/Read Parameter'

    // Start for MATLABSystem: '<S36>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_l.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_l.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_l.orbMetadataObj = ORB_ID
      (vehicle_trajectory_waypoint);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_l.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_l.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_l.isSetupComplete = true;

    // Start for MATLABSystem: '<S34>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_b.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_b.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_b.orbMetadataObj = ORB_ID
      (position_setpoint_triplet);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_b.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_b.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_b.isSetupComplete = true;

    // Start for MATLABSystem: '<S33>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_h.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_h.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_h.orbMetadataObj = ORB_ID
      (home_position);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_h.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_h.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_h.isSetupComplete = true;

    // Start for MATLABSystem: '<S15>/LLA2LocalCoordinates'
    Quadcopter_ControllerWithNavigation1_DW.obj_i.previousValidReceived = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_i.nextValidReceived = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_i.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_i.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_i.isSetupComplete = true;

    // Start for MATLABSystem: '<S582>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_n.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_n.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_n.orbMetadataObj = ORB_ID
      (input_rc);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_n.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_n.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_n.isSetupComplete = true;

    // Start for MATLABSystem: '<S6>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_po.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_po.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_po.orbMetadataObj = ORB_ID
      (vehicle_odometry);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_po.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_po.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_po.isSetupComplete = true;

    // Start for MATLABSystem: '<S8>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_g.matlabCodegenIsDeleted = false;
    Quadcopter_ControllerWithNavigation1_DW.obj_g.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_g.orbMetadataObj = ORB_ID
      (vehicle_attitude);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_g.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_g.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_g.isSetupComplete = true;

    // Start for MATLABSystem: '<S7>/SourceBlock'
    Quadcopter_ControllerWithNavigation1_DW.obj_d0.matlabCodegenIsDeleted =
      false;
    Quadcopter_ControllerWithNavigation1_DW.obj_d0.isInitialized = 1;
    Quadcopter_ControllerWithNavigation1_DW.obj_d0.orbMetadataObj = ORB_ID
      (actuator_armed);
    uORB_read_initialize
      (Quadcopter_ControllerWithNavigation1_DW.obj_d0.orbMetadataObj,
       &Quadcopter_ControllerWithNavigation1_DW.obj_d0.eventStructObj);
    Quadcopter_ControllerWithNavigation1_DW.obj_d0.isSetupComplete = true;
    Quadcopter_ControllerWithNavigation1_PX4Timestamp_Init
      (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp);
  }
}

// Model terminate function
void Quadcopter_ControllerWithNavigation1_terminate(void)
{
  // Terminate for MATLABSystem: '<S9>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_m.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_m.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_m.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_m.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_m.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S9>/SourceBlock'

  // Terminate for MATLABSystem: '<S15>/Read Parameter'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_p.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_p.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S15>/Read Parameter'

  // Terminate for MATLABSystem: '<S36>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_l.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_l.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_l.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_l.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_l.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S36>/SourceBlock'

  // Terminate for MATLABSystem: '<S34>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_b.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_b.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_b.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_b.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_b.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S34>/SourceBlock'

  // Terminate for MATLABSystem: '<S33>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_h.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_h.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_h.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_h.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_h.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S33>/SourceBlock'

  // Terminate for MATLABSystem: '<S15>/LLA2LocalCoordinates'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_i.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_i.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S15>/LLA2LocalCoordinates'

  // Terminate for MATLABSystem: '<S582>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_n.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_n.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_n.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_n.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_n.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S582>/SourceBlock'

  // Terminate for MATLABSystem: '<S6>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_po.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_po.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_po.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_po.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_po.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S6>/SourceBlock'

  // Terminate for MATLABSystem: '<S8>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_g.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_g.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_g.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_g.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_g.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S8>/SourceBlock'

  // Terminate for MATLABSystem: '<S7>/SourceBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_d0.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_d0.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_d0.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_d0.isSetupComplete) {
      uORB_read_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_d0.eventStructObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S7>/SourceBlock'

  // Terminate for IfAction SubSystem: '<Root>/Position & Rate Controller'
  // Terminate for Enabled SubSystem: '<S50>/Attitude controller'
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_b);

  // Terminate for MATLABSystem: '<S363>/SinkBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_jr.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_jr.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_jr.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_jr.isSetupComplete) {
      uORB_write_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_jr.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S363>/SinkBlock'
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_k);

  // Terminate for MATLABSystem: '<S367>/SinkBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_a.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_a.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_a.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_a.isSetupComplete) {
      uORB_write_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_a.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S367>/SinkBlock'
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_d);
  Quadcopter_ControllerWithNavigation1_SinkBlock_Term
    (&Quadcopter_ControllerWithNavigation1_DW.SinkBlock_c);
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_h);

  // Terminate for MATLABSystem: '<S365>/SinkBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_gk.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_gk.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_gk.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_gk.isSetupComplete) {
      uORB_write_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_gk.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S365>/SinkBlock'
  // End of Terminate for SubSystem: '<S50>/Attitude controller'
  Quadcopter_ControllerWithNavigation1_SinkBlock_i_Term
    (&Quadcopter_ControllerWithNavigation1_DW.SinkBlock);

  // End of Terminate for SubSystem: '<Root>/Position & Rate Controller'

  // Terminate for IfAction SubSystem: '<Root>/controllerAttitude'
  Quadcopter_ControllerWithNavigation1_SinkBlock_i_Term
    (&Quadcopter_ControllerWithNavigation1_DW.SinkBlock_k);
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp_c);
  Quadcopter_ControllerWithNavigation1_SinkBlock_Term
    (&Quadcopter_ControllerWithNavigation1_DW.SinkBlock_g);

  // End of Terminate for SubSystem: '<Root>/controllerAttitude'

  // Terminate for Enabled SubSystem: '<S15>/Send waypoints to OBC'
  Quadcopter_ControllerWithNavigation1_MATLABSystem_Term
    (&Quadcopter_ControllerWithNavigation1_DW.MATLABSystem);

  // Terminate for IfAction SubSystem: '<S44>/If Action Subsystem2'
  // Terminate for MATLABSystem: '<S47>/Read Parameter'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_j.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_j.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S47>/Read Parameter'
  // End of Terminate for SubSystem: '<S44>/If Action Subsystem2'

  // Terminate for IfAction SubSystem: '<S44>/If Action Subsystem1'
  // Terminate for MATLABSystem: '<S46>/Read Parameter'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_d.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_d.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S46>/Read Parameter'
  // End of Terminate for SubSystem: '<S44>/If Action Subsystem1'
  Quadcopter_ControllerWithNavigation1_MATLABSystem_Term
    (&Quadcopter_ControllerWithNavigation1_DW.MATLABSystem_p);

  // Terminate for MATLABSystem: '<S41>/MATLAB System'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_ls.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_ls.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S41>/MATLAB System'

  // Terminate for MATLABSystem: '<S43>/SinkBlock'
  if (!Quadcopter_ControllerWithNavigation1_DW.obj_gj.matlabCodegenIsDeleted) {
    Quadcopter_ControllerWithNavigation1_DW.obj_gj.matlabCodegenIsDeleted = true;
    if ((Quadcopter_ControllerWithNavigation1_DW.obj_gj.isInitialized == 1) &&
        Quadcopter_ControllerWithNavigation1_DW.obj_gj.isSetupComplete) {
      uORB_write_terminate
        (&Quadcopter_ControllerWithNavigation1_DW.obj_gj.orbAdvertiseObj);
    }
  }

  // End of Terminate for MATLABSystem: '<S43>/SinkBlock'
  // End of Terminate for SubSystem: '<S15>/Send waypoints to OBC'
  Quadcopter_ControllerWithNavigation1_PX4Timestamp_Term
    (&Quadcopter_ControllerWithNavigation1_DW.PX4Timestamp);
}

//
// File trailer for generated code.
//
// [EOF]
//
